package javax.ws.rs;

public class MessageProcessingException extends RuntimeException
{
	private static final long serialVersionUID = 0x19e9076a41239f45L;

	public MessageProcessingException(Throwable cause)
	{
		super(cause);
	}

	public MessageProcessingException(String message, Throwable cause)
	{
		super(message, cause);
	}

	public MessageProcessingException(String message)
	{
		super(message);
	}

}
