package com.quintiles.structures.engine.jobs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.quintiles.structures.EelRequest;
import com.quintiles.structures.builder.BaseBuilder;
import com.quintiles.structures.builder.CoreBuilder;
import com.quintiles.structures.builder.CountryBuilder;
import com.quintiles.structures.builder.SiteBuilder;
import com.quintiles.e3.data.dao.model.nodb.ProjectJobStatusEnum;


/**
 * Initializes a new EEL3 structures create job
 * for the given study profile ID
 * <p>
 * @author John Shoun, Quintiles (q766769)
 * @version $Revision$
 */
public class CreateJob extends BaseJob
{
	private Logger logger = LoggerFactory.getLogger("com.quintiles.structures.engine.jobs.CreateJob");

	/**
	 * Empty constructor for job initialization
	 * <p/>
	 * Quartz requires a public empty constructor so that the scheduler can
	 * instantiate the class whenever it needs.
	 */
	public CreateJob()
	{
		//NOOP
	}

	/**
	 * implementation for the CreateJob,
	 * gets the profile information and starts up the 
	 * appropriate builder
	 * <p/>
	 */
	@Override
	public void localExecute()
	{
		int rc;
		BaseBuilder aBuilder;

		logger.debug("create job execute start");

		// create the builder and start it up
		// builder type selected based on class (core, country, site)
		if (siteId != null && siteId.length() >= 1){
			aBuilder = new SiteBuilder(profileId, jobId, siteId);
		}
		else if (countryCode != null && countryCode.length() > 1){
			aBuilder = new CountryBuilder(profileId, jobId, countryCode);
		}
		else {
			aBuilder = new CoreBuilder(profileId, jobId);
		}
		aBuilder.jobStatus(ProjectJobStatusEnum.IN_PROGRESS, "Running [Build " + EelRequest.build + "]");
		try {
			rc = aBuilder.buildContainer();
			if (rc == -1) {
				aBuilder.jobStatus(ProjectJobStatusEnum.ERROR, "Failed [Build " + EelRequest.build + "]");
			}
			else {
				aBuilder.jobStatus(ProjectJobStatusEnum.COMPLETED, "Success [Build " + EelRequest.build + "]");
			}
		}
		catch (Exception e) {
			aBuilder.jobStatus(ProjectJobStatusEnum.ERROR, "Failed [Build " + EelRequest.build + "]");
			logger.error("create job fail", e);
		}

		logger.debug("create job execute end");
	}

}
