package com.quintiles.structures.engine;

import java.util.HashMap;

import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.context.ApplicationContext;

import com.google.gson.JsonObject;
import com.quintiles.e3.data.dao.StudyProfileDAO;
import com.quintiles.e3.data.dao.model.StudyProfile;
import com.quintiles.structures.EelRequest;
import com.quintiles.structures.builder.BaseBuilder;
import com.quintiles.structures.builder.CoreBuilder;
import com.quintiles.structures.builder.CountryBuilder;
import com.quintiles.structures.builder.SiteBuilder;
import com.quintiles.lapi.Document;

/**
 * Handles request for DIA artifact folders. If the folder
 * exists the ID is returned. When the folder does not exist
 * it is created as JUST-IN-TIME. If the parent country or
 * site structure is missing the container is created and
 * and a subsequent startup build job is scheduled.
 * <p/>
 * @author John Shoun, Quintiles
 * @version $Revision$
 */
@XmlRootElement(name = "Folder")
@XmlAccessorType(XmlAccessType.FIELD)
public class FolderFactory
{
	// class variables
	private static Logger logger = LoggerFactory.getLogger("com.quintiles.structures.engine.FolderFactory");

	@XmlTransient
	protected static String llserver;

	// model
	@XmlTransient
	protected ApplicationContext sc;
	@XmlTransient
	protected StudyProfileDAO studyProfileDAO_;
	@XmlTransient
	protected StudyProfile studyProfile;

	// search, request parameters
	// profile search
	@XmlElement
	private String customer;
	@XmlElement
	private String project;
	@XmlElement
	private String protocol;
	// class search (no country implies core)
	@XmlElement(name="country_code")
	private String countryCode;
	@XmlElement(name="country")
	private String countryName;
	@XmlElement(name="site")
	private String siteNumber;
	// DIA search
	@XmlElement
	private String zone;
	@XmlElement
	private String section;
	@XmlElement
	private String artifact;
	// returned values
	@XmlElement(name="diakey")
	private String diaKey;
	@XmlElement(name="objectId")
	private int livelinkId;
	@XmlElement(name="projectId")
	private int projectObjId;
	@XmlElement(name="countryId")
	private int countryObjId;
	@XmlElement(name="siteId")
	private int siteObjId;
	@XmlElement
	private int status;
	@XmlElement
	private String message;

	private boolean jitBuild = false;
	private boolean countryBuild = false;
	private boolean siteBuild = false;
	private boolean siteUpdate = false;

	//  init Livelink server
	static {
		try {
			llserver = (String) (new InitialContext( )).lookup("java:comp/env/livelinkServer");
		}
		catch (Exception e){
			llserver = "exception";
		}
	}

	
	/**
	 * No-arg constructor, required for REST service
	 */
	public FolderFactory()
	{

		// default status and response message
		this.status = 0;
		this.message = "new";
	}

	/**
	 * Retrieves the Livelink object ID for the specified
	 * study folder. Extracts the parameters from the HTTP
	 * request.
	 * <p/>
	 * @param req	web request details
	 * @return		JSON response
	 */
	public static JsonObject getFolder(HttpServletRequest req)
	{
		JsonObject returnJ;

		// create and init folder request
		FolderFactory ff = new FolderFactory();
		ff.customer = req.getParameter("customer");
		ff.project = req.getParameter("project");
		ff.protocol = req.getParameter("protocol");

		ff.countryCode = req.getParameter("country");
		ff.siteNumber = req.getParameter("site");

		// get the artifact parameters
		ff.zone = req.getParameter("zone");
		ff.section = req.getParameter("section");
		ff.artifact = req.getParameter("artifact");

		// submit the request
		ff.submit();

		// compose the response
		returnJ = new JsonObject();

		returnJ.addProperty("customer", ff.getCustomer());
		returnJ.addProperty("project", ff.getProject());
		returnJ.addProperty("protocol", ff.getProtocol());

		returnJ.addProperty("country", ff.getCountryName());
		returnJ.addProperty("site", ff.getSiteNumber().trim());

		returnJ.addProperty("DIA", ff.getZone() 
						+ " / " + ff.getSection() 
						+ " / " + ff.getArtifact()
					);

		returnJ.addProperty("objectid", ff.getLivelinkId());
		returnJ.addProperty("objectId", ff.getLivelinkId());
		returnJ.addProperty("status", ff.getStatus());
		returnJ.addProperty("message", ff.getMessage());

		return returnJ;
	}


	/**
	 * Processes the folder request once the factory
	 * has been initialized.
	 * <p/>
	 */
	public void submit()
	{
		Long studyProfileId;

		logger.info("begin folder request"); 

		// plan for failure
		status = -1;

		// load the structure profile
		studyProfileId = getStudyProfileId();
		if ( studyProfileId < 1L) {
			logger.error("could not find profile for {}, {}, {}",
							customer, project, protocol);
			message = "could not find study profile";
			return;
		}

		// find existing artifact, or create new
		try {
			livelinkId = getFolderId();
		}
		catch (Exception e) {
			logger.error("exception for artifact {}, {}, {} -- message {}",
							zone, section, artifact, e);
			message = "error for requested artifact: " + e.getMessage();
			return;
		}

		if ( livelinkId < 0) {
			logger.error("could not get artifact {}, {}, {}",
							zone, section, artifact);
			message = "could not find requested artifact";
			return;
		}

		// success, update status
		status = 0;
		if (jitBuild){
			message = "just-in-time folder";
		}
		else if (livelinkId == 0){
			message = "no artifact requested";
		}
		else {
			message = "OK";
		}
		if (countryBuild){
			message += " -- build for " + countryName + " scheduled";
			// get job factory to schedule a country build
			JobFactory.createCreateJob( studyProfileId, countryCode, null );
		}
		if (siteBuild){
			message += " -- build for SITE " + siteNumber + " scheduled";
			// get job factory to schedule a site build
			JobFactory.createCreateJob( studyProfileId, countryCode, siteNumber );
		}

		if (siteUpdate){
			message += " -- SITE " + siteNumber + " was updated";
		}

		logger.debug("end folder request"); 
		return;
	}

	/**
	 * Retrieves the Livelink object ID for the specified study folder.
	 * Searches through any specified country and site levels;
	 * if the country and/or site container is missing it is created
	 * and a build triggered.
	 * <p/>
	 * This routine tracks the class container IDs (core, country,
	 * and site). The request can be submitted without the 
	 * zone/section/artifact in order to access the containers
	 * for batch processing.
	 * <p/>
	 * @return		folder id
	 * @throws Exception 
	 */
	public int getFolderId() throws Exception
	{
		BaseBuilder aBuilder;
		Document doc;
		int containerId = 0;
		int folderId;
		String query;

		logger.info("search for artifact"); 

		// we need to track the core/country/site containers, init values here
		projectObjId = 0;
		countryObjId = 0;
		siteObjId = 0;

		// let's go find the class container (core/country/site)
		doc = new Document(llserver);
		projectObjId = studyProfile.getProjectLlId().intValue();

		// start with assumption the container is project,
		// create the builder just-in-case we need it later
		containerId = -projectObjId;
		aBuilder = new CoreBuilder(studyProfile.getProfileId(), null);

		// but if we have country code, then down a level
		if (countryCode != null && countryCode.length() > 1) {
			aBuilder = new CountryBuilder(studyProfile.getProfileId(), null, countryCode);

			// get country container
			countryName = CountryBuilder.getCountry(countryCode);
			containerId = doc.getChildObjectId(-projectObjId, countryName);

			// missing? then build country
			if (containerId == -1) {
				containerId = aBuilder.createContainer();

				// if it failed to build then give up
				if (containerId == -1) {
					logger.error("could not build country {}", countryName);
					return -1;
				}
				countryBuild = true;
			}

			// track the country container
			countryObjId = containerId;
		}

		// then if there is a site, down one more
		// (we assume the country exists, as it was built in
		// the previous country search)
		if (siteNumber != null && siteNumber.length() >= 1 && countryCode.length() > 1) {
			HashMap<String, Object> siteInfo;

			aBuilder = new SiteBuilder(studyProfile.getProfileId(), null, siteNumber);

			// get site container:
			// use a special site builder function that takes the submitted
			// site_number and compares against the history and actually 
			// built site structures
//			query = "name like '" + siteNumber + " %' and subtype = 10101";
//			containerId = doc.getChildObjectId(countryObjId, siteNumber, query);
			siteInfo = SiteBuilder.findCS10Site(countryObjId, project, protocol, siteNumber);
			containerId = (Integer) siteInfo.get("dataid");

			// missing site? then build it
			if (containerId == -1) {
				containerId = aBuilder.createContainer();

				// if it failed to build then give up
				if (containerId == -1) {
					logger.error("could not build site {}", siteNumber);
					return -1;
				}
				siteBuild = true;

				// did the site number have to be changed?
				String builtSite;

				builtSite = ((SiteBuilder) aBuilder).getSiteId();
				if (!siteNumber.equals(builtSite) ) {
					logger.info("site requested '{}' was replaced by new site '{}'", siteNumber, builtSite);
					siteNumber = builtSite;
				}
			}
			else {
				// find out if the site number had to be changed
				String foundSite;

				foundSite = (String) siteInfo.get("site_number");
				if (!siteNumber.equals(foundSite) ) {
					logger.info("site requested '{}' was replaced by existing '{}'", siteNumber, foundSite);
					siteNumber = foundSite;
				}
			}

			// track the site container
			siteObjId = containerId;
		}

		// if no artifact specified, we are done
		// just return 0 as the object ID
		if (zone == null || (zone.length() < 1) ) {
			return 0;
		}

		// search for artifact within container
		query = "name = '" + zone + "'";
		folderId = doc.getChildObjectId(containerId, zone, query);
		if (folderId > 2000) {
			int subFolderId;

			subFolderId = folderId;
			query = "name like '%." + section + "'";
			folderId = doc.getChildObjectId(subFolderId, section, query);
			if (folderId > 2000) {
				subFolderId = folderId;
				// ready to look for artifact, deal with the UNBLINDED infix problem
				if ( artifact.startsWith("UNBLINDED") ) {
					query = "name like '%." + artifact + "'";
				}
				else {
					query = "name like '%." + artifact + "' and name not like '%UNBLINDED%'";
				}
				livelinkId = doc.getChildObjectId(subFolderId, artifact, query);
				if (livelinkId > 2000) {
					diaKey = doc.getObjectName().split(" ")[0];
					return livelinkId;
				}
			}
		}

		// if we got this far, it doesn't exist
		// let's try to create JIT item
		logger.info("could not find target, time to JIT"); 
		aBuilder.initTier();
		livelinkId = aBuilder.buildJIT(containerId, zone, section, artifact);
		diaKey = aBuilder.getDIA();
		jitBuild = true;

		return livelinkId;
	}


	/**
	 * gets the study profile (if it exists)
	 * <p/>
	 * @return			profile ID
	 */
	private Long getStudyProfileId()
	{
		sc = EelRequest.getSpringContext();
		studyProfileDAO_ = sc.getBean(StudyProfileDAO.class);

		// load the objects
		studyProfile = studyProfileDAO_.findByProjectProperty(customer, project, protocol);
		if (studyProfile == null) {
			return -1L;
		}

		return studyProfile.getProfileId();
	}

	/**
	 * accessors
	 */
	public String getCustomer()
	{ return customer; }
	public void setCustomer(String customer)
	{
		this.customer = customer;
	}

	public String getProject()
	{ return project; }
	public void setProject(String project)
	{
		this.project = project;
	}

	public String getProtocol()
	{ return protocol; }
	public void setProtocol(String protocol)
	{
		this.protocol = protocol;
	}

	public String getCountryCode()
	{ return countryCode; }
	public void setCountryCode(String countryCode)
	{
		this.countryCode = countryCode;
	}

	public String getCountryName()
	{ return countryName; }
	public void setCountryName(String countryName)
	{
		this.countryName = countryName;
	}

	public String getSiteNumber()
	{ return siteNumber; }
	public void setSiteNumber(String siteNumber)
	{
		this.siteNumber = siteNumber;
	}

	public String getZone()
	{ return zone; }
	public void setZone(String zone)
	{
		this.zone = zone;
	}

	public String getSection()
	{ return section; }
	public void setSection(String section)
	{
		this.section = section;
	}

	public String getArtifact()
	{ return artifact; }
	public void setArtifact(String artifact)
	{
		this.artifact = artifact;
	}

	public int getLivelinkId()
	{ return livelinkId; }
	public void setLivelinkId(int livelinkId)
	{
		this.livelinkId = livelinkId;
	}

	public String getMessage()
	{ return message; }
	public void setMessage(String message)
	{
		this.message = message;
	}

	public int getStatus()
	{ return status; }
	public void setStatus(int status)
	{
		this.status = status;
	}

	public String getDiaKey()
	{ return diaKey; }
	public void setDiaKey(String diaKey)
	{
		this.diaKey = diaKey;
	}

}
