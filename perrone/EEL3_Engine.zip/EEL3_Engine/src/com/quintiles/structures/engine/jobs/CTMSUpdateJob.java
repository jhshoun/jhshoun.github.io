package com.quintiles.structures.engine.jobs;


import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import com.quintiles.e3.data.dao.AuditTrailDAO;
import com.quintiles.e3.data.dao.ProjectJobDAO;
import com.quintiles.e3.data.dao.StudyProfileDAO;
import com.quintiles.e3.data.dao.model.AuditTrail;
import com.quintiles.e3.data.dao.model.ProjectJob;
import com.quintiles.e3.data.dao.model.StudyProfile;
import com.quintiles.e3.data.dao.model.nodb.ProjectJobStatusEnum;
import com.quintiles.e3.data.dao.model.nodb.ProjectJobTypeEnum;
import com.quintiles.structures.cloudrequests.PrepareCTMSBulkUpload;
import com.quintiles.structures.cloudrequests.PrepareWizardStatusCheck;
import com.quintiles.structures.cloudrequests.TmfCountryWizardJSONResponse;
import com.quintiles.structures.cloudrequests.TmfSiteWizardJSONResponse;
import com.quintiles.structures.cloudrequests.TmfStudyWizardJSONResponse;
import com.quintiles.structures.db.DbPackage;



/**
 * Supervisory job that scans for new CTMS data for health projects,
 * initiates tasks to transfer data to Wingspan
 * <p>
 * @author John Shoun, Quintiles (q766769)
 * @version $Revision: 827 $
 */
@Configurable
@Component
public class CTMSUpdateJob extends BaseJob
{
	private Logger logger = LoggerFactory.getLogger(CTMSUpdateJob.class);

	@Autowired
	protected StudyProfileDAO studyProfileDAO_;
	protected StudyProfile studyProfile;

	@Autowired
	protected ProjectJobDAO projectJobDAO_;
	protected ProjectJob projectJob;

	@Autowired
	protected AuditTrailDAO auditTrailDAO_;
	protected AuditTrail auditTrail;

	// list of all Wingspan configured studies
	List<Map<String, Object>> wingspanStudies;

	/**
	 * Empty constructor for job initialization
	 * <p/>
	 * Quartz requires a public empty constructor so that the scheduler can
	 * instantiate the class whenever it needs.
	 */
	public CTMSUpdateJob()
	{
		//NOOP
	}

	/**
	 * default procedure called by Quartz, we are overriding
	 * the base job because we don't need/have regular build data
	 * <p/>
	 */
	@Override
	public void execute(JobExecutionContext context)
									throws JobExecutionException
	{
		try {
			// is this a schedule or on demand run?
			// this is a schedule run, we need to create a job record
			if ( context.getJobDetail().getKey().getName().equals("ctms_update") ) {
				profileId = -2L;
				jobId = addScheduledHealthJob();
				logger.info("starting health CTMS scheduled data transfer");
			}
			// this is an on demand job, job already exists
			else {
				JobDataMap data = context.getMergedJobDataMap();
				jobId = data.getLong("PROJECT_JOB_ID");
				profileId = data.getLong("PROFILE_ID");
				logger.info("starting on demand health CTMS data transfer -- PID: {} JID: {}",
							profileId, jobId);
			}

			// get the study profile
			studyProfile = studyProfileDAO_.findById( profileId );

			localExecute( );
		}
		catch (Exception e){
			logger.error("health CTMS job execute failure", e);
		}

		logger.info("health CTMS job complete");
	}

	/**
	 * implementation of the health CTMS data update job
	 * <p/>
	 */
	@Override
	public void localExecute()
	{
		logger.debug("initializing health CTMS xfer");

		// load the health studies
		projectJob = projectJobDAO_.findByProjectJobIdAndProfileId(jobId, profileId);

		// start an audit trail object
		// used by the implementing classes
		auditTrail = new AuditTrail();
		auditTrail.setAuditType("CTMS data transfer");
		auditTrail.setProjectJobId( jobId );
		auditTrail.setProfileId( studyProfile.getProfileId() );
		auditTrail.setTemplateId( 0L );
		auditTrail.setTransUser("EEL3 Health Service");

		jobStatus(ProjectJobStatusEnum.IN_PROGRESS, "xfter job start");

		/*
		 * determine if the upload is the daily incremental or initial
		 * load for a single study
		 */
		try {
			PrepareCTMSBulkUpload ctmsBulk;

			// on demand job
			if( projectJob.getJobType() == ProjectJobTypeEnum.CTMS_INIT ) {
				ctmsBulk = new PrepareCTMSBulkUpload(ProjectJobTypeEnum.CTMS_INIT, profileId.intValue());
				ctmsBulk.setHealthJob( this );
				// is this profile health or tmf (transformation)
				if ( studyProfile.isStudyHealth() ) {
					ctmsBulk.createRequestIns("health");
				}
				else if ( studyProfile.getHostingEnv().equalsIgnoreCase("Wingspan") ) {
					ctmsBulk.createRequestIns("tmf");
				}
				auditTrail.setAuditType("CTMS study initial xfer");
				jobAudit("data transfer ready");
				ctmsBulk.execute();

				// insert (possibly) new upload status record for the profile	
				DbPackage dbPackage = new DbPackage.SetWingspanStatus();
				dbPackage.run(projectJob.getProfileId(), "Core", null, null, 1, 0, null);

				jobAudit("initial profile transfer complete");
			}

			// scheduled update
			// daily job profile id is -2
			else if( projectJob.getJobType() == ProjectJobTypeEnum.CTMS_UPDATE ) {
				// health updates
				ctmsBulk = new PrepareCTMSBulkUpload(ProjectJobTypeEnum.CTMS_UPDATE, profileId.intValue());
				ctmsBulk.setHealthJob( this );

				ctmsBulk.createRequestIns("health");
				auditTrail.setAuditType("CTMS health update");
				jobAudit("health update data transfer ready");
				ctmsBulk.execute();

				// tmf (transformation) updates
				ctmsBulk = new PrepareCTMSBulkUpload(ProjectJobTypeEnum.CTMS_UPDATE, -3);
				ctmsBulk.setHealthJob( this );


				ctmsBulk.createRequestIns("tmf");
				auditTrail.setAuditType("CTMS tmf update");
				jobAudit("tmf update data transfer ready");
				ctmsBulk.execute();

				// clear the build status
				getWingspanProfiles();
				jobAudit("wingspan study profiles collected");

				// update wizard completion status
				// health
				getWingspanStudyStatus("health", "Core");

				// transformation
				getWingspanStudyStatus("tmf", "All");
			}
			jobStatus(ProjectJobStatusEnum.COMPLETED, 
						"CTMS transfer job OK " + projectJob.getJobType().getTitle() 
					);
			jobAudit("CTMS transfer complete");
		}
		catch(Exception e) {
			logger.error("error occurred while executing job {}, id {}", 
							projectJob.getJobType(),
							projectJob.getProjectJobId()
						);
			logger.error("executing job exception", e);

			auditTrail.setDescription("CTMS transfer exception " + e);
			auditTrailDAO_.insert( auditTrail );

			jobStatus(ProjectJobStatusEnum.ERROR, 
							"CTMS xfter job error -jobType=" 
							+ projectJob.getJobType() 
							+ " exception=" 
							+ e
						);
		}

	}


	/**
	 * call the Wingspan study REST report
	 * update the Wingspan build status in EEL3
	 * 
	 * process wizard web service return message
	 * 1. it retrieves the protocol_number, project_code, customer, and wingspan_id 
	 *    from JSON message
	 * 2. it updates wingspan build status using the profile_id from all wingspan list
	 */
	private void getWingspanStudyStatus(String env, String scope) throws Exception
	{
		PrepareWizardStatusCheck wizardStatus;
		String response = null;

		// wizard completion status
		wizardStatus = new PrepareWizardStatusCheck(ProjectJobTypeEnum.CTMS_UPDATE);
		wizardStatus.createRequestIns(env);
		response = wizardStatus.execute();

		// update the wizard completion status
		try
		{
			TmfStudyWizardJSONResponse studies;
			TmfCountryWizardJSONResponse countries;
			TmfSiteWizardJSONResponse sites;
			DbPackage updateWsStatus = new DbPackage.SetWingspanStatus();

			// de-serialize the JSON to the response object
			logger.debug("API response >> {}", response);
			studies = new Gson().fromJson( response, TmfStudyWizardJSONResponse.class);

			// try to match completed wizards to registered profiles
			for ( TmfStudyWizardJSONResponse.Study wsStudy : studies.data )
			{
				logger.debug("protocol - {}, customer - {}, wingspan ID - {}", 
								wsStudy.name, wsStudy.sponsor, wsStudy.id);

				// scan the wingspan study list looking for a match
				for ( Map<String, Object> rec : wingspanStudies )
				{
					int profile_id;

					// look for protocol, environment match
					if ( !((String) rec.get("cloud_type")).equals(env) ) {
						continue;
					}
					if ( !((String) rec.get("protocol_number")).equalsIgnoreCase( wsStudy.name ) ) {
						continue;
					}

					// update the E4 build table with status
					profile_id = ((BigDecimal) rec.get("profile_id")).intValue();
					if ( "Effective".equalsIgnoreCase( wsStudy.status ) ) {
						updateWsStatus.run(profile_id, "Core", null, null, 1, 1, wsStudy.id);
					}
					else {
						updateWsStatus.run(profile_id, "Core", null, null, 1, 0, null);
					}

					// check the scope, 'Core' only then we are done
					if ( "Core".equals(scope) ) {
						continue;
					}

					// get the country build status
					wizardStatus.createRequestIns(env, wsStudy.links.countries);
					response = wizardStatus.execute();
					countries = new Gson().fromJson( response, TmfCountryWizardJSONResponse.class);
					for ( TmfCountryWizardJSONResponse.Country wsCountry : countries.data )
					{
						if ( "Effective".equalsIgnoreCase( wsCountry.status ) ) {
							updateWsStatus.run(profile_id, "Country", wsCountry.name, null, 1, 1, wsCountry.id);
						}
					}

					// get all sites for the study
					wizardStatus.createRequestIns(env, wsStudy.links.sites);
					response = wizardStatus.execute();
					sites = new Gson().fromJson( response, TmfSiteWizardJSONResponse.class);
					for ( TmfSiteWizardJSONResponse.Site wsSite : sites.data )
					{
						if ( "Effective".equalsIgnoreCase( wsSite.status ) ) {
							updateWsStatus.run(profile_id, "Site", wsSite.country, wsSite.name, 1, 1, wsSite.id);
						}
					}
				}
			}

		}
		catch (JsonSyntaxException jse)
		{
			logger.error("error parsing JSON REST response", jse);
			jobAudit(env + " invalid JSON response to study request");
		}
		catch (NullPointerException npe)
		{
			logger.error("null study list", npe);
			jobAudit(env + " NUll response to study list request");
		}

		jobAudit(env + " wizard build check complete");
	}


	/**
	 * clear all wizard build wingspan status
	 *    1. it retrieves all studies' wingspan status from database
	 *    2. it clears wingspan status using the profile_id from step 1.
	 */
	private void getWingspanProfiles() throws Exception
	{
		DbPackage dbGetAllPackage;

		logger.debug("get all wingspan status");
		dbGetAllPackage = new DbPackage.GetAllWingspanStatus();
		wingspanStudies = dbGetAllPackage.run();
		logger.debug("wingspan status fetch complete");
	}

	/**
	 * creates a new project job entry,
	 * this is required for scheduled runs that have to create their own 
	 */
	private long addScheduledHealthJob()
	{
		ProjectJob pj;

		pj = new ProjectJob();
		pj.setProfileId( profileId );
		pj.setTemplateId( -2L );

		pj.setStatus( ProjectJobStatusEnum.PENDING );
		pj.setJobType( ProjectJobTypeEnum.CTMS_UPDATE );

		pj.setStatusMessage("Schedule Job Registered");
		pj.setRequestTime( new Date() );
		pj.setTransUser( "QUARTZ" );

		pj = projectJobDAO_.insert( pj );
		logger.info("added schedule project job number: {}", pj.getProjectJobId());

		return pj.getProjectJobId();
	}

	/**
	 * updated the project job record in the database
	 * <p/>
	 * @param statusNo	status code
	 * @param msg		status message
	 */
	public void jobStatus(ProjectJobStatusEnum statusNo, String msg)
	{

		if (projectJob == null){
			return;
		}

		logger.debug("updating job status");
		projectJob.setServerId( System.getenv("COMPUTERNAME") );
		projectJob.setStatus( statusNo );
		projectJob.setStatusMessage(msg);
		projectJobDAO_.update( projectJob );
	}

	/**
	 * add a job event/audit entry
	 * <p/>
	 * @param msg		status message
	 */
	public void jobAudit(String msg)
	{
		if (auditTrail != null){
			auditTrail.setDescription(msg);
			auditTrailDAO_.insert( auditTrail );
		}

	}

}
