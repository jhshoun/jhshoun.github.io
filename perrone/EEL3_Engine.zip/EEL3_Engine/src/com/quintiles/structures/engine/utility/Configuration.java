package com.quintiles.structures.engine.utility;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.stereotype.Component;
import java.util.List;

import com.quintiles.e3.data.dao.ConfigurationDAO;
import com.quintiles.e3.data.dao.model.ConfigurationItem;

/**
 * shared configuration access
 * <p/>
 * @author John Shoun, Quintiles
 * @version $Revision: 908 $
 */
@Configurable
@Component
public class Configuration implements ConfigurationInterface
{
	@Autowired
	private ConfigurationDAO configurationDAO_;

	/**
	 */
	public Configuration()
	{
		// noop
	}

	/**
	 * get string value from configuration table
	 */
	public String getConfigValue(String key)
	{
		List<ConfigurationItem> cfg;

		cfg = configurationDAO_.findByName(key);
		return cfg.get(0).getCfgValue();
	}

	/**
	 * get number value from configuration table
	 */
	public int getConfigNumberValue(String key)
	{
		List<ConfigurationItem> cfg;

		cfg = configurationDAO_.findByName(key);
		return cfg.get(0).getCfgNumberValue().intValue();
	}

}
