package com.quintiles.structures.engine;

import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.quintiles.structures.engine.jobs.SiteUpdateJob;

/**
 * Manages the site batch update job. Only one of these
 * jobs exists in the scheduler. It is a permanent trigger
 * that repeats on a defined schedule. 
 * <p/>
 * The Site Batch Factory is implemented as a REST service.
 * <p/>
 * @author John Shoun, Quintiles
 * @version $Revision: 908 $
 */
@XmlRootElement(name = "SiteBatch")
@XmlAccessorType(XmlAccessType.FIELD)
public class SiteBatchFactory extends QuartzFactory
{
	// class variables
	private static Logger logger = LoggerFactory.getLogger("com.quintiles.structures.engine.SiteBatchFactory");

	/**
	 * No-arg constructor, required for REST service
	 */
	public SiteBatchFactory()
	{

		// default status and response message
		this.status = 0;
		this.userId = "SYSTEM";
		this.message = "batch site service";

		this.jobName = "batch_site";
		this.groupName = "EEL3_SITE";
	}

	/**
	 * Executes the job submission, once the input requirements
	 * are known. Status is stored here, so it can be returned as
	 * REST object
	 * <p/>
	 */
	public void updateSchedule()
	{
		// expect the worst
		status = -1;

		// verify initialization
		if (std == null) {
			logger.error("Quartz factory not initialized");
			addMessage("Quartz factory not initialized");
			return;
		}

		// schedule the run with Quartz
		try {

			// if disabled, we will remove the trigger and return
			if ( !isEnabled("batch") ) {
				this.removeSchedule("batch");
				addMessage("cron schedule trigger removed");
				status = 0;
				return;
			}

			// update the schedule
			if ( schedule( SiteUpdateJob.class, "batch" ) != 0) {
				addMessage("scheduler error");
				status = -1;
			}
			else {
				addMessage("OK, schedule updated");
				status = 0;
			}
		}
		catch (SchedulerException se) {
			logger.error("SiteUpdateJob schedule error", se);
			addMessage("scheduler error");
			status = -1;
		}
		catch (Exception e) {
			logger.error("SiteUpdateJob unforeseen problem", e);
			addMessage("bad problem, check the logs");
			status = -1;
		}

		return;
	}

	/**
	 * Executes the batch site update immediately
	 * <p/>
	 */
	public void runUpdate()
	{
		SiteUpdateJob suj;

		// expect the worst
		status = -1;

		try {

			// create job and run it
			suj = new SiteUpdateJob();
			suj.localExecute();

			addMessage("OK");
			status = 0;
		}
		catch (Exception e) {
			logger.error("SiteUpdateJob unforeseen problem", e);
			addMessage("bad problem, check the logs");
		}

		return;
	}


}
