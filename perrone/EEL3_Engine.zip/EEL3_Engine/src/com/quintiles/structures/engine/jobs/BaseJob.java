package com.quintiles.structures.engine.jobs;

import java.util.Date;

import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;


/**
 * Base implementation for the EEL job, this manages
 * the setup and scheduling for a Quartz job. The
 * E3_PROJECT_JOB record is created and updated as
 * the job progresses.
 * <p/>
 * Information about the job is passed to the logger
 * through the MDC so that individual log files are
 * generated for each run.
 * <p/>
 * @author John Shoun, Quintiles
 * @version $Revision$
 */
public class BaseJob implements Job, EelJob
{
	private Logger logger = LoggerFactory.getLogger("com.quintiles.structures.engine.jobs.BaseJob");

	protected Long jobId = -1L;
	protected Long profileId = -1L;
	protected String countryCode;
	protected String siteId;
	protected String status;
	protected Date startTime;
	protected Date endTime;
	protected Long dataId = 0L;


	/**
	 * Empty constructor for job initialization
	 * <br/>
	 * Quartz requires a public empty constructor so that the scheduler can
	 * instantiate the class whenever it needs.
	 */
	public BaseJob()
	{
		//NOOP
	}

	/**
	 * Called by the <code>{@link org.quartz.Scheduler}</code> when a
	 * <code>{@link org.quartz.Trigger}</code> fires that is associated with the
	 * <code>Job</code>.
	 * <p/>
	 * @throws 		if there is an exception while executing the job.
	 */
	@Override
	public void execute(JobExecutionContext context)
					throws JobExecutionException
	{
		JobDataMap data = context.getMergedJobDataMap();

		// job id used for build job log discrimination
		if ( data.containsKey("PROJECT_JOB_ID") ) {
			MDC.put("jobId", "" + data.getLong("PROJECT_JOB_ID") );
		}

		logger.info("starting job execution");

		try {
			// get the context
			jobId = data.getLong("PROJECT_JOB_ID");
			profileId = data.getLong("PROFILE_ID");
			countryCode = data.getString("COUNTRY_CODE");
			siteId = data.getString("SITE_NUMBER");
			if ( data.containsKey("DATA_ID") ) {
				dataId = data.getLong("DATA_ID");
			}

			logger.info("profile Id = {}; job id = {}", profileId, jobId);

			localExecute();
		}
		catch (Exception e){
			logger.error("build job execute failure", e);
		}

		MDC.clear();
		logger.info("job complete");
	}

	/**
	 * this is the specific build task for a job,
	 * overridden by sub-class
	 * <p/>
	 */
	public void localExecute()
	{
		//NOOP
	}

	/**
	 * accessors
	 */
	public Long getProfileId()
	{
		return profileId;
	}
	public Long getJobId()
	{
		return jobId;
	}
	public String getStatus()
	{
		return status;
	}
	public String getDescription()
	{
		return getStatus() + " some other stuff tbd";
	}
	public Date getStartTime()
	{
		return startTime;
	}
	public Date getEndTime()
	{
		return endTime;
	}

}
