package com.quintiles.structures.engine.jobs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.quintiles.structures.EelRequest;
import com.quintiles.structures.builder.StructureVerifier;
import com.quintiles.e3.data.dao.model.nodb.ProjectJobStatusEnum;


/**
 * Initializes a new EEL3 structures check job
 * for the given study profile ID. The check job verifies that
 * the study objects match the study template.
 * <p>
 * @author John Shoun, Quintiles (q766769)
 * @version $Revision: 827 $
 */
public class CheckJob extends BaseJob
{
	private Logger logger = LoggerFactory.getLogger("com.quintiles.structures.engine.jobs.CheckJob");

	/**
	 * Empty constructor for job initialization
	 * <p/>
	 * Quartz requires a public empty constructor so that the scheduler can
	 * instantiate the class whenever it needs.
	 */
	public CheckJob()
	{
		//NOOP
	}

	/**
	 * implementation for the Structure Verifier Job,
	 * gets the profile information and starts up the
	 * appropriate builder
	 * <p/>
	 */
	@Override
	public void localExecute()
	{
		int rc;
		StructureVerifier aChecker;

		logger.debug("check job execute start");

		// create the checker and start it up
		aChecker = new StructureVerifier(profileId, jobId, dataId);
		aChecker.jobStatus(ProjectJobStatusEnum.IN_PROGRESS, "Running [Build " + EelRequest.build + "]");

		try {
			rc = aChecker.verify();
			if (rc == -1) {
				aChecker.jobStatus(ProjectJobStatusEnum.ERROR, "Failed [Build " + EelRequest.build + "]");
			}
			else {
				aChecker.jobStatus(ProjectJobStatusEnum.COMPLETED, "Success [Build " + EelRequest.build + "]");
			}
		}
		catch (Exception e) {
			aChecker.jobStatus(ProjectJobStatusEnum.ERROR, "Failed [Build " + EelRequest.build + "]");
			logger.error("create job fail", e);
		}

		logger.debug("check job execute end");
	}

}
