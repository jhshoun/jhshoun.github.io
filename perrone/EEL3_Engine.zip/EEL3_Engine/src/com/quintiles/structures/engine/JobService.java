package com.quintiles.structures.engine;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.quintiles.e3.data.dao.model.nodb.ProjectJobTypeEnum;

/**
 * Handles the creation of EEL jobs. Either a new job
 * can be initiated or information can be requested on
 * an existing job (TBD).
 * <p/>
 * The Job Factory is implemented as a REST service.
 * <p/>
 * @author John Shoun, Quintiles
 * @version $Revision$
 */
@Path("/create")
@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
public class JobService
{

	@GET
	@Path("/project")
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public JobFactory getJobFactoryCore(
				@QueryParam("pid") int pid,
				@QueryParam("update") String jobType
			)
	{
		JobFactory jf;

		jf = new JobFactory(new Long(pid), null, null);

		// if the job type is not null, this is an update (create is default)
		if (jobType != null) {
			jf.setJobType( ProjectJobTypeEnum.UPDATE.getValue(), "update, project");
		}
		else {
			jf.setJobType( ProjectJobTypeEnum.CREATE.getValue(), "create, project");
		}

		jf.submit();
		return jf;
	}

	@GET
	@Path("/country")
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public JobFactory getJobFactoryCountry(
				@QueryParam("pid") int pid,
				@QueryParam("country") String country
			)
	{
		JobFactory jf;

		jf = new JobFactory(new Long(pid), country, null);
		jf.setJobType( ProjectJobTypeEnum.COUNTRY.getValue(), "build, country");
		jf.submit();
		return jf;
	}

	@GET
	@Path("/site")
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public JobFactory getJobFactorySite(
				@QueryParam("pid") int pid,
				@QueryParam("country") String country,
				@QueryParam("site") String site
			)
	{
		JobFactory jf;

		jf = new JobFactory(new Long(pid), country, site);
		jf.setJobType( ProjectJobTypeEnum.SITE.getValue(), "build, site");
		jf.submit();
		return jf;
	}

	@GET
	@Path("/check_job")
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public JobFactory getJobFactoryCheck(
				@QueryParam("pid") int pid,
				@QueryParam("restartid") int dataid
			)
	{
		JobFactory jf;

		// create a check job
		jf = new JobFactory(new Long(pid), null, null);
		jf.setJobType( ProjectJobTypeEnum.CHECK.getValue(), "check job");
		jf.setDataid( 0L );
		if (dataid > 1000) {
			jf.setDataid( new Long(dataid) );
		}

		jf.submit();
		return jf;
	}

	@GET
	@Path("/batch_update/schedule")
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public SiteBatchFactory updateBatchSchedule()
	{
		SiteBatchFactory sbf;

		sbf = new SiteBatchFactory();
		sbf.updateSchedule();
		return sbf;
	}

	@GET
	@Path("/batch_update/run")
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public SiteBatchFactory runBatchSiteUpdate()
	{
		SiteBatchFactory sbf;

		sbf = new SiteBatchFactory();
		sbf.runUpdate();
		return sbf;
	}

	@GET
	@Path("/health/schedule")
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public CTMSJobFactory runHealthScheduleUpdate()
	{
		CTMSJobFactory hjf;

		hjf = new CTMSJobFactory();
		hjf.updateSchedule();
		return hjf;
	}

	@GET
	@Path("/health/ctms_update")
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public CTMSJobFactory runHealthCTMSUpdate()
	{
		CTMSJobFactory hjf;

		hjf = new CTMSJobFactory();
		hjf.setJobType(ProjectJobTypeEnum.CTMS_UPDATE.getValue(), "ctms data transfer");
		hjf.submit();
		return hjf;
	}

	@GET
	@Path("/health/study_init/{pid}")
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public CTMSJobFactory runHealthStudyInit(
								@PathParam("pid") int profileId
						)
	{
		CTMSJobFactory hjf;

		hjf = new CTMSJobFactory();
		hjf.setProfileId( (long) profileId );
		hjf.setJobType(ProjectJobTypeEnum.CTMS_INIT.getValue(), "initial study data transfer");
		hjf.submit();
		return hjf;
	}
}
