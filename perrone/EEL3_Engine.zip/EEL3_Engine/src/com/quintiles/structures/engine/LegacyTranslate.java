package com.quintiles.structures.engine;

import java.util.List;
import java.util.Map;

import com.quintiles.structures.db.DbPackage;



/**
 * Used to translate legacy CLASS, GROUP, TYPE, SUBTYPE
 * structure references to the new DIA template.
 * This is done with a mapping table in the E3 schema.
 * <p/>
 * @author John Shoun, Quintiles
 * @version $Revision$
 */
public class LegacyTranslate
{

	public String[] xlate(String eclass, String group, String type, String subtype, String report)
	{
		List<Map<String, Object>> rs1;
		String[] dia;

		// look up the CGTS value from the mapping table
		rs1 = (new DbPackage.LegacyXlate()).run(eclass, group, type, subtype, report);

		if (rs1.size() > 0) {
			Map<String, Object> rec = rs1.get(0);

			dia = new String[5];
			dia[0] = (String) rec.get("zone_name");
			dia[1] = (String) rec.get("section_name");
			dia[2] = (String) rec.get("artifact_name");
			dia[3] = (String) rec.get("abbreviation");
			dia[4] = (String) rec.get("tmf_item_id");

			return dia;
		}

		return new String[0];
	}
}
