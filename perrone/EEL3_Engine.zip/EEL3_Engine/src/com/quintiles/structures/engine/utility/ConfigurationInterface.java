package com.quintiles.structures.engine.utility;

/**
 * @author q791213 
 * 
 * parent interface for configuration class so that we can
 * implement mock configure class for junit testing.
 */

public interface ConfigurationInterface
{

	/**
	 * get string value
	 */
	public String getConfigValue(String key);

	/**
	 * get number value
	 */
	public int getConfigNumberValue(String key);

}
