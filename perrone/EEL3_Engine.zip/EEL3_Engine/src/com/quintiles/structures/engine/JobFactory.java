package com.quintiles.structures.engine;

import static org.quartz.DateBuilder.*;
import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.quartz.DateBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.impl.StdSchedulerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.context.ApplicationContext;

import com.quintiles.e3.data.dao.ProjectJobDAO;
import com.quintiles.e3.data.dao.StudyProfileDAO;
import com.quintiles.e3.data.dao.model.ProjectJob;
import com.quintiles.e3.data.dao.model.StudyProfile;
import com.quintiles.e3.data.dao.model.nodb.ProjectJobTypeEnum;
import com.quintiles.e3.data.dao.model.nodb.ProjectJobStatusEnum;
import com.quintiles.structures.EelRequest;
import com.quintiles.structures.engine.jobs.CheckJob;
import com.quintiles.structures.engine.jobs.CreateJob;

/**
 * Handles the creation of EEL jobs. Either a new job
 * can be initiated or information can be requested on
 * an existing job (TBD).
 * <p/>
 * The Job Factory is implemented as a REST service.
 * <p/>
 * @author John Shoun, Quintiles
 * @version $Revision$
 */
@XmlRootElement(name = "Job")
@XmlAccessorType(XmlAccessType.FIELD)
public class JobFactory
{
	// class variables
	private static Logger logger = LoggerFactory.getLogger("com.quintiles.structures.engine.JobFactory");
	private static StdSchedulerFactory std;
	private static final int delay = 1; 		// number of minutes to wait for run

	// REST service elements
	@XmlElement(name="jobId")
	private Long projectJobId;
	@XmlElement(name="profileId")
	private Long profileId;
	@XmlElement(name="country")
	private String countryCode;
	@XmlElement(name="site")
	private String siteNumber;

	@XmlElement(name="type")
	private int jobType;
	@XmlElement
	private int status;
	@XmlElement
	private String message;
	@XmlElement
	private Long dataid = 0L;      // data ID for check job restart

	/**
	 * No-arg constructor, required for REST service
	 */
	public JobFactory()
	{
		this.profileId = 0L;
		this.countryCode = null;
		this.siteNumber = null;

		this.projectJobId = -1L;
		this.jobType = ProjectJobTypeEnum.CREATE.getValue();

		// default status and response message
		this.status = 0;
		this.message = "new";
	}

	/**
	 * This is a utility constructor for the job factory.
	 * It creates and initializes the factory so that is
	 * can be called by the REST service.
	 * <p/>
	 * @param pid		profile ID
	 * @param country	country code (optional)
	 * @param site		site number (optional)
	 * @param update	is this a create or update [boolean]
	 */
	public JobFactory(Long pid, String country, String site)
	{
		this.profileId = pid;
		this.countryCode = country;
		this.siteNumber = site;

		this.projectJobId = -1L;
		this.jobType = ProjectJobTypeEnum.CREATE.getValue();

		// default status and response message
		this.status = 0;
		this.message = "factory ready";
	}

	/**
	 * holds reference to the global scheduler created by the
	 * application container (servlet container)
	 * <p/>
	 * @param s 	reference to Quartz scheduler factory
	 */
	public static void setScheduler(StdSchedulerFactory s)
	{
		std = s;
	}

	/**
	 * assembles a new Create Job for the specified profile
	 * <p/>
	 * @param pid		study profile ID
	 * @param country	(optional) country code to be built
	 * @param site		(optional) site ID to be build, requires country
	 */
	public static void createCreateJob(Long pid, String country, String site)
	{
		JobFactory jf;

		logger.info("start create job");

		jf = new JobFactory(pid, country, site);
		if (site != null) {
			jf.setJobType( ProjectJobTypeEnum.SITE.getValue(), "build, site");
		}
		else {
			jf.setJobType( ProjectJobTypeEnum.COUNTRY.getValue(), "build, country");
		}

		jf.submit();

		logger.debug("CreateJob return");
	}


	/**
	 * Executes the job submission, once the input requirements
	 * are known. Status is stored here, so it can be returned as
	 * REST object
	 * <p/>
	 */
	public void submit()
	{
		int rc;

		// expect the worst
		status = -1;

		try {

			// did we get a valid number?
			if (profileId < 1) {
				addMessage("invalid profile number");
				return;
			}

			// create a new project job entry
			addProjectJob();
			if ( projectJobId < 1) {
				logger.error("create job could not find study profile ID {}", profileId);
				addMessage("could not find study profile ID " + profileId);
				return;
			}

			// is the quartz engine available?
			if (std == null) {
				logger.error("Quartz factory not initialized");
				addMessage("Quartz factory not initialized");
				return;
			}

			// schedule the appropriate job run with Quartz
			if ( this.jobType == ProjectJobTypeEnum.CHECK.getValue() ) {
				rc = schedule( CheckJob.class );
			}
			else {
				rc = schedule( CreateJob.class );
			}

			// did it schedule?
			if ( rc != 0) {
				addMessage("scheduler error");
			}
			else {
				addMessage("OK");
				status = 0;
			}
		}
		catch (SchedulerException se) {
			logger.error("create job schedule error", se);
			addMessage("scheduler error");
		}
		catch (Exception e) {
			logger.error("create job unforeseen problem", e);
			addMessage("bad problem, check the logs");
		}

		return;
	}

	/**
	 * accesses the Quartz engine (standard schedule factory) to
	 * create a run request and start trigger for the
	 * defined job class
	 * </p>
	 * @param jClass		class information for the build job
	 * @param pid 			the study profile ID number
	 * @param jid			the project job Id number
	 * @param country		(optional) country code
	 * @param site			(optional) site ID
	 * @return 		0
	 * @throws 		SchedulerException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private int schedule(Class jClass)
					throws SchedulerException
	{
		JobDetail job;
		Trigger trigger;
		Scheduler sched;

		// scheduler accessed from servlet context; KEY configured in web.xml
		sched = std.getScheduler();

		// compute time that is the next round minute
		logger.info("run time is {} minutes in future", delay);
		Date scheduleTime = futureDate(delay, DateBuilder.IntervalUnit.MINUTE);

		// define job based on EEL structure job
		// the PROJECT_JOB_ID will be used to identify the Quartz job
		logger.info("build job, type: {}", jClass.getCanonicalName());
		job = newJob( jClass )
				.withIdentity("EJ-" + projectJobId, "EEL3")
				.storeDurably( true )
				.build();

		// set run parameters, all we need is the job record id
		job.getJobDataMap().put("PROJECT_JOB_ID", projectJobId);
		job.getJobDataMap().put("PROFILE_ID", profileId);
		job.getJobDataMap().put("COUNTRY_CODE", countryCode);
		job.getJobDataMap().put("SITE_NUMBER", siteNumber);
		job.getJobDataMap().put("DATA_ID", dataid);

		// trigger job to run
		trigger = newTrigger()
				.withIdentity("ET-" + projectJobId, "EEL3")
				.startAt(scheduleTime)
				.build();

		// tell quartz to schedule job using our trigger
		sched.scheduleJob(job, trigger);
		logger.info("{} will run at: {}", job.getKey(), scheduleTime);
		logger.info("schedule complete");

		return 0;
	}

	/**
	 * creates the E3_PROJECT_JOB record that will be used for
	 * actual task execution
	 * </p>
	 */
	private void addProjectJob()
	{
		ApplicationContext sc;
		StudyProfileDAO studyProfileDAO_;
		ProjectJobDAO projectJobDAO_;

		ProjectJob pj;
		StudyProfile sp;

		// manual DAO injection
		sc = EelRequest.getSpringContext();
		studyProfileDAO_ = sc.getBean(StudyProfileDAO.class);
		projectJobDAO_ = sc.getBean(ProjectJobDAO.class);

		sp = studyProfileDAO_.findById( profileId );
		if ( sp == null ){
			return;
		}
		pj = new ProjectJob();
		pj.setProfileId( profileId );
		pj.setTemplateId( sp.getTemplateId() );

		pj.setStatus( ProjectJobStatusEnum.PENDING );
		for ( ProjectJobTypeEnum en : ProjectJobTypeEnum.values() ) {
			if (en.getValue() == jobType) {
				pj.setJobType( en );
			}
		}

		pj.setStatusMessage("Job Registered.");
		pj.setRequestTime( new Date() );
		{
			String user;

			user = sp.getTransUser();
			if ( user.contains("\\") ){
				user = user.split("\\\\")[1];
			}
			pj.setTransUser( user );
		}

		pj = projectJobDAO_.insert( pj );
		logger.info("added project job number: {}", pj.getProjectJobId());

		projectJobId = pj.getProjectJobId();
		return;
	}

	/**
	 * accessors
	 */
	public Long getProjectJobId()
	{ return projectJobId; }
	public void setProjectJobId(Long projectJobId)
	{
		this.projectJobId = projectJobId;
	}

	public Long getProfileId()
	{ return profileId; }
	public void setProfileId(Long profileId)
	{
		this.profileId = profileId;
	}

	public String getCountryCode()
	{ return countryCode; }
	public void setCountryCode(String countryCode)
	{
		this.countryCode = countryCode;
	}

	public String getSiteNumber()
	{ return siteNumber; }
	public void setSiteNumber(String siteNumber)
	{
		this.siteNumber = siteNumber;
	}

	public int getStatus()
	{ return status; }
	public void setStatus(int status)
	{
		this.status = status;
	}

	public String getMessage()
	{ return message; }
	public void setMessage(String message)
	{
		this.message = message;
	}
	public void addMessage(String message)
	{
		this.message += "; " + message;
	}

	public int getJobType()
	{ return jobType; }
	public void setJobType(int jobType, String msg)
	{
		this.jobType = jobType;
		addMessage(msg);

	}

	public Long getDataid()
	{
		return dataid;
	}

	public void setDataid(Long dataid)
	{
		this.dataid = dataid;
	}


}
