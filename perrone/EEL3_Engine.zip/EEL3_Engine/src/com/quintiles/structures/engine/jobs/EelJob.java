package com.quintiles.structures.engine.jobs;

import java.util.Date;


/**
 * public interface for jobs that are scheduled and managed
 * by the EEL3 engine
 *
 * @author John Shoun, Quintiles (q766769)
 * @version $Revision$
 */
public interface EelJob
{

	public Long getProfileId();
	public Long getJobId();
	public String getStatus();
	public String getDescription();
	public Date getStartTime();
	public Date getEndTime();

}
