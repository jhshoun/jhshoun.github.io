package com.quintiles.structures.engine;

import org.quartz.DateBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import static org.quartz.DateBuilder.futureDate;
import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.quintiles.e3.data.dao.ProjectJobDAO;
import com.quintiles.e3.data.dao.model.ProjectJob;
import com.quintiles.e3.data.dao.model.nodb.ProjectJobStatusEnum;
import com.quintiles.e3.data.dao.model.nodb.ProjectJobTypeEnum;
import com.quintiles.structures.EelRequest;
import com.quintiles.structures.engine.jobs.CTMSUpdateJob;


/**
 * Manages the site batch update job. Only one of these
 * jobs exists in the scheduler. It is a permanent trigger
 * that repeats on a defined schedule. 
 * <p/>
 * The Site Batch Factory is implemented as a REST service.
 * <p/>
 * @author John Shoun, Quintiles
 * @version $Revision: 908 $
 */
@XmlRootElement(name = "CloudCTMSBatch")
@XmlAccessorType(XmlAccessType.FIELD)
public class CTMSJobFactory extends QuartzFactory
{
	// class variables
	private static Logger logger = LoggerFactory.getLogger(CTMSJobFactory.class);
	private static final int delay = 1; 		// number of minutes to wait for run

	// REST service elements
	@XmlElement(name="jobId")
	private Long projectJobId;
	@XmlElement(name="profileId")
	private Long profileId;

	@XmlElement(name="type")
	private int jobType;

	/**
	 * No-arg constructor, required for REST service
	 */
	public CTMSJobFactory()
	{

		// default status and response message
		this.userId = "SYSTEM";
		this.jobName = "ctms_update";
		this.groupName = "WS_CLOUD";

		this.profileId = -2L;
		this.projectJobId = -1L;
		this.jobType = ProjectJobTypeEnum.CTMS_UPDATE.getValue();

		// default status and response message
		this.status = 0;
		this.message = "factory ready";
	}


	/**
	 * Executes the job submission, once the input requirements
	 * are known. Status is stored here, so it can be returned as
	 * REST object
	 * <p/>
	 */
	public void submit()
	{
		// expect the worst
		status = -1;

		try {

			// create a new project job entry
			addCTMSJob();
			if ( projectJobId < 1) {
				logger.error("create CTMS job failed");
				addMessage("could not create CTMS update job");
				return;
			}

			// is the quartz engine available?
			if (std == null) {
				logger.error("Quartz factory not initialized");
				addMessage("Quartz factory not initialized");
				return;
			}

			// schedule the appropriate job run with Quartz
			// did it schedule?
			if ( singleSchedule( CTMSUpdateJob.class ) != 0) {
				addMessage("scheduler error");
			}
			else {
				addMessage("OK");
				status = 0;
			}
		}
		catch (SchedulerException se) {
			logger.error("ctms job schedule error", se);
			addMessage("scheduler error");
		}
		catch (Exception e) {
			logger.error("ctms job unforeseen problem", e);
			addMessage("bad problem, check the logs");
		}

		return;
	}


	/**
	 * accesses the Quartz engine (standard schedule factory) to
	 * create a run request and start trigger for the 
	 * defined job class
	 * </p>
	 * @param jClass		class information for the build job
	 * @return 		0
	 * @throws 		SchedulerException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private int singleSchedule(Class jClass) throws SchedulerException
	{
		JobDetail job;
		Trigger trigger;
		Scheduler sched;

		// scheduler accessed from servlet context; KEY configured in web.xml
		sched = std.getScheduler();

		// computer a time that is on the next round minute
		logger.info("run time is {} minutes in future", delay);
		Date scheduleTime = futureDate(delay, DateBuilder.IntervalUnit.MINUTE);

		// define job based on EEL structure job
		// the PROJECT_JOB_ID will be used to identify the Quartz job
		logger.info("health job, type: {}", jClass.getCanonicalName());
		job = newJob( jClass )
				.withIdentity("WS-" + projectJobId, "WS-HEALTH")
				.storeDurably( true )
				.build();

		// set run parameters, all we need is the job record id
		job.getJobDataMap().put("PROJECT_JOB_ID", projectJobId);
		job.getJobDataMap().put("PROFILE_ID", profileId);

		// trigger job to run
		trigger = newTrigger()
				.withIdentity("ET-" + projectJobId, "CTMS_UPDATE")
				.startAt(scheduleTime)
				.build();

		// tell quartz to schedule job using our trigger
		sched.scheduleJob(job, trigger);
		logger.info("{} will run at: {}", job.getKey(), scheduleTime);
		logger.info("schedule complete");

		return 0;
	}


	/**
	 * Executes the job submission, once the input requirements
	 * are known. Status is stored here, so it can be returned as
	 * REST object
	 * <p/>
	 */
	public void updateSchedule()
	{
		// expect the worst
		status = -1;

		// verify initialization
		if (std == null) {
			logger.error("Quartz factory not initialized");
			addMessage("Quartz factory not initialized");
			return;
		}

		// schedule the run with Quartz
		try {

			// if disabled, we will remove the trigger and return
			if ( !isEnabled("health") ) {
				this.removeSchedule("health");
				addMessage("cron schedule trigger removed");
				status = 0;
				return;
			}

			// update the schedule
			if ( schedule( CTMSUpdateJob.class, "health" ) != 0) {
				addMessage("scheduler error");
				status = -1;
			}
			else {
				addMessage("OK, schedule updated");
				status = 0;
			}
		}
		catch (SchedulerException se) {
			logger.error("CTMS update job schedule error", se);
			addMessage("scheduler error");
			status = -1;
		}
		catch (Exception e) {
			logger.error("HealthUpdateJob unforeseen problem", e);
			addMessage("bad problem, check the logs");
			status = -1;
		}

		return;
	}


	/**
	 * creates the E3_PROJECT_JOB record that will be used for 
	 * actual task execution
	 * </p>
	 */
	private void addCTMSJob()
	{
		ApplicationContext sc;
		ProjectJobDAO projectJobDAO_;

		ProjectJob pj;

		// manual DAO injection
		sc = EelRequest.getSpringContext();
		projectJobDAO_ = sc.getBean(ProjectJobDAO.class);

		pj = new ProjectJob();
		pj.setProfileId( profileId );
		pj.setTemplateId( -1L );

		pj.setStatus( ProjectJobStatusEnum.PENDING );
		for ( ProjectJobTypeEnum en : ProjectJobTypeEnum.values() ) {
			if (en.getValue() == jobType) {
				pj.setJobType( en );
			}
		}

		pj.setStatusMessage("Job Registered.");
		pj.setRequestTime( new Date() );
		pj.setTransUser( "SYSTEM" );

		pj = projectJobDAO_.insert( pj );
		logger.info("added project job number: {}", pj.getProjectJobId());

		projectJobId = pj.getProjectJobId();
		return;
	}


	/*
	 * accessors
	 */

	public Long getProfileId()
	{ return profileId; }
	public void setProfileId(Long profileId)
	{
		this.profileId = profileId;
	}

	public int getJobType()
	{ return jobType; }
	public void setJobType(int jobType, String msg)
	{
		this.jobType = jobType;
		addMessage(msg);

	}

}
