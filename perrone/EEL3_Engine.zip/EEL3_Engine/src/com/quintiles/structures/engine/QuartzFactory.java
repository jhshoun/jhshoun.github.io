package com.quintiles.structures.engine;

import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;
import static org.quartz.JobKey.jobKey;
import static org.quartz.TriggerKey.triggerKey;
import static org.quartz.CronScheduleBuilder.cronSchedule;

import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.TriggerKey;
import org.quartz.impl.StdSchedulerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import com.quintiles.structures.engine.utility.Configuration;

/**
 * generic job factory that manages Quartz schedules
 * <p/>
 * @author John Shoun, Quintiles
 * @version $Revision: 908 $
 */

@XmlAccessorType(XmlAccessType.FIELD)
public abstract class QuartzFactory
{
	// class variables
	private static Logger logger = LoggerFactory.getLogger("com.quintiles.structures.engine.QuartzJobFactory");
	protected static StdSchedulerFactory std;
	protected String jobName = "jobName";
	protected String groupName = "groupName";
	private Configuration _configuration = new Configuration();

	// REST service elements
	@XmlElement
	protected String userId;
	@XmlElement
	protected int status;
	@XmlElement
	protected String message;

	/**
	 * No-arg constructor, required for REST service
	 */
	public QuartzFactory()
	{

		// default status and response message
		this.status = 0;
	}


	/**
	 * holds reference to the global scheduler created by the
	 * application container (servlet container)
	 * <p/>
	 * @param s 	reference to Quartz scheduler factory
	 */
	public static void setScheduler(StdSchedulerFactory s)
	{
		std = s;
	}

	/**
	 * Executes the job submission, once the input requirements
	 * are known. Status is stored here, so it can be returned as
	 * REST object
	 * <p/>
	 */
	public abstract void updateSchedule();



	/**
	 * accesses the Quartz engine (standard schedule factory) to
	 * create or replace the permanent CRON trigger 
	 * </p>
	 * @param jClass	class information for the build job
	 * @param key		properties prefix to identify schedule
	 * @return 			0
	 * @throws 			SchedulerException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	protected final int schedule(Class jClass, String key) throws SchedulerException
	{
		JobDetail job;
		CronTrigger trigger;
		Scheduler sched;
		String schedulePattern;

		// scheduler accessed from servlet context, KEY configured in web.xml
		sched = std.getScheduler();
		removeSchedule(key);

		// define job based on EEL structure job
		// the PROJECT_JOB_ID will be used to identify the Quartz job
		logger.info("build job, type: {}", jClass.getCanonicalName());
		job = newJob( jClass )
				.withIdentity(jobName, groupName)
				.storeDurably( true )
				.build();

		// set run parameters, all we need is the user ID requesting update
		job.getJobDataMap().put("USER_ID", userId);
		sched.addJob(job, true);

		// trigger job to run
		schedulePattern = getSchedule(key);
		trigger = newTrigger()
				.withIdentity(jobName, groupName)
				.withSchedule( cronSchedule(schedulePattern) )
				.forJob( jobKey(jobName, groupName) )
				.build();

		// tell quartz to schedule job using our trigger
		sched.scheduleJob(trigger);

		logger.info("cron schedule for {} complete ({})", key, schedulePattern);

		return 0;
	}

	/**
	 * removes the quartz schedule trigger
	 * <p/>
	 * @throws SchedulerException 
	 */
	protected final void removeSchedule(String key) throws SchedulerException
	{
		Scheduler sched;
		TriggerKey tk;

		sched = std.getScheduler();
		tk = triggerKey(jobName, groupName);
		if (tk == null) {
			status = 0;
			return;
		}

		sched.unscheduleJob( tk );
		status = 0;
		return;
	}


	/**
	 * go to EEL configuration and get the schedule,
	 * assemble into CRON string 
	 * </p>
	 */
	private String getSchedule(String key)
	{
		String[] days = { "SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT" };
		String[] hours = { "0", "1", "2", "3", "4", "5", 
							"6", "7", "8", "9", "10", "11", 
							"12", "13", "14", "15", "16", "17", 
							"18", "19", "20", "21", "22", "23" };
		String[] minutes = { "0", "10", "20", "30", "40", "50" };
		String schedulePattern;

		// seconds
		schedulePattern = "0 ";

		// get the schedules
		// minutes
		schedulePattern += mapper(key + ".update.schedule.minute", minutes) + " ";

		// hours
		schedulePattern += mapper(key + ".update.schedule.hour", hours) + " ";

		// any day-of-month, any month
		schedulePattern += " ? * ";

		// days of week
		schedulePattern += mapper(key + ".update.schedule.day", days);

		return schedulePattern;
	}

	/**
	 * checks the db configuration to see if the
	 * schedule should be active 
	 * </p>
	 */
	protected final boolean isEnabled(String key)
	{
		Boolean enabled;

		// is this enabled?
		enabled = _configuration.getConfigValue(key + ".update.schedule.enable").equals("1") ? true : false;

		return enabled;
	}

	private String mapper(String cfgId, String[] intervals)
	{
		String[] vals;
		String schedule = "";

		vals = _configuration.getConfigValue(cfgId).split(",");
		for (int i = 0; i < vals.length; ++i) {
			if ( vals[i].equals("1") ) {
				schedule += "," + intervals[i];
			}
		}

		// remove leader, trailing commas
		schedule = schedule.replaceAll("^,", "");
		schedule = schedule.replaceAll(",$", "");

		return schedule;
	}


	/**
	 * accessors
	 */
	public String getUserId()
	{ return userId; }
	public void setUserId(String userId)
	{
		this.userId = userId;
	}

	public int getStatus()
	{ return status; }
	public void setStatus(int status)
	{
		this.status = status;
	}

	public String getMessage()
	{ return message; }
	public void setMessage(String message)
	{
		this.message = message;
	}
	public void addMessage(String message)
	{
		this.message += "; " + message;
	}


}
