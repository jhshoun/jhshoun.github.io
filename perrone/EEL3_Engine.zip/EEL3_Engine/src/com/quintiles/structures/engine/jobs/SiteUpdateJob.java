package com.quintiles.structures.engine.jobs;

import java.util.Date;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.stereotype.Component;

import com.quintiles.e3.data.dao.ProjectJobDAO;
import com.quintiles.e3.data.dao.model.ProjectJob;
import com.quintiles.e3.data.dao.model.nodb.ProjectJobStatusEnum;
import com.quintiles.e3.data.dao.model.nodb.ProjectJobTypeEnum;
import com.quintiles.structures.builder.SiteUpdater;


/**
 * Supervisory job that scans for site data changes and initiates
 * tasks to update specific site structures.
 * <p>
 * @author John Shoun, Quintiles (q766769)
 * @version $Revision: 827 $
 */
@Configurable
@Component
public class SiteUpdateJob extends BaseJob
{
	private Logger logger = LoggerFactory.getLogger("com.quintiles.structures.engine.jobs.SiteUpdateJob");

	@Autowired
	private ProjectJobDAO projectJobDAO_;

	/**
	 * Empty constructor for job initialization
	 * <p/>
	 * Quartz requires a public empty constructor so that the scheduler can
	 * instantiate the class whenever it needs.
	 */
	public SiteUpdateJob()
	{
		//NOOP
	}

	/**
	 * default procedure called by Quartz, we are overriding
	 * the base job because we don't need/have regular build data
	 * <p/>
	 */
	@Override
	public void execute(JobExecutionContext context)
									throws JobExecutionException
	{
//		JobDataMap data = context.getMergedJobDataMap();

		// get the "user" that requested the job (usually "SYSTEM")
//		if ( data.containsKey("USER_ID") ) {
//			MDC.put("userId", "" + data.getString("USER_ID") );
//		}

		logger.info("starting batch site job execution");

		try {
			localExecute();
		}
		catch (Exception e){
			logger.error("site job execute failure", e);
		}

//		MDC.clear();
		logger.info("batch site job complete");
	}

	/**
	 * implementation of the batch site update job
	 * <p/>
	 */
	@Override
	public void localExecute()
	{
		SiteUpdater aWorkerBuilder;
		Long jobId;
		int rc;

		logger.debug("site update job execute start");

		// create the site update job record
		jobId = newSiteProjectJob();
		logger.debug("job id {}", jobId);

		// create update worker
		aWorkerBuilder = new SiteUpdater(jobId);
		aWorkerBuilder.jobStatus(ProjectJobStatusEnum.IN_PROGRESS, "running site update");

		// run the updates
		try {
			rc = aWorkerBuilder.applyUpdates();

			if (rc == -1) {
				aWorkerBuilder.jobStatus(ProjectJobStatusEnum.ERROR, "update failed");
			}
			else {
				aWorkerBuilder.jobStatus(ProjectJobStatusEnum.COMPLETED, "successful update");
			}
		}
		catch (Exception e) {
			aWorkerBuilder.jobStatus(ProjectJobStatusEnum.ERROR, "Failed [exception - " + e.getMessage() + "]");
			logger.error("site update job fail", e);
		}

		logger.debug("site update job execute end");
	}

	/**
	 * creates the E3_PROJECT_JOB record that will be used for 
	 * actual site update task
	 * </p>
	 */
	private Long newSiteProjectJob()
	{
		ProjectJob pj;

		pj = new ProjectJob();
		pj.setTemplateId( -1L );
		pj.setProfileId( -1L );

		pj.setStatus( ProjectJobStatusEnum.PENDING );
		pj.setJobType(ProjectJobTypeEnum.SITE_UPDATE);

		pj.setStatusMessage("Job Registered.");
		pj.setRequestTime( new Date() );

		pj = projectJobDAO_.insert( pj );
		logger.info("added project job number: {}", pj.getProjectJobId());

		return pj.getProjectJobId();
	}

}
