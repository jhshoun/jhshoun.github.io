package com.quintiles.structures.engine;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;


/**
 * Handles requests for eTMF (DIA) folders.
 * The user requests an artifact based on the zone,
 * section, artifact. If the artifact exists, then the
 * ID is returned, otherwise it is created just-in-time.
 * <p/>
 * The Folder Factory is implemented as a REST service.
 * <p/>
 * @author John Shoun, Quintiles
 * @version $Revision$
 */
@Path("/folder")
@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
public class FolderService
{

	@POST
	@Path("/request")
	@Consumes( MediaType.APPLICATION_FORM_URLENCODED )
	public FolderFactory getFolderFactory(MultivaluedMap<String, String> params)
	{
		FolderFactory ff;

		ff = new FolderFactory();
		ff.setCustomer( params.getFirst("customer") );
		ff.setProject( params.getFirst("project") );
		ff.setProtocol( params.getFirst("protocol") );

		ff.setCountryCode( params.getFirst("country") );
		ff.setSiteNumber( params.getFirst("site") );

		// get the artifact parameters
		ff.setZone( params.getFirst("zone") );
		ff.setSection( params.getFirst("section") );
		ff.setArtifact( params.getFirst("artifact") );

		// submit the request
		ff.submit();

		// return the result
		return ff;
	}

	@POST
	@Path("/xlate")
	@Consumes( MediaType.APPLICATION_FORM_URLENCODED )
	@Produces( MediaType.TEXT_PLAIN )
	public String getLegacyFolder(MultivaluedMap<String, String> params)
	{
		LegacyTranslate xlate;
		String[] dia;

		xlate = new LegacyTranslate();

		// look up return result
		dia = xlate.xlate(
						params.getFirst("class"), 
						params.getFirst("group"), 
						params.getFirst("type"), 
						params.getFirst("subtype"),
						params.getFirst("report"));
		// did we find anything?
		if (dia.length == 0) {
			return "NULL";
		}

		// return includes a default doc name abbreviation
		return dia[0] + "|" + dia[1] + "|" + dia[2] + "|" + dia[3] + "|" + dia[4];
	}

}
