package com.quintiles.structures.db;

import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.OracleTypes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.jdbc.core.ColumnMapRowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

public class DbPackage extends StoredProcedure
{
	private Logger logger = LoggerFactory.getLogger("com.quintiles.structures.engine.jobs.BaseJob");

	private Input[] parms;
	private String qSql;

	//add default constructor so we do not need to invoke spring 
	// StoredProcedure class during the junit testing
	// TODO implement spring JUnit4 test
	public DbPackage()
	{
		// noop
	}

	// constructor
	public DbPackage(String sql)
	{
		super(SQLFactory.getDS(), sql);

		qSql = sql;
		setFunction(false);
	}

	// defines the input parameters and compiles the request
	protected void init(Input[] qParms)
	{
		SqlParameter sp;

		this.parms = qParms;
		for (int i = 0; i < parms.length; ++i) {
			sp = new SqlParameter(parms[i].argument, parms[i].dataType);
			declareParameter( sp );
		}

		declareParameter(new SqlOutParameter("result", OracleTypes.CURSOR, new ColumnMapRowMapper() ));
		compile();
	}

	// executes the query
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<Map<String, Object>> run(Object... args)
	{
		Map in, out;
		String log = "SQL request: " + qSql;

		in = new HashMap();
		for (int i = 0; i < parms.length; ++i) {
			if (i < args.length) {
				in.put(parms[i].argument, args[i]);
			}
			else {
				in.put(parms[i].argument, null);
			}
			log += ", " + parms[i].argument + " - {}";
		}

		logger.debug(log, args);

		out = execute(in);
		if (out.isEmpty())
			return null;

		return (List<Map<String, Object>>) out.get("result");
	}


	// internal structure for mapping procedure inputs 
	private static class Input
	{
		public String argument;
		public int dataType;

		// this may be useful in future
		@SuppressWarnings("unused")
		public String type;

		public Input(String arg, int dtype, String theClass)
		{
			argument = arg;
			dataType = dtype;
			type = theClass;
		}
	}


	/*----------------------------------------------------------------------------------
		specific package implementations
	----------------------------------------------------------------------------------*/
	// getTier
	public static class GetTier extends DbPackage
	{
		private static final String sql = "ENGINE.getTier";

		private Input[] parms = {
								new Input("templateId",  Types.NUMERIC, "Integer"),
								new Input("class",       Types.NUMERIC, "Integer")
							};

		public GetTier()
		{
			super( sql );
			this.init( parms );
		}
	}

	// get parent object list
	public static class GetParentList extends DbPackage
	{
		private static final String sql = "ENGINE.getParentList";

		private Input[] parms = {
								new Input("folderId",   Types.NUMERIC, "Integer")
							};

		public GetParentList()
		{
			super( sql );
			this.init( parms );
		}
	}

	// get navigation permissions
	public static class GetNavigators extends DbPackage
	{
		private static final String sql = "ENGINE.getNavigators";

		private Input[] parms = {
								new Input("templateId",   Types.NUMERIC, "Integer")
							};

		public GetNavigators()
		{
			super( sql );
			this.init( parms );
		}
	}

	// get JIT artifact information
	public static class GetJITRecord extends DbPackage
	{
		private static final String sql = "ENGINE.getJITRecord";

		private Input[] parms = {
								new Input("templateId",  Types.NUMERIC, "Integer"),
								new Input("class",       Types.NUMERIC, "Integer"),
								new Input("zone",        Types.VARCHAR, "String"),
								new Input("section",     Types.VARCHAR, "String"),
								new Input("artifact",    Types.VARCHAR, "String")
							};

		public GetJITRecord()
		{
			super( sql );
			this.init( parms );
		}
	}

	// list of groups to create
	public static class CreateGroups extends DbPackage
	{
		private static final String sql = "ENGINE.createGroups";

		private Input[] parms = {
								new Input("templateId",  Types.NUMERIC, "Integer")
							};

		public CreateGroups()
		{
			super( sql );
			this.init( parms );
		}
	}

	// get group membership
	public static class GetGroupMembers extends DbPackage
	{
		private static final String sql = "ENGINE.getGroupMembers";

		private Input[] parms = {
								new Input("templateId",  Types.NUMERIC, "Integer")
							};

		public GetGroupMembers()
		{
			super( sql );
			this.init( parms );
		}
	}

	// get group leaders
	public static class GetGroupLeaders extends DbPackage
	{
		private static final String sql = "ENGINE.getGroupLeaders";

		private Input[] parms = {
								new Input("templateId",  Types.NUMERIC, "Integer")
							};

		public GetGroupLeaders()
		{
			super( sql );
			this.init( parms );
		}
	}

	// get list of folders to build
	public static class GetFolderList extends DbPackage
	{
		private static final String sql = "ENGINE.getFolderList";

		private Input[] parms = {
								new Input("templateId",  Types.NUMERIC, "Integer"),
								new Input("class",       Types.NUMERIC, "Integer"),
								new Input("all",         Types.NUMERIC, "Integer")
							};

		public GetFolderList()
		{
			super( sql );
			this.init( parms );
		}
	}

	// permissions for an artifact
	public static class GetArtifactPermissions extends DbPackage
	{
		private static final String sql = "ENGINE.getArtifactPermissions";

		private Input[] parms = {
								new Input("folderId",    Types.NUMERIC, "Integer"),
								new Input("class",       Types.NUMERIC, "Integer"),
								new Input("templateId",  Types.NUMERIC, "Integer")
							};

		public GetArtifactPermissions()
		{
			super( sql );
			this.init( parms );
		}
	}

	// unblinded permissions for an artifact
	public static class GetUnblindedPermissions extends DbPackage
	{
		private static final String sql = "ENGINE.getUnblindedPermissions";

		private Input[] parms = {
								new Input("folderId",    Types.NUMERIC, "Integer"),
								new Input("class",       Types.NUMERIC, "Integer"),
								new Input("templateId",  Types.NUMERIC, "Integer")
							};

		public GetUnblindedPermissions()
		{
			super( sql );
			this.init( parms );
		}
	}

	// get project information
	public static class GetProjectData extends DbPackage
	{
		private static final String sql = "ENGINE.getProjectData";

		private Input[] parms = {
								new Input("customer",  Types.VARCHAR, "String"),
								new Input("project",   Types.VARCHAR, "String"),
								new Input("protocol",  Types.VARCHAR, "String")
							};

		public GetProjectData()
		{
			super( sql );
			this.init( parms );
		}
	}

	// find the customer folder
	public static class GetCustomerFolder extends DbPackage
	{
		private static final String sql = "ENGINE.getCustomerFolder";

		private Input[] parms = {
								new Input("cust_code",  Types.VARCHAR, "String")
							};

		public GetCustomerFolder()
		{
			super( sql );
			this.init( parms );
		}
	}

	// get name for a given country code
	public static class GetCountryName extends DbPackage
	{
		private static final String sql = "ENGINE.getCountryName";

		private Input[] parms = {
								new Input("country_code",  Types.VARCHAR, "String")
							};

		public GetCountryName()
		{
			super( sql );
			this.init( parms );
		}
	}

	// find site updates
	public static class FindSiteUpdates extends DbPackage
	{
		private static final String sql = "ENGINE.findSiteUpdates";

		private Input[] parms = {
							};

		public FindSiteUpdates()
		{
			super( sql );
			this.init( parms );
		}
	}

	// get changes for a given site
	public static class GetSiteChanges extends DbPackage
	{
		private static final String sql = "ENGINE.getSiteChanges";

		private Input[] parms = {
								new Input("hist_id",  Types.NUMERIC, "Integer"),
								new Input("ctms_id",  Types.VARCHAR, "String")
							};

		public GetSiteChanges()
		{
			super( sql );
			this.init( parms );
		}
	}

	// get site data
	public static class GetSiteData extends DbPackage
	{
		private static final String sql = "ENGINE.getSiteData";

		private Input[] parms = {
								new Input("project",   Types.VARCHAR, "String"),
								new Input("protocol",  Types.VARCHAR, "String"),
								new Input("site",      Types.VARCHAR, "String")
							};

		public GetSiteData()
		{
			super( sql );
			this.init( parms );
		}
	}

	// get site status
	public static class GetSiteStatusConfig extends DbPackage
	{
		private static final String sql = "ENGINE.getSiteStatusConfig";

		private Input[] parms = {
								new Input("cfg",   Types.VARCHAR, "String")
							};

		public GetSiteStatusConfig()
		{
			super( sql );
			this.init( parms );
		}
	}

	// looks through a CS10 folder for a site object
	public static class FindCS10Site extends DbPackage
	{
		private static final String sql = "ENGINE.findCS10Site";

		private Input[] parms = {
								new Input("folder",    Types.NUMERIC, "Integer"),
								new Input("project",   Types.VARCHAR, "String"),
								new Input("protocol",  Types.VARCHAR, "String"),
								new Input("site",      Types.VARCHAR, "String")
							};

		public FindCS10Site()
		{
			super( sql );
			this.init( parms );
		}
	}

	// scan audit trail to find any errors for a given job ID
	public static class JobErrors extends DbPackage
	{
		private static final String sql = "ENGINE.getJobErrorCount";

		private Input[] parms = {
								new Input("job_id",      Types.NUMERIC, "Integer")
							};

		public JobErrors()
		{
			super( sql );
			this.init( parms );
		}
	}

	// translate legacy ELVIS to DIA model (used by CTMS)
	public static class LegacyXlate extends DbPackage
	{
		private static final String sql = "ENGINE.legacyCGTSxlate";

		private Input[] parms = {
								new Input("class",       Types.VARCHAR, "String"),
								new Input("group",       Types.VARCHAR, "String"),
								new Input("type",        Types.VARCHAR, "String"),
								new Input("subtype",     Types.VARCHAR, "String"),
								new Input("report_name", Types.VARCHAR, "String")
							};

		public LegacyXlate()
		{
			super( sql );
			this.init( parms );
		}
	}

	// get all study profiles for HEALTH transfer
	public static class GetHealthStudies extends DbPackage
	{
		private static final String sql = "ENGINE.getHealthStudies";

		private Input[] parms = {
							};

		public GetHealthStudies()
		{
			super( sql );
			this.init( parms );
		}
	}

	// get CTMS data for transmission to Wingspan
	public static class GetCtmsData extends DbPackage
	{
		private static final String sql = "ENGINE.getCTMSdata";

		private Input[] parms = {
								new Input("dataset",     Types.VARCHAR, "String"),
								new Input("profile_id",  Types.NUMERIC, "Integer")
							};

		public GetCtmsData()
		{
			super( sql );
			this.init( parms );
		}
	}

	// procedures to manage the Wingspan build status
	/**
	 * The "Get All" procedure works in two ways. The profile_id
	 * is an optional input. If it is omitted, then all status rows
	 * will be returned. If the profile_id is provided, then only status
	 * for that study (all core, country, site records) will be returned.
	 * @author q766769
	 *
	 */
	public static class GetAllWingspanStatus extends DbPackage
	{
		private static final String sql = "ENGINE.getAllWingspanStatus";

		private Input[] parms = {
								new Input("profile_id",  Types.NUMERIC, "Integer")
							};

		public GetAllWingspanStatus()
		{
			super( sql );
			this.init( parms );
		}
	}

	/**
	 * This operation is an "up-sert", it performs an insert or update
	 * depending on whether the row already exists.
	 * 
	 * @author q766769
	 *
	 */
	public static class SetWingspanStatus extends DbPackage
	{
		private static final String sql = "ENGINE.setWingspanStatus";

		private Input[] parms = {
								new Input("profile_id",    Types.NUMERIC, "Integer"),
								new Input("class_name",    Types.VARCHAR, "String"),
								new Input("country_code",  Types.VARCHAR, "String"),
								new Input("site_id",       Types.VARCHAR, "String"),
								new Input("ctms_transfer", Types.NUMERIC, "Integer"),
								new Input("build_status",  Types.NUMERIC, "Integer"),
								new Input("ws_id",         Types.VARCHAR, "String")
							};

		public SetWingspanStatus()
		{
			super( sql );
			this.init( parms );
		}
	}
}
