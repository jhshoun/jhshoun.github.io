package com.quintiles.structures.db;

import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.jdbc.core.JdbcTemplate;


/**
 * SQL Factory, temp for generating development queries
 */
public class SQLFactory
{
	private static Logger logger = LoggerFactory.getLogger("com.quintiles.structures.engine.jobs.BaseJob");

	private String query = "";
	private static String dsName; 

//	@Autowired
//	@Resource
//	protected DataSource eel3Datasource;

	// empty constructor
	public SQLFactory()
	{
	}

	public List<Map<String, Object>> execute()
	{
		List<Map<String, Object>> rows = null;

		rows = this.execute( null );
		return rows;
	}

	// execute a SQL string with argument array
	public List<Map<String, Object>> execute(Object[] args)
	{
		JdbcTemplate jt;
		List<Map<String, Object>> rows = null;

		logger.debug("running SQL [{}]", query);

		// run query and return rows
		jt = new JdbcTemplate( getDS() );
		rows = jt.queryForList( query, args );

		logger.debug("{} rows returned", rows.size() );

		return rows;
	}

	// get the named data source
	public static DataSource getDS()
	{
		Context initContext;
		Context envContext;
		DataSource ds = null;

		// look up data source name if missing
		if ( dsName == null ) {
			Configuration rb;

			try {
				rb = new PropertiesConfiguration("application.properties");
				dsName = rb.getString( "commons.db.datasource" );
			}
			catch (ConfigurationException e) {
				logger.error("error getting datasource configuration", e);
			}
		}

		// ask context for the data source
		try {
			initContext = new InitialContext();

// test configuration
// TODO, see if this also works for production?? 
{
	Object foo = initContext.lookup("java:/comp/env/jdbc/eel3Datasource");
	if (foo != null) {
		return (DataSource) foo;
	}
}

			envContext  = (Context) initContext.lookup("java:/comp/env");
			ds = (DataSource) envContext.lookup("jdbc/" + dsName);
		}
		catch (NamingException ne) {
			logger.error("cannot find EEL3 datasource", ne);
		}
//		catch (Exception e) {
//			// NOOP
//		}

		return ds;
	}
	
}
