package com.quintiles.structures.builder;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opentext.api.LLValue;
import com.quintiles.lapi.Category;
import com.quintiles.lapi.Document;
import com.quintiles.structures.db.DbPackage;

/**
 * Site Updater
 * <p/>
 * Class responsible for updating metadata associated with
 * an existing site folder structure.
 * <p/>
 * The folders exist, but if attributes have been changed,
 * then the objects need to be updated.
 * <p/>
 * @author John Shoun, Quintiles
 * @version $Revision: 784 $
 */

public class SiteUpdater extends BaseBuilder
{
	protected Logger logger = LoggerFactory.getLogger("com.quintiles.structures.engine.jobs.SiteUpdateJob");

	private String siteId;
	private String siteName;
	private String siteStatus;
	private String investigatorName;
	private String countryCode;

	private Document doc;

	// superclass constructor
	public SiteUpdater(Long jobId)
	{
		this.initBuilder(-1L,  jobId);
		doc = new Document(llserver);
	}

	/**
	 * may not ever need to implement these abstract methods
	 */
	@Override
	public int buildContainer()
	{
		return 0;
	}
	@Override
	public int createContainer()
	{
		return 0;
	}

	/**
	 * Main execution loop. Runs queries to get sites
	 * that have been built and require updates. 
	 * <p/>
	 * @return	status (OK, ERR)
	 */
	public int applyUpdates()
	{
		List<Map<String, Object>> rs1;

		// get list of sites where history has updated
		rs1 = (new DbPackage.FindSiteUpdates()).run();

		// didn't find anything? quitin' time!
		if (rs1 == null) {
			logger.debug("site update job end (no updates required)");
			return 0;
		}

		// work to do, initiate an update for each record
		for (Map<String, Object> rec : rs1)
		{
			int did;
			String site;
			int hist;

			did = ((BigDecimal) rec.get("dataid")).intValue();
			site = (String) rec.get("ctms_id");
			hist = ((BigDecimal) rec.get("hist_id")).intValue();

			// create update worker
			logger.debug("updating site {}, dtree {}", site, did);
			this.updateContainer(did, site, hist);
		}

		return 0;
	}

	/**
	 * Special update to update on a single site.
	 * This is used prior to a site folder request.
	 * <p/>
	 * @param project		project code
	 * @param cc			country code
	 * @param site			site number
	 * @return	status (OK, ERR)
	 */
	public int applySiteUpdate(String project, String cc, String site)
	{
		List<Map<String, Object>> rs1;

		// get list of sites where history has updated
		rs1 = (new DbPackage.FindSiteUpdates()).run();

		// nothing? done!
		if (rs1 == null) {
			return 0;
		}

		// work to do, initiate an update for each record
		for (Map<String, Object> rec : rs1)
		{
			int did;
			String ctms_id;
			int hist;

			// does this match the request?
			if ( !((String) rec.get("project_code")).equals(project) )
				continue;
			if ( !((String) rec.get("site_country_code")).equalsIgnoreCase(cc) )
				continue;
			if ( !((String) rec.get("site_number")).equalsIgnoreCase(site) )
				continue;

			// proceed with the update
			did = ((BigDecimal) rec.get("dataid")).intValue();
			ctms_id = (String) rec.get("ctms_id");
			hist = ((BigDecimal) rec.get("hist_id")).intValue();

			// create update worker
			logger.debug("updating site {}, dtree {}", ctms_id, did);
			return this.updateContainer(did, ctms_id, hist);
		}

		return 0;
	}

	/**
	 * This is the main routine for updating the attributes
	 * for a specified site object.
	 * The process is to get the data used to build the
	 * site and compare with the latest site record.
	 * Any changes are then pushed to the site and
	 * affected child objects.
	 * <p/>
	 * @param ll_id		Livelink object ID to update
	 * @param ctmsId	CTMS site ID
	 * @param histId	history table ID
	 * @return	status (OK, ERR)
	 */
	public int updateContainer(int ll_id, String ctmsId, int histId)
	{
		List<Map<String, Object>> rs1;
		LLValue objectInfo;
		String folderName;
		int newHistId;
		int rc;
		boolean changed;

		// get the site history data (current and latest for this site)
		rs1 = (new DbPackage.GetSiteChanges()).run(new Long(histId), ctmsId);
		if (rs1 == null || rs1.size() != 2) {
			logger.error("could not find history changes for {}", ctmsId);
			return -1;
		}

		try {
			// map fields
			countryCode = (String) rs1.get(0).get("site_country_code");
			siteId = (String) rs1.get(1).get("site_number");
			siteName = (String) rs1.get(1).get("site_name");
			siteStatus = (String) rs1.get(1).get("site_status");
			investigatorName = (String) rs1.get(1).get("principal_inv_last") 
									+ ", " 
									+ (String) rs1.get(1).get("principal_inv_first");
			folderName = SiteBuilder.getSiteFolderName(countryCode, siteId, investigatorName, siteName);

			newHistId = ((BigDecimal) rs1.get(1).get("hist_id")).intValue();

			// update the folder name, site status, and hist_id record
			objectInfo = new LLValue();

			objectInfo.setAssocNotSet();
			objectInfo.add("Name", folderName);
			objectInfo.add("ExAtt1", SiteBuilder.getSiteStatus( siteStatus ));
			objectInfo.add("ExAtt2", "" + newHistId);

			rc = doc.updateObject(ll_id, objectInfo);

			// has anything changed?
			changed = false;
			if ( !((String) rs1.get(0).get("site_number")).equals((String) rs1.get(1).get("site_number")) )
				changed = true;
			if ( !((String) rs1.get(0).get("site_name")).equals((String) rs1.get(1).get("site_name")) )
				changed = true;
			if ( !((String) rs1.get(0).get("principal_inv_last")).equals((String) rs1.get(1).get("principal_inv_last")) )
				changed = true;
			if ( !((String) rs1.get(0).get("principal_inv_first")).equals((String) rs1.get(1).get("principal_inv_first")) )
				changed = true;

			if ( !changed ) {
				logger.debug("no attribute changes for {} (done)", ctmsId);
				return rc;
			}

			// update the relevant metadata for site
			rc = this.updateMetadata(ll_id);
		}
		catch (Exception e) {
			logger.error("site container update failire", e);
			auditRecord(ll_id, "**ERR** site container update failure - " + e.getMessage());
			return -1;
		}

		return rc;
	}


	/**
	 * Update the site category/atts for this folder and any folder children.
	 * <b>SPECIAL NOTE:</b> The rules for folder and document updates
	 * are different. All folder SITE attributes are updated, while for
	 * documents the investigator name never changes.
	 * <p/>
	 * Therefore to speed processing two XML cat/att models are created. 
	 * One is used for folders and all values are updated. 
	 * The second is for documents and the investigator attribute is
	 * removed to allow the current value to remain.
	 * <p/>
	 * Since we know that some site value has changed (otherwise we would
	 * not be doing updates), we just apply the applicable XML template associated
	 * with the 'project / country / site' category without checking details.
	 * @return	status (0/-1)
	 */
	private int updateMetadata(int oid)
	{
		Category fcat, dcat;
		int rc = 0;

		logger.info("updating site metadata on {}", oid);

		// get current metadata from object
		try {
			fcat = new Category(llserver);
			dcat = new Category(llserver);

			// init the folder category for this tier & set values
			rc = fcat.getObjectCategory( oid );
			fcat.XML2DOM();

			fcat.setValue("Investigator Name", investigatorName);
			fcat.setValue("Study Site ID", siteId);
			fcat.setValue("Site Name", siteName);
			fcat.DOM2XML();

			// update the cats/atts for the parent object
			rc = fcat.updateObject( oid );

			// now init the secondary document category
			rc = dcat.getObjectCategory( oid );
			dcat.XML2DOM();

			dcat.setValue("Study Site ID", siteId);
			dcat.setValue("Site Name", siteName);
			dcat.removeValue("Investigator Name");
			dcat.DOM2XML();

			// now process any children
			rc = this.updateChildMetadata(oid, fcat, dcat);
		}
		catch (Exception e) {
			logger.error("set category on site folder", e);
			auditRecord(oid, "**ERR** set category on site folder - " + e.getMessage());
			return -1;
		}

		return rc;
	}

	/**
	 * write the given category XML to any children
	 * <p/>
	 * @param folderid
	 * @param cat
	 * @return	status (0/-1)
	 */
	private int updateChildMetadata(int folderid, Category fcat, Category dcat)
	{
		LLValue children;
		int rc = 0;

		logger.debug("updating children for {}", folderid);

		// get the children
		try {
			children = doc.getChildrenInfo(folderid,  "subtype in (0, 144, 751, 749)");
			for (int cid = 0; cid < children.size(); cid++ ) {
				int stype;
				int llid;
				String name;

				stype = children.toInteger(cid, "subtype");
				llid = children.toInteger(cid, "ID");
				name = children.toString(cid, "name");
				// is this a document or email?
				if ( stype == 144 || stype == 749) {
					dcat.updateObject( llid );
					logger.debug("metadata doc {} [{}]", llid, name);
				}
				else {
					fcat.updateObject( llid );
					logger.debug("metadata folder {} [{}]", llid, name);
					this.updateChildMetadata( llid, fcat, dcat );
				}
			}
		}
		catch (Exception e) {
			logger.error("child category problem", e);
			auditRecord(folderid, "**ERR** set category on folder child item");
			return -1;
		}

		return rc;
	}

	// add entry to job audit trail
	private void auditRecord(int did, String message) 
	{
		auditTrail.setAuditType("SITE UPDATE JOB");
		auditTrail.setDataId( (long) did );
		auditTrail.setDescription( message );
		auditTrail.setCountryName(countryCode);
		auditTrail.setSiteNumber(siteId);

		auditTrailDAO_.insert( auditTrail );
	}

}
