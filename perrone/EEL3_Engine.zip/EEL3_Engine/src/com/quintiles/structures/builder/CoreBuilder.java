package com.quintiles.structures.builder;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.opentext.api.LAPI_DOCUMENTS;
import com.opentext.api.LLValue;
import com.quintiles.e3.data.dao.model.nodb.ProjectJobTypeEnum;
import com.quintiles.lapi.Document;
import com.quintiles.lapi.User;
import com.quintiles.structures.db.DbPackage;


/**
 * Core Builder
 * <p/>
 * Class responsible for building the base tier for
 * a structures project.
 * <p/>
 * Creates the Livelink project and then builds the defined groups,
 * assigns project membership, and builds out the start-up folders.
 * The appropriate categories are attached and data populated.
 * The navigation and artifact permissions are set as configured
 * in the structures template.
 * <p/>
 * @author John Shoun, Quintiles
 * @version $Revision$
 */
public class CoreBuilder extends BaseBuilder
{

	private Document doc;
	private User user;

	// superclass constructor
	public CoreBuilder(Long pid, Long jid)
	{
		super(pid, jid);

		// configure the build
		tier = 1;
	}


	/**
	 * not needed for core build
	 */
	@Override
	public int createContainer()
	{
		return 0;
	}

	/**
	 * This is the main routine for managing the build of the core 
	 * container (project) that will hold study contents. The process is
	 * to create the project, create the groups, and then assign the 
	 * project membership
	 * <p/>
	 * @return	status (0/-1)
	 */
	@Override
	public int buildContainer()
	{
		int rc = 0;
		int llid;

		// get Livelink object creators, and build
		doc = new Document(llserver);
		user = new User(llserver);

		auditRecord(0, "<<START>> core build start");

		// START core build block
build:	{

			// get the tier configuration
			this.initTier();
	
			// get the core container
			if ( jobType() == ProjectJobTypeEnum.CREATE ) {
	
				// create mode, build the project
				llid = this.createProject();
				if ( llid == -1 ){
					logger.error("Core Builder create project failed");
					rc = -1;
					break build;
				}
			}
			else {
				LLValue info;
	
				// this is an update, verify that the project exists
				llid = studyProfile.getProjectLlId().intValue();
				if ( llid == 0 ){
					auditRecord(-1, "*ERR* core build CS10 home object missing, reset profile");
					logger.error("Core Builder Livelink home object missing, reset profile");
					rc = -1;
					break build;
				}
	
				try {
					info = doc.getObjectInfo( llid );
					if (info == null) {
						auditRecord(-1, "*ERR* core build profile error, " + llid + " ID missing");
						logger.error("core builder profile error, {} ID missing", llid);
						rc = -1;
						break build;
					}
				}
				catch (Exception e) {
					auditRecord(-1, "*ERR* core builder profile access error");
					logger.error("core builder profile access error", e);
					rc = -1;
					break build;
				}
	
				// is this deleted?
				if (info.toInteger("VOLUMEID") < -3000L) {
					auditRecord(-1, "*ERR* core build project object is deleted and cannot be used");
					logger.error("Core Builder the project object is deleted and cannot be used");
					rc = -1;
					break build;
				}
			}

			// attach the base category for this tier
			try {
				this.updateNavMetadata( llid );
			}
			catch (Exception e) {
				auditRecord(-1, "*ERR* core project metadata error [" + e.getMessage() + "]");
				logger.error("Core Builder metadata error", e);
				rc = -1;
				break build;
			}
	
			// create the project groups, assign leaders
			this.createProjectGroups();
	
			// assign the default group leaders/members
			this.configureGroupLeadership();
	
			// assign members to project & groups
			if (llid > 2000){
				this.configureGroupMembership( llid );
	
				// set the navigation permissions
				this.setPermissions( llid );
	
				// this is what we've been waiting for
				// build the structure; we assume this was
				// a project so the shadow volume is referenced
				this.buildStartUp( -llid );
			}

		}
		// END core build block

		if (auditJobStatus("core build") != 0) { 
			rc = -1;
		}
		auditRecord(0, "<<END>> core build complete");
		return rc;
	}

	/**
	 * builds the top level container under the
	 * customer folder
	 * <p/>
	 * @return	the Livelink project ID
	 */
	private int createProject()
	{
		int custFolderId;
		int llid = -1;

		logger.info("creating base container for {}, {}, {}", customer, project, protocol);

		// create the core object
		logger.debug("creating the project");
		try {
			String pname;

			// get the home folder for the customer
			// look in the main customer folder
			custFolderId = this.getCustomerFolder(customer);
			if (custFolderId == -1){
				auditRecord(-1, "*ERR* could not get customer folder, create project failed");
				logger.error("could not get the customer folder");
				return -1;
			}

			pname = (protocol == null) ? project : project + " (" + protocol + ")";
			llid = doc.createObject(custFolderId, objType, pname);
		}
		catch (Exception e) {
			auditRecord(-1, "*ERR* create project failed, could not create project");
			logger.error("create core object error", e);
			return -1;
		}

		// update the study profile with the LL object id
		studyProfile.setProjectLlId( (long) llid );
		studyProfileDAO_.update( studyProfile );

		// create audit trail entry for project build
		auditRecord(llid, "create base project for study");

		logger.info("create project ID {}", llid);

		return llid;
	}

	/**
	 * finds the customer folder within the main customer
	 * project folder
	 * <p/>
	 * @param cname			customer name
	 * @return				customer folder object ID
	 * @throws Exception	if the customer folder cannot be found, stop here
	 * 
	 */
	private int getCustomerFolder(String cname) throws Exception
	{
		List<Map<String, Object>> rs5;
		Map<String, Object> rec;

		// create the groups (store in local cache)
		logger.debug("look up customer base folder");
		try {

			// get the dynamic groups to create
			rs5 = (new DbPackage.GetCustomerFolder()).run( cname );

			if ( rs5.size() < 1 ) {
				return -1;
			}

			rec = rs5.get(0);
			return ((BigDecimal) rec.get("CUSTOMER_FOLDER")).intValue();
		}
		catch (Exception e) {
			logger.error("customer base folder error", e);
		}

		return -1;
	}

	/**
	 * Create the standard project groups, any previously
	 * existing groups will be re-used and re-initialized.
	 * The dynamic groups are configured in E3_SECURITY_GROUPS.
	 * The group membership is cleared as a precaution (to allow
	 * for a re-used group).
	 * <p/>
	 * @return 	status (0/-1)
	 */
	private int createProjectGroups()
	{
		List<Map<String, Object>> rs1;
		String gname = "";
		int gid;
		int rc;

		// create the groups (store in local cache)
		logger.debug("creating the project specific groups");
		rc = 0;
		try {

			// get the dynamic groups to create
			rs1 = (new DbPackage.CreateGroups()).run( new Long(templateId) );

			for (Map<String, Object> rec : rs1)	
			{
				int dynamic;

				gname = fmtGroupName( (String) rec.get("group_name") );
				dynamic = ((BigDecimal) rec.get("dynamic_yn")).intValue();

				logger.info("creating group {}", gname);
				gid = user.createGroup( gname );
				if (gid != -1) {
					// cache the group reference for later use by builder
					mapGroups.put(gname, new Integer(gid));
				}

				// there are 2 types of dynamic groups, 
				// regular groups (type 1) are administered by the teams
				// study control group (type 2) are managed by EEL based on the
				// profile type -- we will clear any members in case we are switching
				// (members will be added back later)
				if (dynamic == 2) {
					user.clearGroupMembers(gname, 1);
				}

			}
		}
		catch (Exception e) {
			auditRecord(-1, "*ERR* create group " + gname + " failed");
			logger.error("create group error", e);
			return -1;
		}

		return rc;
	}

	/**
	 * set the leaders for the dynamic project groups
	 * <p/>
	 * @return		status (0/-1)
	 */
	private int configureGroupLeadership()
	{
		List<Map<String, Object>> rs2;
		String lname = "";
		String gname = "";
		int rc, r;

		// assign group leaders
		rc = 0;
		try {

			// get the groups to update
			rs2 = (new DbPackage.GetGroupLeaders()).run( new Long(templateId) );
			for (Map<String, Object> rec : rs2)
			{
				gname = fmtGroupName( (String) rec.get("group_name") );
				lname = fmtGroupName( (String) rec.get("leadership") );

				logger.info("set group leader");
				r = user.addGroupLeader(gname, 1, lname, 1);
				if (r != 0) {
					auditRecord(-1, "*ERR* could not set leader " + lname + " for group " + gname);
					rc = -1;
				}
			}
		}
		catch (Exception e) {
			auditRecord(-1, "*ERR* could not set leader " + lname + " for group " + gname);
			logger.error("group leader error", e);
			return -1;
		}

		return rc;
	}

	/**
	 * Manages the membership of all the new project groups;
	 * some groups are leaders for others, in others the membership
	 * switches based on project type.
	 * <p/>
	 * All of this is driven from the security group configuration table.
	 * <p/>
	 * @param 	projectId	object ID for the project membership being updated
	 * @return	status		(0/-1)
	 */
	private int configureGroupMembership(int projectId)
	{
		List<Map<String, Object>> rs3;
		int rc, r;
		int rtype;
		String gname = "";
		String memberlist, members[];

		// assign group membership
		rc = 0;
		try {

			// clear all project memberships,
			// these will be reset from the configuration
			user.clearGroupMembers("Coordinators", projectId);
			user.clearGroupMembers("Members", projectId);
			user.clearGroupMembers("Guests", projectId);

			// get the membership records
			rs3 = (new DbPackage.GetGroupMembers()).run(new Long(templateId));

			for (Map<String, Object> rec : rs3)
			{
				gname = fmtGroupName( (String) rec.get("group_name") );
				rtype = ((BigDecimal) rec.get("right_type")).intValue();
				memberlist = (String) rec.get("membership");
				members = memberlist.split(",");

				logger.debug("updating group {}", gname);
				for (String s : members)
				{
					logger.debug("set group member {}", fmtGroupName( s ));

					// regular Livelink group
					if (rtype == 0){
						r = user.addGroupMember(gname, 1, fmtGroupName( s ), 1);
					}
					// special project object group
					else {
						r = user.addGroupMember(gname, projectId, fmtGroupName( s ), 1);
					}

					if (r != 0) {
						auditRecord(-1, "*ERR* could not add " + fmtGroupName( s ) + " to group " + gname);
						rc = -1;
					}
				}
			}
		}
		catch (Exception e) {
			auditRecord(-1, "*ERR* failed to configure group " + gname);
			logger.error("group membership error", e);
			return -1;
		}

		if (rc != 0) {
			auditRecord(-1, "*ERR* failed to configure group " + gname);
		}
		return rc;
	}


	/**
	 * sets the defined navigation permissions
	 * on the new project
	 * <p/>
	 * the project member permissions are revoked while the GUEST group along 
	 * with external consumers are given see/see-contents access to browse
	 * (this is now all controlled by the security group template)
	 * <p/>
	 * @param 		projectId
	 * @return		status (0/-1)
	 */
	private int setPermissions(int projectId)
	{
		List<Map<String, Object>> rs4;
		int rc;
		String gname;
		int gid;

		rc = 0;
		user = new User(llserver);
		logger.info("setting navigation permission");

		try {
			// change the owner permission, read-only
			// negate the project ID to get the folder container
			rc = doc.updateObjectPermission(-projectId, LAPI_DOCUMENTS.RIGHT_OWNER, Document.CONSUMER);
			if (rc != 0) {
				auditRecord(projectId, "*ERR* could not change project owner");
			}

			// revoke the default member & guest permissions
			for ( String s :  new String[] {"Members", "Guests"} )
			{
				gid = this.findGroup(s);
				if (gid == -1){
					auditRecord(projectId, "*ERR* could not find project [" + s + "] group");
					logger.error("could not find project [{}] group", s);
				}
				else {
					// negate the project ID to get the folder container
					rc = doc.removeObjectPermission(-projectId, gid);
				}
			}

			// allow the navigation groups to browse
			// get the membership records
			rs4 = (new DbPackage.GetNavigators()).run( new Long(templateId) );
			for (Map<String, Object> rec : rs4)
			{
				int perms;

				gname = fmtGroupName( (String) rec.get("group_name") );
				perms = ((BigDecimal) rec.get("permission")).intValue();
				gid = this.findGroup(gname);
				if (gid == -1){
					auditRecord(projectId, "*ERR* could not find " + gname + " group");
					logger.error("could not find group {}", gname);
					continue;
				}
				// add users to both 'sides' of project volume
				rc = doc.addObjectPermission(projectId, gid, perms);
				if (rc != 0) {
					auditRecord(projectId, "NOTE: could not add group " + gname + " rights to project");
				}
				// negate the project ID to get the folder container
				rc = doc.addObjectPermission(-projectId, gid, perms);
				if (rc != 0) {
					auditRecord(projectId, "NOTE: could not add group " + gname + " rights to project shadow volume");
				}
			}
		}
		catch (Exception e) {
			auditRecord(projectId, "*ERR* failed to set project permissions");
			logger.error("navigation permissions config error", e);
			return -1;
		}

		return rc;
	}

	// add entry to job audit trail
	private void auditRecord(int did, String message) 
	{
		auditTrail.setAuditType("CORE BUILD");
		auditTrail.setDataId( (long) did );
		auditTrail.setDescription( message );

		auditTrailDAO_.insert( auditTrail );
	}



	/**
	 * get the job type ENUM for running build
	 * <p/>
	 */
	private ProjectJobTypeEnum jobType()
	{

		if (this.projectJob == null){
			return ProjectJobTypeEnum.CREATE;
		}

		return projectJob.getJobType();
	}

}
