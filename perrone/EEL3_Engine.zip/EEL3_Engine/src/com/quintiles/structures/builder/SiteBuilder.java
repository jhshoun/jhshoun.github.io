package com.quintiles.structures.builder;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.quintiles.lapi.Category;
import com.quintiles.lapi.Document;
import com.quintiles.structures.db.DbPackage;

/**
 * Site Builder
 * <p/>
 * Class responsible for building the site class (tier)
 * within a structures project.
 * <p/>
 * The core project already exists, the container ID is in
 * the study profile. The country object may or may not exist --
 * if not then the country must be created, 
 * then the start-up folders are built out.
 * <p/>
 * @author John Shoun, Quintiles
 * @version $Revision$
 */

public class SiteBuilder extends BaseBuilder
{
	private String countryCode;
	private String countryName = "Duchy of Grand Fenwick";
	private String siteId;
	private String siteName;
	private String investigatorName;

	private Document doc;

	// superclass constructor
	public SiteBuilder(Long pid, Long jid, String siteNumber)
	{
		super(pid, jid);
		tier = 3;
		this.siteId = siteNumber;
	}

	/**
	 * This is the main routine for managing the build of
	 * a single site container.
	 * The process is to get the container type, create, assign
	 * the defined category, then build the start-up folders.
	 * <p/>
	 * @return	object ID or -1
	 */
	@Override
	public int buildContainer()
	{
		int llid;

		auditRecord(0, "<<START>> site build start: " + siteId);

		// create the core object
		llid = this.createContainer();
		if ( llid != -1 ){

			// build the start-up folders
			this.buildStartUp( llid );
		}

		if (auditJobStatus("site build") != 0) { 
			llid = -1;
		}
		auditRecord(0, "<<END>> site build complete");

		return llid;
	}

	/**
	 * This is a utility to create the empty site container.
	 * The process is to get the container type, create, assign
	 * the defined category.
	 * <p/>
	 * @return	object ID or -1
	 */
	@Override
	public int createContainer()
	{
		int llid;

		// get Livelink object creators, and build
		doc = new Document(llserver);

		// get the tier configuration
		this.initTier();

		// create the core object
		llid = this.createSite();
		if ( llid == -1 ){
			auditRecord(-1, "*ERR* site create fail");
			logger.error("site create folder failed");
			return -1;
		}

		// attach the base category for this tier
		try {
			this.updateMetadata( llid );
		}
		catch (Exception e1) {
			logger.error("Site Builder metadata error", e1);
			auditRecord(-1, "*ERR* site folder metadata error [" + e1.getMessage() + "]");
			try {
				List<Integer> siteItems_ = doc.getChildren(llid, null);
				if (siteItems_.isEmpty()) {
					doc.deleteObject(llid);
					logger.debug("empty sites are deleted  {}", llid);
					return -1;
				}
			} catch (Exception e2) {
				logger.error("delete operation is failed for site folder", e2);
			}
		} 
		return llid;
	}

	/**
	 * builds the site object within the country
	 * container
	 * <p/>
	 * @return	the Livelink object ID
	 */
	private int createSite()
	{
		int prjId;
		int countryId;
		int llid = -1;
		String siteFolderName;
		HashMap<String, String> siteData;

		logger.info("creating site container for {}, {}, {}, {}", 
				customer, project, protocol, siteId);

		// is this a known site?
		siteData = SiteBuilder.getSite(project, protocol, siteId);
		if (siteData.get("status").equalsIgnoreCase("ERR")) {
			auditRecord(-1, "*ERR* could not file site " + siteId);
			logger.error("could not find site {}", siteId);
			return -1;
		}

		// found the site, press on
		// has the site number been updated?
		if ( !siteId.equals( siteData.get("site_number") ) ) {
			siteId = siteData.get("site_number");
			logger.info("site number updated to {}", siteId);
		}
		siteName = siteData.get("site_name");
		investigatorName = siteData.get("inv_name");
		countryCode = siteData.get("country_code");
		countryName = siteData.get("country_name");

		// create the site object
		logger.debug("creating the site");
		try {

			// get the project ID
			// stored in the study profile
			prjId = studyProfile.getProjectLlId().intValue();
			if (prjId < 2001){
				auditRecord(-1, "*ERR* could not get the project folder");
				logger.error("could not get the project folder ID");
				return -1;
			}

			// find the country folder within the project
			countryId = doc.getChildObjectId(-prjId, countryName.toUpperCase());
			if (countryId < 2001){
				auditRecord(-1, "*ERR* could not get the country folder");
				logger.error("could not get the country folder ID");
				return -1;
			}

			// set the site status
			doc.setSiteStatus( SiteBuilder.getSiteStatus( siteData.get("site_status") ) );

			// create the site object
			siteFolderName = SiteBuilder.getSiteFolderName(
									countryCode, siteId, investigatorName, siteName
								);
			llid = doc.createObject(countryId, objType, siteFolderName);
			// save the associated sELVIS_REF history code
			doc.updateObjectExatt2(llid, siteData.get("hist_id"));
		}
		catch (Exception e) {
			auditRecord(-1, "*ERR* site create problem [" + e.getMessage() + "]");
			logger.error("create site container error", e);
			return -1;
		}

		// create audit trail entry for project build
		auditTrail.setCountryName(countryName + " (" + countryCode + ")");
		auditTrail.setSiteNumber(siteName + " - " + investigatorName);
		auditRecord(llid, "create site folder");

		logger.info("create site {} name {}", siteName, llid);

		return llid;
	}

	// accessor for site name
	public String getSiteId()
	{
		return siteId;
	}


	/**
	 * gets site details from elvis_ref
	 * <p/>
	 * @param proj		project code
	 * @param prot		protocol number
	 * @param siteId	site ID
	 * @return			site details as HashMap
	 */
	public static HashMap<String, String> getSite(String proj, String prot, String siteId)
	{
		HashMap<String, String> siteDetails = new HashMap<String, String>();
		List<Map<String, Object>> rs;

		// get the site details from ELVIS_REF
		rs = (new DbPackage.GetSiteData()).run(proj, prot, siteId);
		if (rs == null) {
			siteDetails.put("status", "ERR");
		}
		else if (rs.size() < 1) {
			siteDetails.put("status", "NONE");
		}
		else {
			siteDetails.put("status", "OK");

			siteDetails.put("site_number", (String) rs.get(0).get("site_number") );
			siteDetails.put("site_name", (String) rs.get(0).get("site_name") );
			siteDetails.put("inv_name", (String) rs.get(0).get("principal_inv_full_name") );
			siteDetails.put("country_code", (String) rs.get(0).get("site_country_code") );
			siteDetails.put("country_name", (String) rs.get(0).get("country_name") );
			siteDetails.put("site_status", (String) rs.get(0).get("site_status") );
			siteDetails.put("hist_id", ((BigDecimal) rs.get(0).get("hist_id")).toString() );
		}

		return siteDetails;
	}

	/**
	 * get status for specific site (mapped from config)
	 * <p/>
	 * @param cc	the 2-character country code
	 * @return		map with the site details
	 */
	public static String getSiteStatus(String ctmsStatus)
	{
		List<Map<String, Object>> rs2;
		String cfg;

		// if no results, the status was not matched -- default is ACTIVE
		rs2 = (new DbPackage.GetSiteStatusConfig()).run(ctmsStatus);
		if (rs2 == null) {
			return "ACTIVE";
		}
		if (rs2.size() < 1) {
			return "ACTIVE";
		}

		cfg = (String) rs2.get(0).get("cfg_name");
		if ( cfg.equalsIgnoreCase("nonselected.site.status") ){
			return "NON-SELECTED";
		}
		if ( cfg.equalsIgnoreCase("closed.site.status") ){
			return "CLOSED";
		}

		return "ACTIVE";
	}

	/**
	 * answers the location specific folder name
	 * <p/>
	 * @param cc			the 2-character country code
	 * @param sid			the site identifier
	 * @param inv			the investigator name
	 * @param siteName		the site name
	 * @return		the site folder name
	 */
	public static String getSiteFolderName(String cc, String sid, String inv, String siteName)
	{
		String sfn;

		sfn = sid + " " + inv;
		// site folder has special name for special people
		if ( cc.equalsIgnoreCase("JP") ){
			sfn = sid + " " + siteName;
		}

		return sfn;
	}

	/**
	 * find site folder in CS10
	 * <p/>
	 * @param proj		project code
	 * @param prot		protocol number
	 * @param siteId	site ID
	 * @return			dataid
	 */
	public static HashMap<String, Object> findCS10Site(int countryFolder, String proj, String prot, String siteId)
	{
		HashMap<String, Object> response;
		List<Map<String, Object>> rs;

		response = new HashMap<String, Object>();

		// look under country folder for site matching hist id
		rs = (new DbPackage.FindCS10Site()).run(countryFolder, proj, prot, siteId);
		if ( (rs == null) || (rs.size() < 1) ) {
			response.put("dataid", -1);
			return response;
		}
		else {
			String site_folder_name;
			int did;

			did = ((BigDecimal) rs.get(0).get("dataid")).intValue();
			response.put("dataid", did);
			site_folder_name = (String) rs.get(0).get("name");
			response.put("site_number", site_folder_name.split(" ")[0]);
		}
		return response;
	}


	/**
	 * adds the category for this tier to this object, 
	 * since this is a child, the parent cat must be removed
	 * <p/>
	 * @return	status (0/-1)
	 * @throws Exception 
	 */
	private int updateMetadata(int oid) throws Exception
	{
		Category cat;
		int rc = 0;

		logger.info("setting site metadata {} on {}", categoryId, oid);

		// get the metadata schema and add to the object
		try {
			this.findStudy();

			cat = new Category(llserver);

			// start by removing the inherited metadata
			cat.removeObjectCats( oid );

			// init the category for this tier & set values
			rc = cat.getCategory( categoryId );
			cat.XML2DOM();

			cat.setValue("Customer", customer);
			cat.setValue("Quintiles Project Code", project);
			cat.setValue("Protocol Number", protocol);
			cat.setValue("Phase", getPhase());
			cat.setValue("Therapeutic Area", getTherapyArea());
			cat.setValue("Country", countryName);
			cat.setValue("Country Code", countryCode);
			cat.setValue("Investigator Name", investigatorName);
			cat.setValue("Study Site ID", siteId);
			cat.setValue("Site Name", siteName);

			cat.DOM2XML();
			rc = cat.updateObject( oid );
		}
		catch (Exception e) {
			auditRecord(oid, "*ERR* site metadata problem [" + e.getMessage() + "]");
			logger.error("set category on site folder ({})", oid);
			throw ( new Exception("Site Builder category fail") );
		}

		return rc;
	}

	// add entry to job audit trail
	private void auditRecord(int did, String message) 
	{
		auditTrail.setAuditType("SITE BUILD");
		auditTrail.setDataId( (long) did );
		auditTrail.setDescription( message );

		auditTrailDAO_.insert( auditTrail );
	}

}

	