package com.quintiles.structures.builder;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.opentext.api.LAPI_DOCUMENTS;
import com.opentext.api.LLValue;
import com.quintiles.lapi.Category;
import com.quintiles.lapi.Document;
import com.quintiles.lapi.User;
import com.quintiles.structures.db.DbPackage;
import com.quintiles.structures.engine.FolderFactory;


/**
 * Structure Verifier
 * <p/>
 * Class responsible for inspecting all elements in a specified
 * structure to make sure it matches the template and that all
 * start-up artifacts have been built.
 * <p/>
 * The known study metadata is compared for the objects, and
 * permissions are verified against the template
 * <p/>
 * @author John Shoun, Quintiles
 * @version $Revision: 1208 $
 */
public class StructureVerifier extends BaseBuilder
{

	private Document doc;
	private User user;
	private Long restartId;
	private Boolean skip = false;

	/*
	 * global working lists that are used by the various
	 * level checks (project, country, site)
	 */
	String tier_name_;
	List<Integer> foundArtifacts_;
	// core (project)
	List<Map<String, Object>> core_folders_rs_;
	// country
	List<Map<String, Object>> country_folders_rs_;
	String country_name_;
	String country_code_;
	// site
	List<Map<String, Object>> site_folders_rs_;
	String site_id_;
	String site_name_;
	String investigator_name_;
	// permissions
	List<Map<String, Object>> nav_perms_;

	// superclass constructor
	public StructureVerifier(Long pid, Long jid, Long dataid)
	{
		super(pid, jid);
		tier = 0;
		restartId = dataid;
		if ( restartId > 1000 ) {
			skip = true;
		}
	}


	/**
	 * not needed for check job
	 */
	@Override
	public int createContainer()
	{
		return 0;
	}

	@Override
	public int buildContainer()
	{
		return 0;
	}

	/**
	 * Main routine for managing the structure verification job.
	 * <p/>
	 * @return	status (0/-1)
	 */
	public int verify()
	{
		int rc = 0;
		int r;
		int llid;

		// get Livelink CS10 LAPI controls
		doc = new Document(llserver);
		user = new User(llserver);

		// get the tier configuration
		tier = 1;
		this.initTier();

		// get the reference study information
		// (phase, therapeutic area)
		this.findStudy();

		auditRecord(0, "<<START>> check job" );

		// main block of code that implements the various
		// components of the check job, any section that
		// fails will set the return code and optionally break
check:	{

			// validate the core object
			llid = this.checkProject();
			if ( llid < 2001 ) {
				rc = -1;
				break check;
			}

			// project groups
			logger.info("CHECK: validating project groups");
			r = this.checkProjectGroups();
			if (r != 0) {
				logger.info("CHECK: security group error");
				rc = -1;
			}

			// verify group leaders/members
			logger.info("CHECK: validating group leadership");
			r = this.checkGroupLeadership();
			if (r != 0) {
				logger.info("CHECK: security group leadership error");
				rc = -1;
			}

			// verify group membership
			logger.info("CHECK: validating group membership");
			r = this.checkGroupMembership( llid );
			if (r != 0) {
				logger.info("CHECK: group membership error");
				rc = -1;
			}

			// get the generic navigation folder permissions
			// and unblinded folder permissions,
			// these are common and only loaded once
			nav_perms_ = (new DbPackage.GetNavigators()).run( new Long(templateId) );

			//--------------------------------------------------------
			// let's do it
			try {
				tier_name_ = "Core";
				this.scanProject( llid );

				tier = 2;
				this.initTier();
				tier_name_ = "Country";
				this.scanCountries( -llid );

				tier = 3;
				this.initTier();
				tier_name_ = "Site";
				this.scanSites( -llid );
			}
			catch (Exception e) {
				rc = -1;
				logger.error("CHECK: project scan failure", e);
				auditRecord(llid, "*ERR* project scan failed" );
			}
			//--------------------------------------------------------

		}

		// end of the road, sign out
		if (auditJobStatus("check job") != 0) {
			rc = -1;
		}
		auditRecord(0, "<<END>> check job" );

		return rc;
	}


	/**
	 * scan project object, gets a list of the applicable artifacts and
	 * proceeds to scan all direct contents
	 * <p/>
	 * @param projectObjId		project container ID
	 * @throws Exception
	 */
	private void scanProject(int projectObjId) throws Exception
	{
		// no need to verify the project permissions,
		// they cannot be changed

		// verify cats & atts
		this.checkNavMetadata( projectObjId );

		// get the complete list of folders for this tier
		foundArtifacts_ = new ArrayList<Integer>();
		core_folders_rs_ = (new DbPackage.GetFolderList()).run(
														new Long(templateId),
														new Long(tier),
														1);

		auditRecord(projectObjId, "[ PROJECT ] start" );

// if this is a restart skip all core content
if (!skip) {

		// core components complete, ready for the actual structure
		// use the shadow volume
		this.scanFolder( -projectObjId, 1, core_folders_rs_ );

		// now that we've finished looking at everything built,
		// are there any startup folders are missing (JIT=0)
		this.completeTier(core_folders_rs_, null, null);
}

		// finished project
		auditRecord(projectObjId, "[ PROJECT ] done" );

		return;
	}


	/**
	 * scan country objects
	 * <p/>
	 * @param projectObjId		base project container
	 * @throws Exception
	 */
	private void scanCountries(int projectObjId) throws Exception
	{
		LLValue countries;

		// get the children, check each one
		try {
			countries = doc.getChildrenInfo(projectObjId, "subtype = 10100");
		}
		catch (Exception e) {
			auditRecord(projectObjId, "*ERR* failed to get country list" );
			logger.error("list country folders fail", e);
			return;
		}

		for (int i = 0; i < countries.size(); ++i)
		{
			int countryObjId;

			// get the child object ID, ISO code & name
			countryObjId = countries.toInteger(i, "ID");
			country_code_ = countries.toString(i, "EXATT1").toUpperCase();
			country_name_ = countries.toString(i, "NAME");

// if this is a restart job look at the matching launch point
if (skip) {
	if ( countryObjId == restartId ) {
		skip = false;
	}
	else {
		continue;
	}
}

			auditRecord(countryObjId, "[ " + country_name_ + " ] start" );

			// check the folder permissions
			this.checkPermissions( countryObjId, nav_perms_, false );

			// verify cats & atts
			this.checkNavMetadata( countryObjId );

			// get the complete list of folders for this tier
			foundArtifacts_ = new ArrayList<Integer>();
			country_folders_rs_ = (new DbPackage.GetFolderList()).run(
															new Long(templateId),
															new Long(tier),
															1);

			// scan the country
			this.scanFolder( countryObjId, 1, country_folders_rs_ );

			// are there any startup folders missing
			this.completeTier(country_folders_rs_, country_code_, null);

			// finished this country
			auditRecord(countryObjId, "[ " + country_name_ + " ] done" );
		}

		country_code_ = null;
		country_name_ = null;

		return;
	}

	/**
	 * scan sites
	 * <p/>
	 * @param projectObjId		base project container
	 * @throws Exception
	 */
	private void scanSites(int projectObjId) throws Exception
	{
		LLValue countries;
		LLValue sites;
		HashMap<String, String> siteData;

		// get the children, check each one
		try {
			countries = doc.getChildrenInfo(projectObjId, "subtype = 10100");
		}
		catch (Exception e) {
			auditRecord(projectObjId, "*ERR* failed to get country list for site scan" );
			logger.error("scan sites list country folders fail", e);
			return;
		}

		for (int i = 0; i < countries.size(); ++i)
		{
			int countryObjId;

			countryObjId = countries.toInteger(i, "ID");
//			country_code_ = countries.toString(i, "EXATT1");
//			country_name_ = countries.toString(i, "NAME");

			try {
				sites = doc.getChildrenInfo(countryObjId, "subtype = 10101");
			}
			catch (Exception e) {
				auditRecord(countryObjId, "*ERR* failed to get sites for country "
											+ countries.toString(i, "NAME"));
				logger.error("list site for country fail", e);
				continue;
			}

			for (int j = 0; j < sites.size(); ++j)
			{
				int siteObjId;

				// get the child object ID, ISO code & name
				siteObjId = sites.toInteger(j, "ID");
				site_id_ = sites.toString(j, "NAME").split(" ")[0];

// if this is a restart job look at the matching launch point
if (skip) {
	if ( siteObjId == restartId ) {
		skip = false;
	}
	else {
		continue;
	}
}

				// is this a known site?
				siteData = SiteBuilder.getSite(project, protocol, site_id_);
				if ( !siteData.get("status").equalsIgnoreCase("OK") ) {
					logger.error("could not find site {}", site_id_);
					auditRecord(siteObjId, "*ERR* site " + site_id_ + " is not valid" );
					continue;
				}

				// found the site, press on
				site_name_ = siteData.get("site_name");
				investigator_name_ = siteData.get("inv_name");
// TODO
// should i check for wrong country here???
				country_code_ = siteData.get("country_code");
				country_name_ = siteData.get("country_name");

				auditRecord(siteObjId, "[ " + site_name_ + " ] start" );

				// check the folder permissions
				this.checkPermissions( siteObjId, nav_perms_, false );

				// verify cats & atts
				this.checkNavMetadata( siteObjId );

				// get the complete list of folders for this tier
				foundArtifacts_ = new ArrayList<Integer>();
				site_folders_rs_ = (new DbPackage.GetFolderList()).run(
																new Long(templateId),
																new Long(tier),
																1);

				// scan the site
				this.scanFolder( siteObjId, 1, site_folders_rs_ );

				// are there any startup folders missing
				this.completeTier(site_folders_rs_, country_code_, site_id_);

				// finished this site
				auditRecord(siteObjId, "[ " + site_name_ + " ] done" );
			}
		}

		country_code_ = null;
		country_name_ = null;
		site_id_ = null;
		site_name_ = null;

		return;
	}


	/**
	 * starts with a list of all possible folders for the current
	 * tier, recursively scans all items and verified them against
	 * the master list
	 * <p/>
	 * @param parentId		parent container ID
	 * @param level			folder depth (1 - zone, 2 - section, 3 - artifact)
	 * @return				0/-1
	 * @throws Exception
	 */
	public int scanFolder(int parentId, int level, List<Map<String, Object>> folders_rs)
	{
		int rc = 0;
		LLValue children;

		// get the children, check each one
		try {
			children = doc.getChildrenInfo(parentId, "subtype not in (10100, 10101)");
		}
		catch (Exception e) {
			auditRecord(parentId, "*ERR* failed to get folder contents" );
			logger.error("listing folder contents", e);
			return -1;
		}

		for (int i = 0; i < children.size(); ++i)
		{
			int rowId;
			int objId;
			String folderName;
			boolean unblinded;

			// get the child object ID
			objId = children.toInteger(i, "id");

			// check for documents in wrong folders
			if ( children.toInteger(i, "subtype") == 144) {
				auditRecord( objId, "doc in navigation folder: " + children.toString(i, "name"));
				logger.warn("document in navigation folder - {}", children.toString(i, "name"));
				continue;
			}

			// find item in DIA matrix for this tier
			folderName = children.toString(i, "name");
			unblinded = folderName.contains("UNBLINDED") ? true : false;

			rowId = findFolder(folderName.replaceFirst("UNBLINDED ", "") , level, folders_rs);
			if (rowId < 0) {
				auditRecord( objId, "invalid folder: " + folderName);
				logger.warn("invalid folder - {}", folderName);
				continue;
			}

			// verify the folder
			try {
				// check common folder metadata
				this.checkNavMetadata( objId );

				// review the navigation folders (zone & section)
				if ( level < 3 ) {

					// check the folder permissions
					this.checkPermissions( objId, nav_perms_, false );

					// check their child folders
					if ( children.toInteger(i, "subtype") == 0 ) {
						this.scanFolder( objId, level + 1, folders_rs );
					}
				}

				// for artifact folders (folder or email), scan the contents
				if ( level == 3 ) {
					switch ( children.toInteger(i, "subtype") )
					{
						case 0:
						case 751:
							this.scanArtifact( objId, folders_rs.get(rowId), unblinded );
							break;
						default:
							// NOOP
					}
				}
			}
			catch (Exception e) {
				logger.error("check core object error", e);
				auditRecord(0, "scan-folder exception: " + e.getCause());
				return -1;
			}

			// completed artifact check, add to the found list
			{
				int f;

				f = ((BigDecimal) folders_rs.get(rowId).get("folder_id")).intValue();
				if (unblinded) {
					foundArtifacts_.add( -f );
				}
				else {
					foundArtifacts_.add( f );
				}
			}
		}

		return rc;
	}


	/**
	 * scans the artifact and any contents
	 * looks for category/attribute errors
	 * or permission issues
	 * <p/>
	 * @param parentId		object ID of container
	 * @param record		template record for artifact
	 * @param unblinded		UNBLINDED indicator
	 * @return
	 */
	public int scanArtifact(int parentId, Map<String, Object> record, boolean unblinded)
	{
		int rc = 0;
		LLValue children;
		List<Map<String, Object>> art_perms;
		int fid;
		boolean tmf;

		try {

			// check artifact folder metadata
			rc = checkArtifactMetadata(parentId, record, true, unblinded);

			// get the permissions set for the artifact
			fid = ((BigDecimal) record.get("folder_id")).intValue();
			if (unblinded) {
//				art_perms = unblinded_perms_;
				art_perms = (new DbPackage.GetUnblindedPermissions()).run(
									new Long(fid),
									new Long(classMask),
									new Long(templateId)
							);
			}
			else {
				art_perms = (new DbPackage.GetArtifactPermissions()).run(
									new Long(fid),
									new Long(classMask),
									new Long(templateId)
							);
			}

			// is this a TMF record?
			tmf = ((BigDecimal) record.get("tmf_file_yn")).intValue() == 1L;


			// check perms on artifact folder
			rc = checkPermissions(parentId, art_perms, !tmf);

			// now for the artifact contents
			// get the artifact children, check each one
			children = doc.getChildrenInfo(parentId, null);
			for (int i = 0; i < children.size(); ++i)
			{
				int objId;

				// get the child object ID
				objId = children.toInteger(i, "id");

				// check for wrong content in artifact
				if ( children.toInteger(i, "subtype") == 0) {
					auditRecord(objId, "extra folder in artifact: " + children.toString(i, "name"));
					continue;
				}

				// cats & atts
				this.checkNavMetadata( objId );
				this.checkArtifactMetadata(objId, record, false, unblinded);

				// permissions
				checkPermissions(objId, art_perms, !tmf);
			}

		}
		catch (Exception e) {
			logger.error("check artifact folder error", e);
			auditRecord(parentId, "scan-artifact exception: " + e.getMessage());
			return -1;
		}

		return rc;
	}


	/**
	 * finds the top level container
	 * <p/>
	 * @return	the Livelink project ID
	 */
	private int checkProject()
	{
		int llid;
		LLValue info;

		llid = studyProfile.getProjectLlId().intValue();
		info = new LLValue().setAssocNotSet();

		// find the project
		try {
			info = doc.getObjectInfo( llid );

			if ( info == null || info.isNotSet() ) {
				logger.info("CHECK: no structure for profile {}", studyProfile.getProfileId());
				auditRecord(llid, "*ERR* there is no structure for this profile");
				return -1;
			}
		}
		catch (Exception e) {
			logger.error("check core object error", e);
			auditRecord(0, "*ERR* check-project exception: " + e.getMessage());
			return -1;
		}

		logger.info("CHECK: {} project found", info.toString("NAME"));
		return llid;
	}


	// ******************************     METADATA CHECKS     *************************************
	/**
	 * verifies that the correct category has been applied
	 * to the object and attribute values are correct
	 * re-applies if an error is identified
	 * <p/>
	 * @return	status (0/-1)
	 * @throws Exception
	 */
	private int checkNavMetadata(int oid) throws Exception
	{
		Category cat;
		boolean problem = false;

		// get the metadata and verify study/project values
		try {

			cat = new Category(llserver);

			// do we have the navigation category
			if ( !hasCategory(oid, categoryId) ) {
				logger.info("CHECK: category missing");
				auditRecord(oid, "navigation category missing, reapplied" );
				return updateNavMetadata(oid);
			}

			cat.getObjectCategory( oid );
			cat.XML2DOM();

			if ( !cat.getValue("Customer").equals(customer) ) {
				logger.info("CHECK: customer attribute incorrect");
				auditRecord(oid, "customer attribute wrong" );
				problem = true;
			}
			if ( !cat.getValue("Quintiles Project Code").equals(project) ) {
				logger.info("CHECK: project code attribute incorrect");
				auditRecord(oid, "project code attribute wrong" );
				problem = true;
			}
			if ( !cat.getValue("Protocol Number").equals(protocol) ) {
				logger.info("CHECK: protocol attribute incorrect");
				auditRecord(oid, "protocol attribute wrong" );
				problem = true;
			}
			if ( !cat.getValue("Phase").equals( getPhase() ) ) {
				logger.info("CHECK: phase attribute incorrect");
				auditRecord(oid, "phase attribute wrong" );
				problem = true;
			}
			if ( !cat.getValue("Therapeutic Area").equals( getTherapyArea() ) ) {
				logger.info("CHECK: therapy attribute incorrect");
				auditRecord(oid, "therapy attribute wrong" );
				problem = true;
			}
			if (tier > 1) {
				if ( !cat.getValue("Country").equalsIgnoreCase( country_name_ ) ) {
					logger.info("CHECK: country attribute incorrect");
					auditRecord(oid, "country attribute wrong" );
					problem = true;
				}
				if ( !cat.getValue("Country Code").equalsIgnoreCase( country_code_ ) ) {
					logger.info("CHECK: country code attribute incorrect");
					auditRecord(oid, "country code attribute wrong" );
					problem = true;
				}
			}
			if (tier > 2) {
//				if ( !cat.getValue("Investigator Name").equals(  ) ) {
//					logger.info("CHECK: investigator name incorrect");
//					auditRecord(oid, "investigator name attribute wrong" );
//					problem = true;
//				}
				if ( !cat.getValue("Study Site ID").equals( site_id_ ) ) {
					auditRecord(oid, "site ID attribute wrong" );
					problem = true;
				}
				if ( !cat.getValue("Site Name").equals( site_name_ ) ) {
					auditRecord(oid, "site name wrong" );
					problem = true;
				}
			}

			// find any problems?
			if (problem) {
				auditRecord(oid, "navigation attribute error, reapplied" );
				return updateNavMetadata(oid);
			}

		}
		catch (Exception e) {
			logger.error("check category error, dataid = {}", oid);
			logger.error("check category exception", e);
			auditRecord(0, "check-nav-metadata exception: " + e.getMessage());
			throw ( new Exception("checker category error") );
		}

		logger.info("CHECK: navigation category check end");
		return 0;
	}

	/**
	 * verifies that the correct category has been applied
	 * to the object and attribute values are correct
	 * re-applies if an error is identified
	 * <p/>
	 * @return	status (0/-1)
	 * @throws Exception
	 */
	private int checkArtifactMetadata(int oid,  Map<String, Object> record, boolean fixcats, boolean unblinded) throws Exception
	{
		Category cat;
		int artCatId;
		boolean problem = false;

		// get the metadata and verify study/project values
		try {
			artCatId = ((BigDecimal) record.get("document_category")).intValue();

			cat = new Category(llserver);

			// is the doc naming category present
			if ( !hasCategory(oid, artCatId) ) {
				logger.info("CHECK: doc naming category missing");
				if (fixcats) {
					auditRecord(oid, "*ERR* document naming category missing, reapplied" );
					return updateNamingCatMetadata(oid, artCatId, unblinded, record);
				}
				else {
					auditRecord(oid, "*ERR* document naming category missing, manual fix required" );
					return -1;
				}
			}

			cat.getObjectCategory( oid );
			cat.XML2DOM();

			if ( !cat.getValue("Document Class").equals(tier_name_) ) {
				auditRecord(oid, "doc class attribute wrong" );
				problem = true;
			}
			if ( !cat.getValue("Zone").equals((String) record.get("zone_name")) ) {
				auditRecord(oid, "zone attribute wrong" );
				problem = true;
			}
			if ( !cat.getValue("Section").equals((String) record.get("section_name")) ) {
				auditRecord(oid, "section attribute wrong" );
				problem = true;
			}
			if ( !cat.getValue("Artifact").equals((String) record.get("artifact_name")) ) {
				auditRecord(oid, "artifact attribute wrong" );
				problem = true;
			}
			if ( !cat.getValue("DIA Key").equals((String) record.get("dia_key")) ) {
				auditRecord(oid, "DIA KEY attribute wrong" );
				problem = true;
			}
			// TMF is not on all naming categories, extra checking needed
			{
				String tmf_code = ((BigDecimal) record.get("tmf_file_yn")).intValue() == 1L ? "YES" : "NO";
				String tmf_val;

				try {
					tmf_val = cat.getValue("TMF");
					if ( !tmf_val.equals(tmf_code) ) {
						auditRecord(oid, "TMF attribute wrong" );
						problem = true;
					}
				}
				catch (NullPointerException npe) {
					// NOOP
				}
			}
			// UNBLINDED is not on all naming categories, extra checking needed
			{
				String ub_val;

				try {
					ub_val = cat.getValue("UNBLINDED");
					if ( !ub_val.equals(unblinded ? "-UB" : "") ) {
						auditRecord(oid, "UNBLINDED attribute wrong" );
						problem = true;
					}
				}
				catch (NullPointerException npe) {
					// NOOP
				}
			}

			// find any problems?
			if (problem) {
				auditRecord(oid, "document naming category attribute error, updated" );
				return updateNamingCatMetadata(oid, artCatId, unblinded, record);
			}

		}
		catch (Exception e) {
			logger.error("check naming category error", oid);
			auditRecord(0, "check-doc-naming-metadata exception: " + e.getCause());
			throw ( new Exception("checker category error") );
		}

		logger.info("CHECK: naming category check end");
		return 0;
	}

	/**
	 * adds the category for this tier to this object,
	 * since this is a child, the parent cat must be removed
	 * <p/>
	 * @return	status (0/-1)
	 * @throws Exception
	 */
	@Override
	protected int updateNavMetadata(int oid) throws Exception
	{
		Category cat;
		int rc = 0;

		logger.info("setting site metadata {} on {}", categoryId, oid);

		// get the metadata schema and add to the object
		try {

			cat = new Category(llserver);

			rc = cat.getCategory( categoryId );
			cat.XML2DOM();

			cat.setValue("Customer", customer);
			cat.setValue("Quintiles Project Code", project);
			cat.setValue("Protocol Number", protocol);
			cat.setValue("Phase", getPhase());
			cat.setValue("Therapeutic Area", getTherapyArea());
			if (tier > 1) {
				cat.setValue("Country", country_name_);
				cat.setValue("Country Code", country_code_);
			}
			if (tier > 2) {
				cat.setValue("Investigator Name", investigator_name_);
				cat.setValue("Study Site ID", site_id_);
				cat.setValue("Site Name", site_name_);
			}

			cat.DOM2XML();
			rc = cat.updateObject( oid );
		}
		catch (Exception e) {
			logger.error("set category on site folder ({})", oid);
			throw ( new Exception("check job category fail") );
		}

		return rc;
	}

	private int updateNamingCatMetadata(int oid, int artCatId, boolean unblinded, Map<String, Object> record)
					throws Exception
	{
		Category cat;
		int rc;

		// get the metadata XML schema and add to the object
		cat = new Category(llserver);
		cat.getCategory( artCatId );
		cat.XML2DOM();

		cat.setValue("Document Class", tier_name_);
		cat.setValue("Zone", (String) record.get("zone_name"));
		cat.setValue("Section", (String) record.get("section_name"));
		cat.setValue("Artifact", (String) record.get("artifact_name"));
		cat.setValue("DIA Key", (String) record.get("dia_key"));
		cat.setValue("TMF", ((BigDecimal) record.get("tmf_file_yn")).intValue() == 1L ? "YES" : "NO");
		cat.setValue("UNBLINDED", unblinded ? "-UB" : "");

		cat.DOM2XML();
		rc = cat.updateObject( oid );

		return rc;
	}


	// ******************************     VERIFY SECURITY GROUPS     ******************************
	/**
	 * verify that the configured project groups have been created
	 * <p/>
	 * @return 	status (0/-1)
	 */
	private int checkProjectGroups()
	{
		List<Map<String, Object>> rs1;
		String gname;
		int gid;
		int rc;

		// see if the groups have been created
		rc = 0;
		try {

			// get the dynamic groups to create
			rs1 = (new DbPackage.CreateGroups()).run( new Long(templateId) );

			for (Map<String, Object> rec : rs1)
			{
				gname = fmtGroupName( (String) rec.get("group_name") );

				gid = user.getGroup( gname );
				if (gid == -1) {
					logger.info("CHECK: {} group missing", gname);
					auditRecord(0, "group missing (created) - " + gname );

					gid = user.createGroup( gname );
					if (gid != -1) {
						// cache the group reference for later use by builder
						mapGroups.put(gname, new Integer(gid));
					}
					else {
						logger.error("could not create group {}", gname);
						auditRecord(0, "**FAIL** could not create " + gname );
					}
				}
				else {
					mapGroups.put(gname, new Integer(gid));
				}
			}
		}
		catch (Exception e) {
			logger.error("checker group error", e);
			auditRecord(0, "check-project-groups exception: " + e.getCause());
			return -1;
		}

		return rc;
	}

	/**
	 * verify the leaders for the dynamic project groups
	 * <p/>
	 * @return		status (0/-1)
	 */
	private int checkGroupLeadership()
	{
		List<Map<String, Object>> rs2;
		String lname, gname;
		int lid;
		int rc;

		// check group leadership
		rc = 0;
		try {

			// get the groups to update
			rs2 = (new DbPackage.GetGroupLeaders()).run( new Long(templateId) );
			for (Map<String, Object> rec : rs2)
			{
				gname = fmtGroupName( (String) rec.get("group_name") );
				lname = fmtGroupName( (String) rec.get("leadership") );

				lid = mapGroups.get(lname);

				if ( lid != user.getGroupLeader(gname, 1) ) {
					logger.info("CHECK: {} group does not have correct leader", gname);
					auditRecord(0, "wrong leader for group (restored) - " + gname );

					if (user.addGroupLeader(gname, 1, lname, 1) != 0) {
						logger.info("CHECK: {} could not set leader for {}", gname);
						auditRecord(0, "**FAIL** could not set leader for " + gname );
						rc = -1;
					}
				}
			}
		}
		catch (Exception e) {
			logger.error("checker group leader error", e);
			auditRecord(0, "check-group-leadership exception: " + e.getCause());
			return -1;
		}

		return rc;
	}

	/**
	 * verifies membership of all the project groups
	 * <p/>
	 * @param 	projectId	object ID for the project membership being updated
	 * @return	status		(0/-1)
	 */
	private int checkGroupMembership(int projectId)
	{
		List<Map<String, Object>> rs3;
		int rc;
		int rtype;
		String gname;
		String memberlist, members[];

		// check group membership
		rc = 0;
		try {

			// get the membership assignments from the template
			rs3 = (new DbPackage.GetGroupMembers()).run(new Long(templateId));

			for (Map<String, Object> rec : rs3)
			{
				LLValue gmembers;

				gname = fmtGroupName( (String) rec.get("group_name") );
				rtype = ((BigDecimal) rec.get("right_type")).intValue();
				memberlist = (String) rec.get("membership");
				members = memberlist.split(",");

				// see is the members are actually in the group
				logger.info("CHECK: inspecting group {}", gname);
				gmembers = new LLValue().setTable();

				gmembers = user.listGroupMembers(gname, ((rtype == 0) ? 1 : projectId));
				for (String s : members)
				{
					boolean exists = false;

					// is the member in the group list?
					for (int i = 0; i < gmembers.size(); i++) {
						if ( gmembers.toString(i, "NAME").equals( fmtGroupName(s) ) ) {
							exists = true;
							break;
						}
					}

					// could not find them?
					// try to add missing user/group back
					if ( !exists ) {
						int r;

						logger.info("CHECK: {} group does not have member {}", gname, fmtGroupName(s));
						auditRecord(0, "group " + gname + " missing subgroup (restored) " + fmtGroupName(s));

						r = user.addGroupMember(gname, ((rtype == 0) ? 1 : projectId), fmtGroupName( s ), 1);
						if (r != 0) {
							auditRecord(0, "**FAIL** could not add missing to group " + gname );
							rc = -1;
						}
					}
				}
			}

		}
		catch (Exception e) {
			logger.error("checker group membership error", e);
			auditRecord(0, "check-group-membership exception: " + e.getCause());
			return -1;
		}

		return rc;
	}


	// ******************************     PERMISSIONS CHECKS     **********************************
	/**
	 * permissions verification --
	 * two verifications are required, first that all groups
	 * on the object are valid, and second that all groups in
	 * the navigation list are present
	 * <p/>
	 * the function makes a copy of the source list because
	 * it erases the list during processing
	 * <p/>
	 * @param objectId        objectID being inspected
	 * @param perm_list       permission list
	 * @param ibr             is this an IBR folder?
	 * @return
	 */
	private int checkPermissions(int objectId, List<Map<String, Object>> perm_list, boolean ibr)
	{
		LLValue perms;
		String gname;
		int gid;
		int permission;
		List<Map<String, Object>> working_perms;
		int ownerCreate = Document.CONSUMER
									| LAPI_DOCUMENTS.PERM_MODIFY
									| LAPI_DOCUMENTS.PERM_DELETE
									| LAPI_DOCUMENTS.PERM_DELETEVERSIONS;

		// make working copy of nav perms list
		working_perms = new ArrayList<Map<String, Object>>( perm_list );

		int rc;

		rc = 0;
		logger.debug("checking navigation permissions");

		try {

			// get the object perms
			perms = new LLValue();
			perms = doc.getPermissions( objectId );

			// iterate through the folder rights list
			for (int i = 0; i < perms.size(); ++i)
			{
				boolean matched = false;

				// skip system permissions
				if ( perms.toInteger(i, "rightid") < 1 ) {

					// verify the owner permission if this is an IBR
					if ( ibr && ( perms.toInteger(i, "rightid") == LAPI_DOCUMENTS.RIGHT_OWNER ) ) {

						if (perms.toInteger(i, "permissions") !=  ownerCreate) {
							rc = doc.updateObjectPermission(objectId, LAPI_DOCUMENTS.RIGHT_OWNER, ownerCreate);
							logger.error("IBR owner permissions reset");
							auditRecord(objectId, "IBR owner permissions reset");
						}
					}

					continue;
				}

				// verify that the rightID is in the list and set correctly
				for (Map<String, Object> prec : working_perms)
				{

					// get the group ID
					gname = fmtGroupName( (String) prec.get("group_name") );
					gid = findGroup(gname);
					if (gid == -1){
						logger.error("check job missing group {}", gname);
						auditRecord(objectId, "*ERR* missing security group " + gname);
						continue;
					}

					if (gid != perms.toInteger(i, "rightid")) {
						continue;
					}

					// we have a matching nav rightID
					matched = true;

					// verify permissions
					permission = ((BigDecimal) prec.get("permission")).intValue();
					if (permission != perms.toInteger(i, "permissions")) {

						// wrong permissions granted for this group
						logger.error("wrong permissions for {}", gname);
						auditRecord(objectId, "permissions error for " + gname + " (updated)");

						rc = doc.setObjectPermission(objectId, gid, permission, LAPI_DOCUMENTS.RIGHT_UPDATE);
						if (rc != 0 ) {
							logger.error("failed to update permissions {}", gname);
							auditRecord(objectId, "*ERR* could not update permissions " + gname);
						}
					}

					// nav right processed, remove from list
					working_perms.remove(prec);
					break;
				}

				// this means we could not match a permission in the nav list,
				// it must be removed
				if ( !matched ) {
					logger.error("extra permission group");
					auditRecord(objectId, "extra permission group (removed)");

					rc = doc.removeObjectPermission( objectId, perms.toInteger(i, "rightid") );
					if (rc != 0 ) {
						logger.error("failed to remove permissions {}", perms.toInteger(i, "rightid"));
						auditRecord(objectId, "*ERR* could not remove group " + perms.toInteger(i, "rightid"));
					}
				}

			}

			// is anything left in the nav list? if so the folder is
			// missing one of the template security groups
			if (working_perms.size() > 0) {

				for (Map<String, Object> prec : working_perms)
				{
					// get the group ID
					gname = fmtGroupName( (String) prec.get("group_name") );
					gid = findGroup(gname);
					permission = ((BigDecimal) prec.get("permission")).intValue();

					logger.error("missing permission group");
					auditRecord(objectId, "added missing security group: " + gname);

					rc = doc.addObjectPermission(objectId, gid, permission);
					if (rc != 0 ) {
						logger.error("failed to add permissions {}", gname);
						auditRecord(objectId, "*ERR* could not add security group " + gname);
					}
				}
			}

		}
		catch (Exception e) {
			logger.error("permissions check error", e);
			auditRecord(0, "check-perms exception: " + e.getCause());
			return -1;
		}

		return rc;
	}




	// ********************************************************************************************
	/*
	 * utility methods
	 */

	/*
	 * Go through a record set of folders and build any
	 * "start-up" items that are not present.
	 * <p/>
	 * The challenge to this procedure is UNBLINDED folders
	 * only exist once in the template list -- unblinded is an
	 * option that allows a parallel folder to be constructed.
	 * The trick for start-up folders is to recognize that one or
	 * the other of a blinded/unblinded pair is missing.
	 */
	private void completeTier(List<Map<String, Object>> record_set, String country, String site)
	{
		List<Integer> startupArtifacts;
		List<Map<String, Object>> jitArtifactRecords;

		// go through the template record set and remove all JIT items,
		// make a list of start-up folder ids
		startupArtifacts = new ArrayList<Integer>();
		jitArtifactRecords = new ArrayList<Map<String, Object>>();
		for (Map<String, Object> rec :  record_set)
		{
			int jit;
			int fid;
			int ub;

			jit = ((BigDecimal) rec.get("jit_yn")).intValue();
			fid = ((BigDecimal) rec.get("folder_id")).intValue();
			ub = ((BigDecimal) rec.get("unblinded_yn")).intValue();

			if (jit == 1) {
				jitArtifactRecords.add(rec);
			}
			else {
				startupArtifacts.add( fid );
				// tracked unblinded folders if the profile is unblinded
				if (studyProfile.isStudyUnblinded() && ub == 1) {
					startupArtifacts.add( -fid );
				}
			}
		}

		// now we have a minimal list of template folder IDs,
		// (UB folders are negative), we will remove all the
		// 'found' folders from the list
		// the template folder record_set will have the JIT removed
		record_set.removeAll( jitArtifactRecords );
		startupArtifacts.removeAll( foundArtifacts_ );


		// all reviews are done, build everything that remains
		// in the start-up folder ID list (remember that negative
		// FIDs represent UNBLINDED
		for (Map<String, Object> rec :  record_set)
		{
			int fid;

			fid = ((BigDecimal) rec.get("folder_id")).intValue();

			// regular folder
			if ( startupArtifacts.contains( fid ) ) {
				auditRecord(0, "missing folder " + (String) rec.get("dia_key"));
				buildFolder( rec, country, site, false );
			}
			// unblinded folder
			if ( startupArtifacts.contains( -fid ) ) {
				auditRecord(0, "missing folder " + (String) rec.get("dia_key") + " [UNBLINDED]");
				buildFolder( rec, country, site, true);
			}
		}

	}

	/*
	 * construct a start-up folder missing from the build
	 */
	private void buildFolder(Map<String, Object> record, String country, String site, boolean unblinded)
	{
		FolderFactory ff;

		// get a folder factory ready
		ff = new FolderFactory();
		ff.setCustomer( customer );
		ff.setProject( project );
		ff.setProtocol( protocol );

		if (country != null) {
			ff.setCountryCode( country );
		}
		if (site != null) {
			ff.setSiteNumber( site );
		}

		// get the artifact details from the record
		ff.setZone( (String) record.get("zone_name") );
		ff.setSection( (String) record.get("section_name") );
		if (unblinded) {
			ff.setArtifact( "UNBLINDED " + (String) record.get("artifact_name") );
		}
		else {
			ff.setArtifact( (String) record.get("artifact_name") );
		}

		// submit the folder request
		ff.submit();

		if (ff.getStatus() == 0) {
			auditRecord(ff.getLivelinkId(), "built startup folder "
								+ (String) record.get("dia_key")
								+ " "
								+ ((String) record.get("artifact_name")).split(" ", 2)[1]
				);
		}
		else {
			auditRecord(0, "*ERR* folder build failed");
		}

	}

	// checks for category applied to object
	private boolean hasCategory(int oid, int cid) throws Exception
	{
		Category cat;
		LLValue cids;

		cat = new Category(llserver);

		// get the categories for the object
		cids = new LLValue().setList();
		cids = cat.getObjectCategoryIds( oid );
		for (int i = 0; i < cids.size(); i++)
		{
			if ( cids.toValue(i).toInteger("ID") == cid ) {
				return true;
			}
		}
		return false;
	}


	// add entry to job audit trail
	private void auditRecord(int did, String message)
	{
		auditTrail.setAuditType("CHECK JOB");
		auditTrail.setDataId( (long) did );
		auditTrail.setDescription( message );
		auditTrail.setCountryName(country_name_);
		auditTrail.setSiteNumber(site_id_);

		auditTrailDAO_.insert( auditTrail );
	}


	// find record in current folder record-set.
	// the data record holds the spec for all folders in the tier
	private int findFolder(String key, int level, List<Map<String, Object>> folder_set)
	{
		String dia;
		String name;
		Map<String, Object> row;

		for (int i = 0; i < folder_set.size(); ++i)
		{
			dia = (String) folder_set.get(i).get("dia_key");
			row = folder_set.get(i);
			name = "";

			switch (level)
			{
				case 1:
					name = ((String) row.get("zone_name")).split(" ", 2)[1];
					break;
				case 2:
					if (row.get("section_name") == null) {
						continue;
					}
					name = ((String) row.get("section_name")).split(" ", 2)[1];
					break;
				case 3:
					if (row.get("artifact_name") == null) {
						continue;
					}
					name = ((String) row.get("artifact_name")).split(" ", 2)[1];
					break;
			}
			if (key.equals(dia + " " + name)) {
				return i;
			}
		}

		return -1;
	}

}

