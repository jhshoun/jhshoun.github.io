package com.quintiles.structures.builder;

import java.util.List;
import java.util.Map;

import com.quintiles.lapi.Category;
import com.quintiles.lapi.Document;
import com.quintiles.structures.db.DbPackage;

/**
 * Country Builder
 * <p/>
 * Class responsible for building the country class (tier)
 * within a structures project.
 * <p/>
 * The core project already exists, the container ID is in
 * the study profile. The country object is created with the
 * defined category, then the start-up folders are built out.
 * <p/>
 * @author John Shoun, Quintiles
 * @version $Revision$
 */
public class CountryBuilder extends BaseBuilder
{
	private String countryCode;
	private String countryName = "Duchy of Grand Fenwick";

	private Document doc;

	// superclass constructor
	public CountryBuilder(Long pid, Long jid, String country)
	{
		super(pid, jid);
		tier = 2;
		this.countryCode = country;
	}

	/**
	 * This is the main routine for managing the build of
	 * a single country container.
	 * The process is to get the container type, create, assign
	 * the defined category, then build the start-up folders.
	 * <p/>
	 * @return	object id or -1
	 */
	@Override
	public int buildContainer()
	{
		int llid;

		auditRecord(0, "<<START>> country build start: " + countryCode);

		// create the core object
		llid = this.createContainer();
		if ( llid != -1 ){

			// build the start-up folders
			this.buildStartUp( llid );
		}

		if (auditJobStatus("country build") != 0) { 
			llid = -1;
		}
		auditRecord(0, "<<END>> country build complete");

		return llid;
	}

	/**
	 * This builds just the empty country container.
	 * The process is to get the container type, create, assign
	 * the defined category.
	 * <p/>
	 * @return	object id or -1
	 */
	@Override
	public int createContainer()
	{
		int llid;

		// get Livelink object creators, and build
		doc = new Document(llserver);

		// get the tier configuration
		this.initTier();

		// create the core object
		llid = this.createCountry();
		if ( llid == -1 ){
			auditRecord(-1, "*ERR* country create fail");
			logger.error("country create folder failed");
			return -1;
		}

		// attach the base category for this tier
		try {
			this.updateMetadata( llid );
		}
		catch (Exception e1) {
			try {
				// remove the failed country
				doc.deleteObject(llid);
			}
			catch (Exception e2) {
				// NOOP
			}
			auditRecord(-1, "*ERR* country folder metadata error [" + e1.getMessage() + "]");
			logger.error("Country Builder metadata error", e1);
			return -1;
		}

		return llid;
	}


	/**
	 * gets the country name based on the code
	 * <p/>
	 * @param cc	the 2-character country code
	 * @return		the official country name
	 */
	public static String getCountry(String cc)
	{
		String cName;
		List<Map<String, Object>> rs;

		// get the full country name based on the code
		// look-up in country table
		rs = (new DbPackage.GetCountryName()).run( cc );

		if (rs == null){
			cName = "UNKNOWN COUNTRY";
		}
		else {
			cName = (String) rs.get(0).get("country");
		}

		return cName;
	}

	/**
	 * builds the country object within the project
	 * container
	 * <p/>
	 * @return	the Livelink object ID
	 */
	private int createCountry()
	{
		int prjId;
		int llid = -1;

		logger.info("creating country container for {}, {}, {}, {}", 
				customer, project, protocol, countryCode);

		// get the country name
		// look-up in country table
		countryName = CountryBuilder.getCountry(countryCode);

		// create the country object
		logger.debug("creating the country");
		try {

			// get the project ID
			// stored in the study profile
			prjId = studyProfile.getProjectLlId().intValue();
			if (prjId < 2001){
				auditRecord(-1, "*ERR* could not get the project folder");
				logger.error("could not get the project folder ID");
				return -1;
			}

			doc.setCountry(countryCode);
			llid = doc.createObject(-prjId, objType, countryName);
		}
		catch (Exception e) {
			auditRecord(llid, "*ERR* country folder fail [" + e.getMessage() + "]");
			logger.error("create country container error", e);
			return -1;
		}

		// create audit trail entry for project build
		auditTrail.setCountryName(countryName + " (" + countryCode + ")");
		auditRecord(llid, "create country folder");

		logger.info("create country {} ID {}", countryName, llid);

		return llid;
	}

	/**
	 * adds the category for this tier to this object, 
	 * since this is a child, the parent cat must be removed
	 * <p/>
	 * @return	status (0/-1)
	 * @throws Exception 
	 */
	private int updateMetadata(int oid) throws Exception
	{
		Category cat = null;
		int rc = 0;

		logger.info("setting country metadata {} on {}", categoryId, oid);

		// get the metadata schema and add to the object
		try {
			this.findStudy();

			cat = new Category(llserver);

			// start by removing the inherited metadata
			cat.removeObjectCats( oid );

			// init the category for this tier & set values
			rc = cat.getCategory( categoryId );
			cat.XML2DOM();

			cat.setValue("Customer", customer);
			cat.setValue("Quintiles Project Code", project);
			cat.setValue("Protocol Number", protocol);
			cat.setValue("Phase", getPhase());
			cat.setValue("Therapeutic Area", getTherapyArea());
			cat.setValue("Country", countryName);
			cat.setValue("Country Code", countryCode);

			cat.DOM2XML();
			rc = cat.updateObject( oid );
		}
		catch (Exception e) {
			auditRecord(oid, "*ERR* country folder metadata problem [" + e.getMessage() + "]");
			logger.error("set category on country folder ({})", oid);
			throw ( new Exception("Country Builder category fail") );
		}

		return rc;
	}

	// add entry to job audit trail
	private void auditRecord(int did, String message) 
	{
		auditTrail.setAuditType("COUNTRY BUILD");
		auditTrail.setDataId( (long) did );
		auditTrail.setDescription( message );

		auditTrailDAO_.insert( auditTrail );
	}


}
