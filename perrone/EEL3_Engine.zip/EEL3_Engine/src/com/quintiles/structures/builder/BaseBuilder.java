package com.quintiles.structures.builder;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.InitialContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.context.ApplicationContext;

import com.opentext.api.LAPI_DOCUMENTS;
import com.quintiles.lapi.Category;
import com.quintiles.lapi.Document;
import com.quintiles.lapi.User;
import com.quintiles.e3.data.dao.AuditTrailDAO;
import com.quintiles.e3.data.dao.ProjectJobDAO;
import com.quintiles.e3.data.dao.StudyProfileDAO;
import com.quintiles.e3.data.dao.model.AuditTrail;
import com.quintiles.e3.data.dao.model.ProjectJob;
import com.quintiles.e3.data.dao.model.StudyProfile;
import com.quintiles.e3.data.dao.model.nodb.ProjectJobStatusEnum;
import com.quintiles.structures.EelRequest;
import com.quintiles.structures.db.DbPackage;
import com.quintiles.structures.db.DbPackage.GetUnblindedPermissions;

// TODO review what audit events are needed and the object ID
// creates that should be logged

/**
 * Core implementation for container construction, these
 * items will be the base for initializing a copy of the DIA template
 * with folders tagged for the requested tier. Subclasses implement
 * the specific variations for a given tier.
 * <p/>
 * @author John Shoun, Quintiles
 * @version $Revision$
 */
public abstract class BaseBuilder
{
	protected Logger logger = LoggerFactory.getLogger("com.quintiles.structures.engine.jobs.BaseJob");

	// business models and data access
	protected ApplicationContext sc;
	
	protected StudyProfileDAO studyProfileDAO_;
	protected StudyProfile studyProfile;

	protected ProjectJobDAO projectJobDAO_;
	protected ProjectJob projectJob;

	protected AuditTrailDAO auditTrailDAO_;
	protected AuditTrail auditTrail;

	protected static String llserver;

	// local utility attributes
	// (some are duplicated in DAO models)
	protected String currentDIAkey;
	protected String customer;
	protected String project;
	protected String protocol;
	protected String phase;
	protected String therapyArea;
	protected int categoryId;
	protected int tier;					// tier ID within a template hierarchy
	protected int classMask;			// this is a bit mask for matching artifacts to a tier
	protected int objType;				// Livelink object type
	protected int templateId;
	// working dictionary of groups
	protected Map<String, Integer> mapGroups;

	//  init Livelink server
	static {
		try {
			llserver = (String) (new InitialContext( )).lookup("java:comp/env/livelinkServer");
		}
		catch (Exception e){
			llserver = "exception";
		}
	}


	public BaseBuilder()
	{
		// auto-generated constructor stub
	}

	/**
	 * constructor that takes the study profile ID and 
	 * job ID and initializes the reference data
	 * from the database
	 * <p/>
	 * @param pid	study profile ID number
	 * @param jid	project job ID number
	 */
	public BaseBuilder(Long pid, Long jid)
	{
		super();

		// load the database entries
		initBuilder(pid, jid);
	}

	/**
	 * retrieves the study profile and job detail records
	 * from the database and initializes the reference objects
	 * <p/>
	 * @param pid	study profile ID number
	 * @param jid	project job ID number (optional)
	 */
	public void initBuilder(Long pid, Long jid)
	{
		logger.debug("initializing study, project records");

		// manual DAO injection
		sc = EelRequest.getSpringContext();
		studyProfileDAO_ = sc.getBean(StudyProfileDAO.class);
		projectJobDAO_ = sc.getBean(ProjectJobDAO.class);
		auditTrailDAO_ = sc.getBean(AuditTrailDAO.class);

		// load the objects
		studyProfile = studyProfileDAO_.findById( pid );
		if (jid != null){
			projectJob = projectJobDAO_.findByProjectJobIdAndProfileId(jid, pid);
		}

		// start an audit trail object
		// used by the implementing classes
		auditTrail = new AuditTrail();
		auditTrail.setAuditType("BASE BUILD");
		auditTrail.setProjectJobId( jid );
		auditTrail.setProfileId( studyProfile.getProfileId() );
		auditTrail.setTemplateId( studyProfile.getTemplateId() );
		auditTrail.setTransUser("EEL Service");

		customer = studyProfile.getProject().getCustomer().getCustomerName();
		project = studyProfile.getProject().getProjectCode();
		protocol = studyProfile.getProject().getProjectNumber();
		templateId = studyProfile.getTemplateId().intValue();

		// initialize the group map
		// (saves repeated look-ups to find groupdID from name)
		mapGroups = new HashMap<String, Integer>();

	}

	/**
	 * updated the project job record in the database
	 * <p/>
	 * @param statusNo	status code
	 * @param msg		status message
	 */
	public void jobStatus(ProjectJobStatusEnum statusNo, String msg)
	{

		if (projectJob == null){
			return;
		}

		logger.debug("updating job status");
		projectJob.setServerId( System.getenv("COMPUTERNAME") );
		projectJob.setStatus( statusNo );
		projectJob.setStatusMessage(msg);
		projectJobDAO_.update( projectJob );
	}

	/**
	 * main execution routine for the particular container,
	 * builds all the startup folders along with any 
	 * specific configurations for the container type
	 * <p/>
	 * @return	object ID for new container
	 */
	public abstract int buildContainer();

	/**
	 * utility routine to build empty container
	 * <p/>
	 * @return	object ID for new container
	 */
	public abstract int createContainer();


	/**
	 * the hierarchy record for the template holds values
	 * for creating the object, cats & atts, and mask to
	 * match the tier artifacts
	 * <p/>
	 */
	public void initTier()
	{
		List<Map<String, Object>> rs;

		logger.info("getting tier build parameters for {}, {}, {}", customer, project, protocol);

		// query for the tier parameters
		rs = (new DbPackage.GetTier()).run(new Long(templateId), new Long(tier));

		// get the Livelink object type
		objType = ((BigDecimal) rs.get(0).get("subtype")).intValue();

		// get the common category ID for this tier
		categoryId = ((BigDecimal) rs.get(0).get("category_id")).intValue();

		// need the class mask for matching tier folders
		classMask = ((BigDecimal) rs.get(0).get("class_mask")).intValue();
	}


	/**
	 * constructs the list of all start-up (non-JIT) folders
	 * that should be built for this tier (project,country,site)
	 * <p/>
	 * the folders are all constructed in the referenced parent,
	 * the document naming category is added to the artifact (leaf) folder
	 * <p/>
	 * @param parentId		parent container ID
	 * @return				0/-1
	 */
	public int buildStartUp(int parentId)
	{
		int rc = 0;
		String diaKey;
		int fid;
		int pfid;
		int subtype;
		int namingCatId;
		String tName;
		String aName;
		String comment;
		boolean isTmf;

		List<Map<String, Object>> rs1;

		// get the list of folders for this tier
		rs1 = (new DbPackage.GetFolderList()).run(new Long(templateId), new Long(tier), 0L);

		// create each startup folder found
		for (int i = 0; i < rs1.size(); ++i)
		{

			// get the args and pass to folder build
			fid = ((BigDecimal) rs1.get(i).get("folder_id")).intValue();
			pfid = ((BigDecimal) rs1.get(i).get("parent_folder_id")).intValue();
			diaKey = (String) rs1.get(i).get("dia_key");
			subtype = ((BigDecimal) rs1.get(i).get("subtype")).intValue();
			namingCatId = ((BigDecimal) rs1.get(i).get("document_category")).intValue();
			tName = (String) rs1.get(i).get("tier_name");
			aName = (String) rs1.get(i).get("artifact_name");
			comment = (String) rs1.get(i).get("description");
			if ( ((BigDecimal) rs1.get(i).get("tmf_file_yn")).intValue() == 1L ){
				isTmf = true;
			}
			else {
				isTmf = false;
			}

			// build the regular folder
			this.buildFolder(fid, parentId, pfid, diaKey, 
					aName, tName, subtype, namingCatId, comment,
					isTmf, false);

			// if artifact allow unblinded, build second folder
			// but first see if this study allows unblinded
			if ( studyProfile.isStudyUnblinded() ){
				if ( ((BigDecimal) rs1.get(i).get("unblinded_yn")).intValue() == 1 ){
					this.buildFolder(fid, parentId, pfid, diaKey, 
							aName, tName, subtype, namingCatId, comment,
							isTmf, true);
				}
			}

		}

		return rc;
	}
	
	/**
	 * constructs a single just-in-time (JIT) folder
	 * <p/>
	 * the target is identified by zone, section, artifact
	 * names (instead of DIA), because web requests come in that way
	 * <p/>
	 * the artifact name is parsed to determine if the item is UNBLINDED
	 * <p/>
	 * @param parentId		parent container ID
	 * @param zone			DIA zone name
	 * @param section		DIA section name
	 * @param artifact		DIA artifact name
	 * @return				folder id or -1
	 * @throws Exception 
	 */
	public int buildJIT(int parentId, String zone, String section, String artifact) 
			throws Exception
	{
		String diaKey;
		int fid;
		int pfid;
		int subtype;
		int namingCatId;
		String tName;
		String aName;
		String comment;
		boolean requestUnblinded = false;
		boolean allowUnblinded = false;
		boolean isTmf = false;

		// are we looking for an unblinded item?
		if ( artifact.startsWith("UNBLINDED") ){
			requestUnblinded = true;
			artifact = artifact.replace("UNBLINDED ", "");
		}

		// query to get the build list for the artifact
		List<Map<String, Object>> rs1;
		rs1 = (new DbPackage.GetJITRecord()).run(new Long(templateId), new Long(tier), zone, section, artifact);

		if (rs1.size() < 1){
			logger.error("referenced DIA not in template [{} / {} / {}] ", 
					zone, section, artifact);
			return -1;
		}

		// create JIT folder (should be just one)
		// get the args and pass to folder build
		fid = ((BigDecimal) rs1.get(0).get("folder_id")).intValue();
		pfid = ((BigDecimal) rs1.get(0).get("parent_folder_id")).intValue();
		diaKey = (String) rs1.get(0).get("dia_key");
		subtype = ((BigDecimal) rs1.get(0).get("subtype")).intValue();
		namingCatId = ((BigDecimal) rs1.get(0).get("document_category")).intValue();
		tName = (String) rs1.get(0).get("tier_name");
		aName = (String) rs1.get(0).get("artifact_name");
		comment = (String) rs1.get(0).get("description");
		if ( ((BigDecimal) rs1.get(0).get("tmf_file_yn")).intValue() == 1 ){
			isTmf = true;
		}
		if ( ((BigDecimal) rs1.get(0).get("unblinded_yn")).intValue() == 1 ){
			allowUnblinded = true;
		}

		// is unblinded valid for the artifact
		if ( requestUnblinded && !allowUnblinded ){
			throw new Exception("UNBLINDED not allowed for this artifact");
		}

		return this.buildFolder(fid, parentId, pfid, diaKey, 
							aName, tName, subtype, namingCatId, comment,
							isTmf, requestUnblinded);
	}

	/**
	 * constructs a single artifact folder and populates
	 * the defined metadata,
	 * creates or locates the required parent folders
	 * <p/>
	 * the folders are all in the referenced parent
	 * <p/>
	 * @param folderTemplateId			ID of the template folder being created
	 * @param parentId					Livelink container to hold object
	 * @param folderTemplateParentId	ID of the template folders parent template
	 * @param diaKey					DIA reference key
	 * @param artifactName				name
	 * @param tier						core, country, site tier code
	 * @param subtype					artifact subtype
	 * @param namingCatId				document category
	 * @param dcomment					content server object comment
	 * @return							folder ID or -1
	 */
	public int buildFolder(int folderTemplateId, int parentId, 
					int folderTemplateParentId,
					String diaKey, String artifactName, String tier,
					int subtype, int namingCatId, String dcomment,
					boolean tmf, boolean unblinded)
	{
		Document doc;
		Category cat;
		String fname;

		// query to get zone & section for an artifact
		List<Map<String, Object>> rs2;

		String subDiaKey;
		int zoneId, sectionId;
		int folderId = -1;
		int rc = -1;

		// save dia for external reference
		currentDIAkey = diaKey;

		// get and/or build path, create artifact + metadata + perms
		try
		{
			doc = new Document(llserver);

			rs2 = (new DbPackage.GetParentList()).run(new Long(folderTemplateParentId));

			// make,get the zone
			subDiaKey = (String) rs2.get(0).get("dia_key");
			fname = (String) rs2.get(0).get("zone_name");
			zoneId = doc.createObject(parentId, LAPI_DOCUMENTS.FOLDERSUBTYPE, fname);

			// make,get the section
			subDiaKey = (String) rs2.get(1).get("dia_key");
			fname = subDiaKey + " " + ((String) rs2.get(1).get("section_name")).split(" ", 2)[1];
			sectionId = doc.createObject(zoneId, LAPI_DOCUMENTS.FOLDERSUBTYPE, fname);

			// make,get the artifact
			if ( unblinded ){
				fname = diaKey + " UNBLINDED " + artifactName.split(" ", 2)[1];
			}
			else {
				fname = diaKey + " " + artifactName.split(" ", 2)[1];
			}
			folderId = doc.createObject(sectionId, subtype, fname, dcomment);
			if (folderId > 1000) {
				auditRecord(folderId, "built artifact " + fname);
			}

			// apply the doc naming category to the artifact
			logger.info("setting artifact metadata {} on {}", namingCatId, folderId);

			// get the metadata XML schema and add to the object
			cat = new Category(llserver);
			rc = cat.getCategory( namingCatId );
			cat.XML2DOM();

			cat.setValue("Document Class", tier);
			cat.setValue("Zone", (String) rs2.get(0).get("zone_name"));
			cat.setValue("Section", (String) rs2.get(1).get("section_name"));
			cat.setValue("Artifact", artifactName);
			cat.setValue("DIA Key", diaKey);
			cat.setValue("TMF", tmf ? "YES" : "NO");
			cat.setValue("UNBLINDED", unblinded ? "-UB" : "");

			cat.DOM2XML();
			rc = cat.updateObject( folderId );
			if (rc != 0) {
				auditRecord(folderId, "*ERR* folder naming category fail -- " + cat.getConnection().getStatusMessage());
			}

			// set the artifact level permissions
			rc = setPermissions( folderTemplateId, folderId, unblinded, tmf );
		}
		catch (Exception e) {
			// log the error, but press on
			auditRecord(folderId, "*ERR* problem building folder [" + e.getMessage() + "]");
			logger.error("folder build fail", e);
			return -1;
		}
		if (rc != 0) {
			// log the error, not sure what happened
			auditRecord(folderId, "*ERR* unknown folder build problem");
			logger.error("folder build error *unknown code* [" + rc + "]");
		}

		return folderId;
	}

	/**
	 * applies the navigation category (project, country, site)
	 * to the target object
	 * <p/>
	 * @param oid
	 * @return
	 * @throws Exception
	 */
	protected int updateNavMetadata(int oid) throws Exception
	{
		Category cat;
		int rc = 0;

		logger.debug("setting core metadata {} on {}", categoryId, oid);

		// get the metadata schema and add to the object
		try {
			this.findStudy();

			cat = new Category(llserver);
			rc = cat.getCategory( categoryId );
			cat.XML2DOM();

			cat.setValue("Customer", customer);
			cat.setValue("Quintiles Project Code", project);
			cat.setValue("Protocol Number", protocol);
			cat.setValue("Phase", getPhase());
			cat.setValue("Therapeutic Area", getTherapyArea());

			cat.DOM2XML();
			rc = cat.updateObject( oid );
			if (rc != 0) {
				auditRecord(oid, "*ERR* navigation category update fail -- " 
									+ cat.getConnection().getStatusMessage());
			}
		}
		catch (Exception e) {
			auditRecord(oid, "*ERR* failed to set core category [" + e.getMessage() + "]");
			logger.error("set category on core project ({})", oid);
			throw ( new Exception("Builder category fail") );
		}

		return rc;
	}

	/**
	 * sets the access permissions on a single artifact
	 * <p/>
	 * all permissions are revoked (inherited navigation and
	 * project guest, but not owner) and replaced by the
	 * selected security groups for the level
	 * <p/>
	 * @param templateFolderId    DIA template folder ID
	 * @param objectId            content server object being updated
	 * @param unblinded           is this an unblinded folder?
	 * @param tmf                 is this a TMF content folder?
	 * @return		status (0/-1)
	 */
	private int setPermissions(int templateFolderId, int objectId, boolean unblinded, boolean tmf)
	{
		Document doc;
		int rc = 0;
		String gname;
		int gid;
		int perms;

		List<Map<String, Object>> rs3;

		logger.info("setting artifact permission");
		doc = new Document(llserver);

		// start by revoking the guest permissions
		gid = findGroup("Guests");
		if (gid == -1){
			auditRecord(objectId, "*ERR* could not find project guests");
			logger.error("could not find project guests");
		}
		else {
			rc = doc.removeObjectPermission(objectId, gid);
			if (rc != 0) {
				logger.error("did not remove GUEST perm {} from {} [rc = {}]", gid, objectId, rc);
				auditRecord(objectId, "*ERR* failed to strip artifact GUEST right -- " 
										+ doc.getConnection().getStatusMessage());
			}
		}
		// and any other inherited perms
		rc = doc.clearObjectPermissions( objectId );
		if (rc != 0) {
			logger.error("could not clear rights from {} [rc = {}]", objectId, rc);
			auditRecord(objectId, "*ERR* failed to strip artifact inherited rights -- " 
									+ doc.getConnection().getStatusMessage());
		}

		// owner delete rights
		// add DELETE & DELETE_VERSIONS to owner for IBR content
		if ( !tmf ) {
			rc = doc.updateObjectPermission(
											objectId, 
											LAPI_DOCUMENTS.RIGHT_OWNER, 
											Document.CONSUMER 
												| LAPI_DOCUMENTS.PERM_MODIFY 
												| LAPI_DOCUMENTS.PERM_DELETE 
												| LAPI_DOCUMENTS.PERM_DELETEVERSIONS
										);
			if (rc != 0) {
				auditRecord(objectId, "*ERR* failed to set artifact owner rights -- " 
										+ doc.getConnection().getStatusMessage());
			}
		}

		// get the configured rights for this artifact
		if ( unblinded ) {
			rs3 = (new GetUnblindedPermissions()).run(
														new Long(templateFolderId), 
														new Long(classMask), 
														new Long(templateId)
													);
			if (rc != 0) {
				auditRecord(objectId, "*ERR* failed to set artifact UNBLINDED rights -- " 
										+ doc.getConnection().getStatusMessage());
			}
		}
		else {
			rs3 = (new DbPackage.GetArtifactPermissions()).run(
														new Long(templateFolderId), 
														new Long(classMask), 
														new Long(templateId)
													);
			if (rc != 0) {
				auditRecord(objectId, "*ERR* failed to set artifact rights -- " 
										+ doc.getConnection().getStatusMessage());
			}
		}

		for (Map<String, Object> rec : rs3)
		{
			gname = fmtGroupName( (String) rec.get("group_name") );
			perms = ((BigDecimal) rec.get("permission")).intValue();

			gid = findGroup(gname);
			if (gid == -1){
				logger.error("could not find group {}", gname);
				continue;
			}

			rc = doc.addObjectPermission(objectId, gid, perms);
			if (rc != 0) {
				auditRecord(objectId, "*ERR* failed to set artifact dynamic rights -- " + gname);
			}
		}

		return rc;
	}


	/**
	 * looks up some study attributes from ELVIS_REF
	 * <p/>
	 */
	// TODO this belongs somewhere else
	protected void findStudy()
	{
		List<Map<String, Object>> rs;

		logger.info("locating study info for {}, {}, {}", customer, project, protocol);

		// query for the tier parameters
		rs = (new DbPackage.GetProjectData()).run(customer, project, protocol);
		if (rs.size() < 1) {
			return;
		}

		// get study phase and area
		this.setPhase( (String) rs.get(0).get("phase") );
		this.setTherapyArea( (String) rs.get(0).get("therapeutic_area") );
	}

	/**
	 * utility method for locating a group in the MAP, if
	 * the group is missing then it is located and added
	 * <p/>
	 * @param gname		name of group to locate
	 * @return			group ID number
	 */
	protected int findGroup(String gname)
	{
		List<String> projectGroups = Arrays.asList("Coordinators", "Members", "Guests");
		User user;
		int gid;

		user = new User(llserver);

		// if group is in cache, then return ID
		if ( mapGroups.containsKey(gname) ){
			return mapGroups.get(gname).intValue();
		}

		// otherwise, look it up and add to cache
		// project groups are a special case
		if ( projectGroups.contains(gname) ){
			gid = user.getGroup(gname, studyProfile.getProjectLlId().intValue());
			mapGroups.put(gname, new Integer(gid));
		}
		else{
			gid = user.getGroup(gname);
			mapGroups.put(gname, new Integer(gid));
		}

		return gid;
	}

	/**
	 * shared method for generating the group INFIX using
	 * the customer and project code or the alternate identifier
	 * <p/>
	 * @return	group infix	
	 */
	protected String groupInfix()
	{
		String infix;

		if (studyProfile.getGroupPrefixName() == null)
			infix = customer + "_" + project;
		else
			infix = customer + "_" + studyProfile.getGroupPrefixName();
		return infix.toUpperCase();
	}

	/**
	 * The configured group names have substitution parameters.
	 * This constructs the required name from the study profile
	 * values.
	 * <p/>
	 * The string "<>" is replaced by the custom group infix.
	 * The string "^^" is replaced by the study type.
	 * <p/>
	 * @return	group name
	 */
	protected String fmtGroupName(String stub)
	{
		String iname, gname;

		iname = stub.replace("<>", groupInfix().toUpperCase() );
		gname = iname.replace("^^", studyProfile.getStudyType().replaceAll(" ", "_").toUpperCase() );

		return gname;
	}

	// add entry to job audit trail
	private void auditRecord(int did, String message) 
	{
		auditTrail.setDataId( (long) did );
		auditTrail.setDescription( message );

		auditTrailDAO_.insert( auditTrail );
	}

	// audit the job status
	protected int auditJobStatus(String jName) 
	{
		List<Map<String, Object>> rs6;

		try {
			int ecount;

			// count errors in audit trail
			rs6 = (new DbPackage.JobErrors()).run( auditTrail.getProjectJobId() );
			ecount = ((BigDecimal) rs6.get(0).get("ERR_COUNT")).intValue();
			if (ecount > 0) {
				auditRecord(-1, "*ERR* " + jName + " had " + ecount + " errors");
				return -1;
			}
		}
		catch (Exception e) {
			// NOOP
		}

		return 0;
	}


	/**
	 * accessors
	 */
	public String getCustomer() { 
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getProject() { 
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}

	public String getProtocol() {
		return protocol;
	}
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	public String getPhase() { 
		if (phase == null)
			return "";
		else
			return phase; 
	}
	public void setPhase(String phase) {
		this.phase = phase;
	}

	public String getTherapyArea() {
		if (therapyArea == null)
			return "";
		else
			return therapyArea;
	}
	public void setTherapyArea(String therapyArea) {
		this.therapyArea = therapyArea;
	}

	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public int getTier() {
		return tier;
	}
	public void setTier(int tier) {
		this.tier = tier;
	}

	public int getClassMask() {
		return classMask;
	}
	public void setClassMask(int classMask) {
		this.classMask = classMask;
	}

	public int getObjType() {
		return objType;
	}
	public void setObjType(int objType) {
		this.objType = objType;
	}

	public int getTemplateId() { 
		return templateId;
	}
	public void setTemplateId(int templateId) {
		this.templateId = templateId;
	}

	public String getDIA() { 
		return currentDIAkey;
	}
	
}
