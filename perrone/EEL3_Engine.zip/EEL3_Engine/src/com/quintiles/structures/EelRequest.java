package com.quintiles.structures;


import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;

import org.quartz.ee.servlet.QuartzInitializerListener;
import org.quartz.impl.StdSchedulerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.core.util.StatusPrinter;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.quintiles.structures.engine.JobFactory;
import com.quintiles.structures.engine.SiteBatchFactory;

// TODO add basic authentication to secure all services

/**
 * testing servlet
 *
 */
public class EelRequest
				extends javax.servlet.http.HttpServlet
				implements javax.servlet.Servlet
{
	/** SID */
	private static final long serialVersionUID = 4286375800176746966L;
	private static Logger qlog;
	private static ApplicationContext springContext;
	public static String build;


	/* initialization here  */
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);

		// get the build number, for internal reference
		try {
			Configuration rb;
			rb = new PropertiesConfiguration("application.properties");
			build = rb.getString("version.label");
		}
		catch (ConfigurationException e) {
			build = "3.x";
		}

		// store the context and scheduler factory for general use 
		ServletContext ctx;

		qlog = LoggerFactory.getLogger("com.quintiles.structures.EelRequest");
		qlog.debug("build servlet initialization"); 

		// print internal state 
		LoggerContext lc = (LoggerContext) LoggerFactory.getILoggerFactory(); 
		StatusPrinter.print(lc); 

		// get Quartz scheduler and pass to the factories
		// TODO this has to be improved (time to spring?)
		qlog.info("Quartz factory reference"); 
		ctx = this.getServletContext();
		JobFactory.setScheduler( 
					(StdSchedulerFactory) ctx.getAttribute(QuartzInitializerListener.QUARTZ_FACTORY_KEY)
				);
		SiteBatchFactory.setScheduler( 
				(StdSchedulerFactory) ctx.getAttribute(QuartzInitializerListener.QUARTZ_FACTORY_KEY)
			);

		// set shared access to the Spring context
		// using manual injection right now
		// TODO better ideas?
		qlog.info("track spring context"); 
		springContext = WebApplicationContextUtils.getRequiredWebApplicationContext(ctx);
	}

	// access to the Spring context
	public static ApplicationContext getSpringContext()
	{
		return springContext;
	}

	// access to the Spring context
//	public static void setSpringContext(ApplicationContext ctx)
//	{
//		springContext = ctx;
//	}

	/* main request/response handler */
	protected void doGet(HttpServletRequest req, HttpServletResponse response)
			throws ServletException, IOException
	{
		PrintWriter jout;

		// this is just for testing, should return as JSON type
		if ( req.getHeader("user-agent") == null )
			response.setContentType("application/json");
		else
			response.setContentType("text/plain");
		jout = response.getWriter();

		jout.flush();
	}

	/* HTTP post not supported for this servlet -- ignored */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		// NOOP
	}


}

 