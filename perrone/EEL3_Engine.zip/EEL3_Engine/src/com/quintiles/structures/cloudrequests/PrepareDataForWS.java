package com.quintiles.structures.cloudrequests;

import java.io.File;

import com.quintiles.structures.engine.utility.Configuration;
import com.quintiles.structures.engine.utility.ConfigurationInterface;

/**
 * @author q791213
 * 
 * main class for the class that deal with preparing the data to send to wingspan
 * 
 */
public abstract class PrepareDataForWS
{
	protected WSRequest _request;
	protected File _file = null;
	protected String _hostingEnv = null;

	private ConfigurationInterface _configuration = null;

	/**
	 * allow add request instance from outside,
	 * 
	 * create a new WS rest request based on the supplied class
	 */
	public abstract void createRequestIns(String env);

	/**
	 * child class to trigger the web service call;
	 * for GET, DELETE web REST call 
	 * (file is not required)
	 * 
	 * @return
	 * @throws Exception
	 */
	protected String sendRequest() throws Exception
	{
		return _request.sendRequest(_file);
	}

	/**
	 * public interface to trigger execution
	 * 
	 */
	public abstract Object execute() throws Exception;


	// configuration, lazy initialization
	public ConfigurationInterface get_config()
	{
		if(_configuration == null){
			_configuration = new Configuration();
		}
		return _configuration;
	}


}
