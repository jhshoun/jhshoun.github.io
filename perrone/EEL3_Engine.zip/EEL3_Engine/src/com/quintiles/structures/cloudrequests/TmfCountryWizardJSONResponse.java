package com.quintiles.structures.cloudrequests;

/**
 * TMF Country Wizard JSON response
 * @author q766769
 *
 * very simple POJO class to de-serialize the Wingspan
 * response to a request for all known countries for
 * a study
 */
public class TmfCountryWizardJSONResponse
{
	public int totalCount;
	public String message;
	public String version;
	public Country[] data;

	public static class Country
	{
		public String id;
		public String name;
		public String status;
	}

}

