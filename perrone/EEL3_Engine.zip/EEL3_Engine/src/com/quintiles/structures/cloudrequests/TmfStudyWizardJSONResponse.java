package com.quintiles.structures.cloudrequests;

/**
 * TMF Study Wizard JSON response
 * @author q766769
 *
 * very simple POJO class to de-serialize the Wingspan
 * response to a request for all known studies
 */
public class TmfStudyWizardJSONResponse
{
	public int totalCount;
	public String message;
	public String version;
	public Study[] data;

	public static class Study
	{
		public String id;
		public String name;
		public String status;
		public String programCode;
		public String diseaseArea;
		public String studyIdentifier;
		public String studyDescription;
		public String sponsor;
		public String studyOwner;
		public Links links;
	}

	public static class Links
	{
		public String self;
		public String countries;
		public String sites;
		public String studyMetrics;
	}

}

