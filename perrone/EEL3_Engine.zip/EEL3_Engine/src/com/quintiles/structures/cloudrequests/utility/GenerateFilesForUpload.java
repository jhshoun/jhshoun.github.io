/**
 * 
 */
package com.quintiles.structures.cloudrequests.utility;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.List;

/**
 * generate files in file system,
 *     the default column delimiter is comma
 *     option quote flag encloses in double quotation mark
 *     all values are escaped for embedded quotation mark
 *
 */
public class GenerateFilesForUpload
{
	private static final char DEFAULT_SEPARATOR = ',';

	// line w/comma and no quoted strings
	public static void writeLine(OutputStreamWriter w, List<String> values) throws IOException
	{
		writeLine(w, values, DEFAULT_SEPARATOR, false);
	}

	// line w/comma and quoted strings flag
	public static void writeLine(OutputStreamWriter w, List<String> values, boolean csvQuote) throws IOException
	{
		writeLine(w, values, DEFAULT_SEPARATOR, csvQuote);
	}

	// line w/separator and no quoted strings
	public static void writeLine(OutputStreamWriter w, List<String> values, char separator) throws IOException
	{
		writeLine(w, values, separator, false);
	}

	/**
	 * write content one line at a time
	 * 
	 * @param w
	 * @param values
	 * @param separators
	 * @param csvQuote (enclose all strings in double quotes)
	 * @throws IOException
	 */
	public static void writeLine(
							OutputStreamWriter w, 
							List<String> values, 
							char separator, 
							boolean csvQuote
													) throws IOException
	{
		StringBuilder sb;
		boolean first = true;
		char delimiter;

		//default customQuote is empty

		delimiter = (separator == 0) ? DEFAULT_SEPARATOR : separator;

		sb = new StringBuilder();
		for (String value : values)
		{
			if (!first) {
				sb.append(delimiter);
			}
			if (csvQuote) {
				sb.append('"').append(escapeQuotes(value)).append('"');
			}
			else {
				sb.append(escapeQuotes(value));
			}

			first = false;
		}
		sb.append("\n");
		w.append(sb.toString());
	}

	// https://tools.ietf.org/html/rfc4180
	/**
	 * escape double quotes so that CSV files will load properly
	 * 
	 * @param value
	 * @return
	 */
	private static String escapeQuotes(String value)
	{
		String result = value;

		if (result != null) {
			if (result.contains("\"")) {
				result = result.replace("\"", "\"\"");
			}
		}
		return result;
	}

}
