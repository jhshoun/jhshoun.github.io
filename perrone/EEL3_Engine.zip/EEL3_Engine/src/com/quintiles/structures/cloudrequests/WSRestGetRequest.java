package com.quintiles.structures.cloudrequests;

import java.io.File;

import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author q791213, q766769
 * 
 * implements GET request client using javax.ws REST
 */
public class WSRestGetRequest extends WSRequest
{
	private Logger logger = LoggerFactory.getLogger(WSRestGetRequest.class);

	// constructor
	WSRestGetRequest(String user, String password, String host, String path)
	{
		super(user, password, host, path);
	}

	/*
	 * sends a generic request GET request (FILE is discarded),
	 * returns the JSON encoded response string
	 */
	@Override
	public String sendRequest(File do_not_use)
	{
		WebTarget target;
		Response response;
		String responseText;

		try {

			target = client.target(_server);

			response = target
							.path( _path )
							.request(MediaType.APPLICATION_JSON)
							.header("Authorization", authHeader())
							.get();

			logger.info("REST request: {} / {}", target.getUri().toString(), _path);

			if (response.getStatus() >= 300) {
				String error;

				error = response.getStatusInfo().getReasonPhrase();
				logger.error("Wingspan: rest error - [{}] {}", response.getStatus(), error);
				logger.error("Wingspan: rest error >> {}", response.readEntity(String.class));
				throw new Exception("Wingspan: rest error - " + error);
			}

			responseText = response.readEntity(String.class);
			logger.debug("REST response: {}", 
							responseText.length() > 260 ? responseText.substring(0, 250) : responseText
						);
			return responseText;
		}
		catch (Exception e) {
			logger.error("request error: {}{}", _server, _path);
			logger.error("request error", e);
		}
		finally {
			client.close();
		}

		return "null";
	}

}
