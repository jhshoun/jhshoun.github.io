package com.quintiles.structures.cloudrequests.crush;

import java.io.FileInputStream;
import java.io.InputStream;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.quintiles.structures.engine.utility.Configuration;

/**
 * Crush FTP Requests
 * @author q766769
 *
 * provides basic FTP services to Crush server,
 * uses the Crush REST API
 */
public class FTPRequests
{
	private Configuration _configuration = new Configuration();
	private Logger logger = LoggerFactory.getLogger( FTPRequests.class );

	public FTPRequests(String server)
	{
		// we are not using the server configuration yet
		// may be needed later when we have multiple Crush targets
	}


	/**
	 * gets a listing of all files in a specified FTP folder
	 * 
	 * @param folderType   configuration reference to standard service folders
	 * @return an FtpDirectory object
	 */
	public FtpDirectory dirListing(String folderType)
	{
		String authCookie;
		String c2f;
		String json;

		authCookie = getAuth();
		if ( authCookie.startsWith("ERR:") ) {
			return new FtpDirectory();
		}
		c2f = authCookie.substring(authCookie.length() - 4);

		try {
			Response response;
			Client client;
			WebTarget target;
			Form form;
			Entity<Form> entity;

			form = new Form();
			form.param("command", "getXMLListing")
				.param("format", "JSONOBJ")
				.param("path", _configuration.getConfigValue("ftp.folder." + folderType))
				.param("c2f", c2f);

			entity = Entity.form(form);

			client = ClientBuilder.newClient();
			target = client.target( _configuration.getConfigValue("ftp.server") );

			response = target
							.request(MediaType.APPLICATION_JSON)
							.cookie("CrushAuth", authCookie)
							.post(entity);

			if (response.getStatus() != 200)
			{
				logger.error("Crush API directory error; {} {}", response.getStatus(), response.getStatusInfo() );
				return new FtpDirectory();
			};

			json = response.readEntity(String.class);
		}
		catch (Exception e) {
			logger.error("Crush API directory list exception", e);
			return null;
		}

		// passed everything
		return new Gson().fromJson(json, FtpDirectory.class);
	}

	/**
	 * upload a document to Crush ftp server
	 * 
	 * @param fileName      complete path for file to be uploaded
	 * @param folderType    reference to configuration for target folder name 
	 * @return pass/fail int
	 */
	public int upload(String fileName, String folderType)
	{
		String authCookie;
		String confirmationID;

		authCookie = getAuth();
		if ( authCookie.startsWith("ERR:") ) {
			return -1;
		}

		try {
			Response response;
			Client client;
			WebTarget target;
			InputStream is;

			is = new FileInputStream( fileName );

			client = ClientBuilder.newClient();
			target = client
							.target( _configuration.getConfigValue("ftp.server") )
							.path( _configuration.getConfigValue("ftp.folder." + folderType) );

			response = target
							.request()
							.cookie("CrushAuth", authCookie)
							.put( Entity.entity(is, "application/octet-stream" ) );

			// sends 201 as "created" status for put
			if (response.getStatus() != 201)
			{
				logger.error("Crush API upload fail; {} {}", response.getStatus(), response.getStatusInfo() );
				return -1;
			};

			confirmationID = response.readEntity(String.class);
		}
		catch (Exception e) {
			logger.error("Crush API upload exception", e);
			return -1;
		}

		// all clear
		logger.info("Crush API upload confirmation; {}", confirmationID);
		return 0;
	}


	/**
	 * Get CrushFTP authentication token
	 * presents credentials to server, gets authentication
	 * cookie as a response on success 
	 * 
	 * @return authentication string
	 */
	public String getAuth()
	{
		String authCookie;

		try {
			Response response;
			Client client;
			WebTarget target;
			Form form;
			Entity<Form> entity;

			form = new Form();
			form.param("command", "login")
				.param("username", _configuration.getConfigValue("ftp.username"))
				.param("password", _configuration.getConfigValue("ftp.password"))
				.param("encoded", "true")
				.param("random", Double.toString(Math.random()) );

			entity = Entity.form(form);

			client = ClientBuilder.newClient();
			target = client.target( _configuration.getConfigValue("ftp.server") );

			response = target
							.request(MediaType.APPLICATION_XML)
							.post(entity);

			if (response.getStatus() != 200)
			{
				logger.error("Crush API auth failed; {} {}", response.getStatus(), response.getStatusInfo() );
				return("ERR: authentication did not get 200 response");
			};

			// get the auth cookie
			{
				String header = response.getHeaderString("Set-Cookie");
				String cookie = header.split("; ")[0];
				authCookie = cookie.split("=")[1];
			}

		}
		catch (Exception e) {
			logger.error("Crush API error", e);
			return("ERR: crush authentication failed");
		}

		// return the cookie
		return(authCookie);
	}


}

