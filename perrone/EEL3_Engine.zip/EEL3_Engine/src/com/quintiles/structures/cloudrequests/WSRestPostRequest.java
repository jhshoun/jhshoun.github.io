package com.quintiles.structures.cloudrequests;

import java.io.File;

import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.glassfish.jersey.media.multipart.file.FileDataBodyPart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

/**
 * @author q791213
 * 
 * implements POST request client using JAX-RS framework
 */
public class WSRestPostRequest extends WSRequest
{
	private Logger logger = LoggerFactory.getLogger(WSRestPostRequest.class);

	// constructor
	WSRestPostRequest(String user, String password, String host, String path)
	{
		super(user, password, host, path);
	}

	/* 
	 * send request with attachment,
	 * returns the JSON encoded response
	 */
	@Override
	public String sendRequest(File attachedFile)
	{
		WebTarget target;
		Response response;
		String responseText;

		FormDataMultiPart form;
		FileDataBodyPart filePart;

		try {

			target = client.target(_server);

			// construct multi-part form, add file attachment
			form = new FormDataMultiPart();
			filePart = new FileDataBodyPart( "content", attachedFile );
			form.bodyPart( filePart );

			response = target
							.path( _path )
							.request()
							.header("Authorization", authHeader())
							.header("Host", target.getUri().getHost())
							.post( Entity.entity(form, form.getMediaType()) );

			form.close();
			logger.info("REST post request: {} - {}", target.getUri().toString(), _path);

			if (response.getStatus() != 201) {
				String error;

				error = response.getStatusInfo().getReasonPhrase();
				logger.error("Wingspan: rest error - {}, {}", response.getStatus(), error);
				throw new Exception("Wingspan: rest error - " + error);
			}

			responseText = response.readEntity(String.class);
			logger.debug("REST response: {}", responseText);
			return responseText;
		}
		catch (Exception e) {
			logger.error("error from ws post request", e);
		}
		finally {
			client.close();
		}

		return null;
	}


}
