package com.quintiles.structures.cloudrequests;

import com.quintiles.e3.data.dao.model.nodb.ProjectJobTypeEnum;

/**
 * @author q791213
 *
 * this is class to prepare the data for etmf health wizard status completion check.
 * the interface is run in daily basis. 
 */
public class PrepareWizardStatusCheck extends PrepareDataForWS
{
//	private Logger logger = LoggerFactory.getLogger(PrepareWizardStatusCheck.class);

	ProjectJobTypeEnum _projectJobType;

	// default constructor
	public PrepareWizardStatusCheck()
	{
		// noop
	}

	// constructor for projectJobType
	public PrepareWizardStatusCheck(ProjectJobTypeEnum NOT_USED)
	{
		_projectJobType = NOT_USED;
	}

	/**
	 * add request instance using defaults
	 */
	public void createRequestIns(String env)
	{
		_hostingEnv = env;
		_request = new WSRestGetRequest(
						get_config().getConfigValue(env + ".rest.username"),
						get_config().getConfigValue(env + ".rest.password"),
						get_config().getConfigValue(env + ".rest.server"),
						get_config().getConfigValue(env + ".rest.resource.wizard")
					);
	}

	/**
	 * create request with custom path 
	 */
	public void createRequestIns(String env, String path)
	{
		_hostingEnv = env;
		_request = new WSRestGetRequest(
						get_config().getConfigValue(env + ".rest.username"),
						get_config().getConfigValue(env + ".rest.password"),
						path,
						""
					);
	}

	/**
	 * execute it to:
	 * 1. prepare the data 
	 * 2. make the web service call
	 * 
	 * 2 kind of jobs can be execute in this method 
	 */
	public String execute() throws Exception
	{
		String responseTxt;

		responseTxt = sendRequest();
		return responseTxt;
	}


}
