package com.quintiles.structures.cloudrequests.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * builds a ZIP file of the individual CTMS source files,
 * this requires a single upload and avoids the "file to large" issue
 * 
 * @author q766769
 *
 */
public class ZipLoad
{

	public ZipLoad()
	{
		// NOOP
	}

	public void getZippy(String zipFile, String[] files) throws IOException
	{
		List<String> srcFiles;
		FileOutputStream fos;
		ZipOutputStream zipOut;

		srcFiles = Arrays.asList(files);
		fos = new FileOutputStream(zipFile);
		zipOut = new ZipOutputStream(fos);

		for (String srcFile : srcFiles)
		{
			File fileToZip = new File(srcFile);
			FileInputStream fis = new FileInputStream(fileToZip);
			byte[] bytes;
			int length;

			// skip zero length files
			if (fileToZip.length() < 10) {
				continue;
			}

			zipOut.putNextEntry( new ZipEntry(fileToZip.getName()) );

			bytes = new byte[1024];
			while ((length = fis.read(bytes)) >= 0)
			{
				zipOut.write(bytes, 0, length);
			}
			fis.close();
		}

		zipOut.close();
		fos.close();
	}

}
