package com.quintiles.structures.cloudrequests.crush;

/**
 * FTP directory
 * @author q766769
 *
 * very simple POJO class to de-serialize the directory
 * listing from CrushFTP, most values are dropped except for the
 * source path and the file names
 * (others can be added as needed) 
 */
public class FtpDirectory
{
	public String path = "nothing";
	public DirItem[] listing;

	public class DirItem
	{
		public String name;
		public String dateFormatted;
		public String sizeFormatted;
	}

}
