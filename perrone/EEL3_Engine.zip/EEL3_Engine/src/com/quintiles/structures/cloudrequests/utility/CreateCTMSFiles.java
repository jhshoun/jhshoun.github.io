package com.quintiles.structures.cloudrequests.utility;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.quintiles.structures.db.DbPackage;
import com.quintiles.structures.engine.utility.Configuration;
import com.quintiles.structures.engine.utility.ConfigurationInterface;

/**
 * get the data from database and generate the output file in file system.
 *
 * @author q791213
 *
 */
public class CreateCTMSFiles
{
	private Logger logger = LoggerFactory.getLogger(CreateCTMSFiles.class);

	// max widths for certain CTMS columns
	// (some columns are 'unlimited')
	private static final Map<String, Integer> max;
	static
	{
		max = new HashMap<String, Integer>();

		max.put("NAME", 256);
		max.put("STUDY_NAME", 256);
		max.put("STUDY_DESCRIPTION", 512);
		max.put("STUDY_IDENTIFIER", 512);

		max.put("ADDRESS_LINE_1", 256);
		max.put("ADDRESS_LINE_2", 256);
		max.put("CITY", 256);
		max.put("STATE_PROVINCE", 256);
		max.put("COUNTRY", 256);
		max.put("POSTAL_CODE", 256);

		max.put("CTMS_SITE_ID", 64);
		max.put("CTMS_STABLE_ID", 100);
		max.put("INVESTIGATOR_ID", 64);
		max.put("ROLE", 32);
		max.put("FIRST_NAME", 256);
		max.put("MIDDLE_NAME", 256);
		max.put("LAST_NAME", 256);
		max.put("EMAIL_ADDRESS", 256);

		max.put("MILESTONE_NAME", 256);
	}

	private ConfigurationInterface _configuration = new Configuration();
	private DbPackage _dbPackage = new DbPackage.GetCtmsData();
	private Long _ctmsJob = 0L;

	// default constructor
	public CreateCTMSFiles()
	{
		// NOOP
	}

	// create with jobId
	public CreateCTMSFiles(Long jobId)
	{
		_ctmsJob = jobId;
	}

	/**
	 * get data from db and create file header in file system
	 * 
	 * @param environment (health or tmf)
	 * @param profile_id (E3 study profile)
	 * @return array of file names
	 * @throws IOException
	 */
	public String[] getContentGenerateFiles(String env, int profile_id) throws IOException
	{
		// get export file configurations
		String fileList = _configuration.getConfigValue(env + ".upload.files");
		String sourcePath = _configuration.getConfigValue(env + ".upload.filepath");
		String fileExt = _configuration.getConfigValue(env + ".upload.fileext");

		String[] fileNameArray = toStringArray(fileList);
		String[] filePathNameArray = new String[fileNameArray.length];
		OutputStreamWriter writer = null;

		for (int i = 0; i < fileNameArray.length; i++)
		{
			int recordCount = 0;
			String exportPath = null;

			try {

				// files stored by job ID folder
				exportPath = sourcePath + _ctmsJob + "-" + env + "\\" + fileNameArray[i] + fileExt;
				(new File(exportPath)).getParentFile().mkdirs();

				// output file must be UTF8
				writer = new OutputStreamWriter(
								new FileOutputStream(exportPath),
								Charset.forName("UTF-8").newEncoder() 
							);

				filePathNameArray[i] = exportPath;

				if (writer != null) {
					String header;

					//get header fields from db
					header = _configuration.getConfigValue(env + ".upload." + fileNameArray[i] + ".header");
					// generate file body
					recordCount = generateFileBody(writer, fileNameArray[i], header, profile_id);
					logger.info("CTMS file {}, {} records", fileNameArray[i], recordCount);
				}
			}
			catch (IOException e) {
				logger.error("error occurred while writing content to file {}", fileNameArray[i]);
				logger.error("exception writing content to file", e);
				throw e;
			}
			finally {
				try {
					if (writer != null) {
						writer.flush();
						writer.close();
					}
				}
				catch (IOException e) {
					logger.error("error occurred while closing writer {} ({})", 
									fileNameArray[i], e.getLocalizedMessage());
					throw e;
				}
			}
		}
		return filePathNameArray;
	}

	/**
	 * get data from db and create file body in file system
	 * 
	 * @param writer
	 * @param fileName
	 * @param header
	 * @param profile_id (E3 study profile)
	 * @return number of lines written
	 * @throws IOException
	 */
	private int generateFileBody(
							OutputStreamWriter writer, 
							String fileName,
							String header, 
							int profile_id
											) throws IOException
	{
		List<Map<String, Object>> resultSet;
		int rowCount;

		// get the CTMS values
		// ** the 'fileName' maps to a specific dataset name in the 
		// ** DB stored procedure
		resultSet = _dbPackage.run(fileName, profile_id);

		rowCount = resultSet.size();
		if (rowCount > 0)
		{
			String[] headerArray;

			// write the CSV header
			GenerateFilesForUpload.writeLine(writer, toStringList(header));
			headerArray = header.split(",");

			for (int j = 0; j < rowCount; j++)
			{
				Map<String, Object> rec = resultSet.get(j);
				String[] bodyArray = new String[headerArray.length];

				rec = resultSet.get(j);
				bodyArray = new String[headerArray.length];
				for (int i = 0; i < headerArray.length; i++)
				{
					String col = (String) rec.get(headerArray[i]);
					if (col != null)
					{
						// restrict column to max width (if defined)
						if (max.containsKey( headerArray[i] )) {
							int k = max.get( headerArray[i] ).intValue();
							col = col.length() < k ? col : col.substring(0, k-2);
						}
						bodyArray[i] = col;
					}
					else
					{
						bodyArray[i] = "";
					}
				}
				try
				{
					GenerateFilesForUpload.writeLine(writer, Arrays.asList(bodyArray), true);
				}
				catch (IOException e)
				{
					throw e;
				}
			}
		}

		return rowCount;
	}


	private String[] toStringArray(String columns)
	{
		String[] columnArray = null;

		if (columns != null) {
			columnArray = columns.split(",");
		}
		return columnArray;
	}

	private List<String> toStringList(String columns)
	{
		return Arrays.asList( toStringArray(columns) );
	}

}
