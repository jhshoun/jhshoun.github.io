package com.quintiles.structures.cloudrequests;

/**
 * TMF Site Wizard JSON response
 * @author q766769
 *
 * very simple POJO class to de-serialize the Wingspan
 * response to a request for all configured sites for
 * a given study
 */
public class TmfSiteWizardJSONResponse
{
	public int totalCount;
	public String message;
	public String version;
	public Site[] data;

	public static class Site
	{
		public String id;
		public String name;
		public String status;
		public String country;
		public String siteName;
		public String siteLabel;
		public String siteStatus;
		public String principalInvestigator;
	}

}

