package com.quintiles.structures.cloudrequests;

import java.io.File;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.xml.bind.DatatypeConverter;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;
import org.glassfish.jersey.media.multipart.MultiPartFeature;

/**
 * @author q791213
 *
 * this main Web service class.  all other Web service class inherited from this class.
 * 
 */
public abstract class WSRequest
{
	protected String _user; 
	protected String _password; 
	protected String _server;
	protected String _path;

	protected Client client;

	/**
	 * get server info and build the client
	 *  
	 * @param user
	 * @param password
	 * @param uri
	 * @param path
	 */
	WSRequest(String user, String password, String host, String path)
	{
		_user = user; 
		_password = password; 
		_server = host;
		_path = path;

		prepareRequest();
	}
	
	/**
	 * initialized client and web connection
	 */
	private void prepareRequest()
	{
		ClientConfig clientConfig = new ClientConfig();

		clientConfig.register(new WSCustomLoggingFilter());
		client = ClientBuilder
						.newBuilder()
//						.withConfig( clientConfig )       // extended logging
						.register(MultiPartFeature.class)
						.build()
						.property(ClientProperties.SUPPRESS_HTTP_COMPLIANCE_VALIDATION, true);
	}

	/**
	 * send web service request
	 * 
	 * @param attachedFile (optional)
	 * @return
	 * @throws Exception 
	 */
	public abstract String sendRequest(File attachedFile) throws Exception;

	/**
	 * generate WS authentication header
	 * <p/>
	 * @return 	header string
	 */
	protected String authHeader()
	{
		String authHeader = "Basic ";
		byte[] uid_pw = (_user + ":" + _password).getBytes();

		authHeader += DatatypeConverter.printBase64Binary( uid_pw );
		return authHeader;
	}

	/**
	 * generate preemptive (BASIC) WS authentication header
	 * <p/>
	 * @return 	header string
	 */
	protected HttpAuthenticationFeature prempAuthHeader()
	{
		HttpAuthenticationFeature feature;

		feature = HttpAuthenticationFeature.basic("username", "password");
		return feature;
	}


}
