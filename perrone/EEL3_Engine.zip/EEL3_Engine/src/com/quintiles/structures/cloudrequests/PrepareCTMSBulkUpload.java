package com.quintiles.structures.cloudrequests;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;

import com.quintiles.e3.data.dao.model.nodb.ProjectJobTypeEnum;
import com.quintiles.structures.cloudrequests.utility.CreateCTMSFiles;
import com.quintiles.structures.cloudrequests.utility.ZipLoad;
import com.quintiles.structures.engine.jobs.CTMSUpdateJob;

/**
 * @author q791213
 *
 * this is class to prepare the CTMS data for health/transformation bulk upload;
 * the bulk upload interface can be used on schedule basis or on demand
 */
public class PrepareCTMSBulkUpload extends PrepareDataForWS
{
	private Logger logger = LoggerFactory.getLogger(PrepareCTMSBulkUpload.class);

	private ProjectJobTypeEnum _projectJobType;

	private int _profile_id = 0;
	private CreateCTMSFiles _createCSVFiles = null;
	private CTMSUpdateJob _ctmsJob = null;

	// default constructor
	public PrepareCTMSBulkUpload()
	{
		// noop
	}

	// job constructor
	public PrepareCTMSBulkUpload(ProjectJobTypeEnum projectJobType, int profile_id)
	{
		_projectJobType = projectJobType;
		_profile_id = profile_id;
	}

	/**
	 * add request instance from outside
	 */
	public void createRequestIns(String env)
	{
		_hostingEnv = env;

		_request = new WSRestPostRequest(
						get_config().getConfigValue(_hostingEnv + ".rest.username"),
						get_config().getConfigValue(_hostingEnv + ".rest.password"),
						get_config().getConfigValue(_hostingEnv + ".rest.server"),
						get_config().getConfigValue(_hostingEnv + ".rest.resource.upload")
					);
	}

	// register the quartz job
	public void setHealthJob(CTMSUpdateJob job)
	{
		this._ctmsJob = job;
	}


	/**
	 * execute it to:
	 * 1. prepare the data 
	 * 2. make the web service call
	 * 
	 * 2 kind of jobs can be execute in this method 
	 */
	public String execute() throws Exception
	{

		if (_projectJobType == ProjectJobTypeEnum.CTMS_UPDATE) {
			// daily bulk update all studies
			return buildSend();
		}
		else if (_projectJobType == ProjectJobTypeEnum.CTMS_INIT) {
			// on demand single study upload
			return buildSend();
		}
		else{
			logger.error("undefined project Job Type = {}", _projectJobType);
		}

		return null;
	}

	/**
	 * build load files and call REST to upload
	 */
	private String buildSend() throws Exception
	{
		String returnTxt = null;
		String[] fileList;

		fileList = createFiles();
		logger.info("file List created: {}, {}, {}", _profile_id, _projectJobType, _hostingEnv);
		returnTxt = sendRequest(fileList);
		logger.info("request sent: profile ID - {}", _profile_id);

		return returnTxt;
	}


	/**
	 * send web service request
	 * one file at a time
	 * 
	 * @param fileList
	 * @throws Exception 
	 */
	private String sendRequest(String[] fileList) throws Exception
	{
		String message = "";
		ZipLoad zl;
		String zipFile;

		// pack all the files into a ZIP archive
		zl = new ZipLoad();
		zipFile = (new File(fileList[0])).getParent() + "\\ctms.zip";
		try {
			zl.getZippy(zipFile, fileList);

			_file = new File( zipFile );
			// send the zip file, if it is not empty
			if (_file.length() < 100 ) {
				logger.info("upload skipped, zip file empty");
			}
			else {
				message = sendRequest();
				if (_ctmsJob != null){
					_ctmsJob.jobAudit(zipFile + " FTP send");
				}
			}
		}
		catch (IOException ioe) {
			logger.error("zip file IO exception", ioe);
			message = "ERROR: " + ioe.getLocalizedMessage();
		}
		return message;
	}

	/**
	 * create files
	 * 
	 * @return
	 * @throws IOException 
	 */
	private String[] createFiles() throws IOException
	{
		String[] fileList = null;

		try {
			fileList = get_createDataFiles().getContentGenerateFiles(_hostingEnv, _profile_id);
			if (_ctmsJob != null){
				_ctmsJob.jobAudit(_hostingEnv + " files created: " + fileList.length);
			}
		}
		catch (IOException e) {
			logger.error("error occurred while generate the export files for {}", _projectJobType);
			logger.error("generate the export files exception", e);
			if (_ctmsJob != null) {
				_ctmsJob.jobAudit("error creating export files");
			}
			throw e;
		}
		return fileList;
	}


	private CreateCTMSFiles get_createDataFiles()
	{
		if (_createCSVFiles == null) {
			if (_ctmsJob == null) {
				_createCSVFiles = new CreateCTMSFiles();
			}
			else {
				_createCSVFiles = new CreateCTMSFiles(_ctmsJob.getJobId());
			}
		}
		return _createCSVFiles;
	}


}
