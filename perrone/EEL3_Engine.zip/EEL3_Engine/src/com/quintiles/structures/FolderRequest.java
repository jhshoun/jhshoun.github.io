package com.quintiles.structures;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.core.util.StatusPrinter;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.JsonObject;
import com.quintiles.structures.engine.FolderFactory;

/**
 * testing servlet
 *
 */
public class FolderRequest
				extends javax.servlet.http.HttpServlet
				implements javax.servlet.Servlet
{
	/** SID */
	private static final long serialVersionUID = 1544390665121773234L;
	private static Logger qlog;
	private static ApplicationContext springContext;


	/* initialization here */
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);

		// store the context and scheduler factory for general use 
		ServletContext ctx;

		qlog = LoggerFactory.getLogger("com.quintiles.structures.FolderRequest");
		qlog.debug("folder servlet initialization"); 

		// print internal state 
		LoggerContext lc = (LoggerContext) LoggerFactory.getILoggerFactory(); 
		StatusPrinter.print(lc); 

		// set shared access to the Spring context
		// using manual injection right now
		// TODO better ideas?
		qlog.info("track spring context"); 
		ctx = this.getServletContext();
		springContext = WebApplicationContextUtils.getRequiredWebApplicationContext(ctx);
	}

	// access to the Spring context
	public static ApplicationContext getSpringContext()
	{
		return springContext;
	}

	/* main request/response handler */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		PrintWriter jout;
		JsonObject jmsg;

		// this is just for testing, should return as JSON type
		if ( req.getHeader("user-agent") == null )
			resp.setContentType("application/json");
		else
			resp.setContentType("text/plain");
		jout = resp.getWriter();

		// get the factory to run a folder request
		qlog.debug("retrieve content server folder ID"); 
		jmsg = FolderFactory.getFolder( req );

		// the data is returned as JSON structure,
		jout.write( jmsg.toString() );
		jout.flush();

	}

	/* this should only be used for JSONP requests */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		PrintWriter jout;
		JsonObject jmsg;
		String cb;

		resp.setContentType("text/plain");
		jout = resp.getWriter();

		// get the factory to run a folder request
		qlog.debug("retrieve content server folder ID (JSONP)"); 
		jmsg = FolderFactory.getFolder( req );

		// the data is returned as JSON structure,
		// if CALLBACK is specified, this is JSONP and needs to be wrapped
		cb = req.getParameter("callback");
		if (cb == null) {
			jout.write( cb + "(0);" );
		}
		else {
			// JSON-p
			String jp;

			jp = cb + "(" + jmsg.toString() + ");";
			jout.write( jp );
		}
		jout.flush();

	}


}

 