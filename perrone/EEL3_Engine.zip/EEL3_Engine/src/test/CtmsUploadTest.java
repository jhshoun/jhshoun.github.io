package test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.mock.jndi.SimpleNamingContextBuilder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.quintiles.e3.data.dao.model.nodb.ProjectJobTypeEnum;
import com.quintiles.structures.cloudrequests.PrepareCTMSBulkUpload;

/**
 * @author q791213
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "resources/test-app-context.xml")
public class CtmsUploadTest
{

	// setup
	@BeforeClass
	public static void setUpBeforeClass() throws Exception
	{
		JunitTestUtility.setup();
	}

	@Before
	public void beforeTest()
	{
		SimpleNamingContextBuilder.getCurrentContextBuilder().deactivate();
	}
	
	
	/*
	 * upload CTMS data files to Wingspan
	 */
	@Test
	public void uploadNewStudy()
	{
		String result;

		try {

			PrepareCTMSBulkUpload prepUpload;

			prepUpload = new PrepareCTMSBulkUpload(ProjectJobTypeEnum.CTMS_INIT, 733);
			prepUpload.createRequestIns("tmf");
//			prepUpload = new PrepareCTMSBulkUpload(ProjectJobTypeEnum.CTMS_INIT, 697);
//			prepUpload.setRequestIns(null, "health");

			result = prepUpload.execute();

			if (result.equalsIgnoreCase("")) {
				fail("web service call failed");
			}

		} 
		catch (Exception e) {
			e.printStackTrace();
			fail("upload fail" + e.getMessage());
		}
	}

}
