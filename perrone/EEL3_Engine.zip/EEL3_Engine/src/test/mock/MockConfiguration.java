/**
 * 
 */
package test.mock;


import java.util.Map;

import com.quintiles.structures.engine.utility.Configuration;
import com.quintiles.structures.engine.utility.ConfigurationInterface;

/**
 * @author q791213
 *
 */
public class MockConfiguration implements ConfigurationInterface{
	
	static Map<String,String> _configurationDATA = null;
	
	
	
	public Map<String, String> get_configurationDATA() {
		return _configurationDATA;
	}

	public void set_configurationDATA(Map<String, String> _configurationDATA) {
		MockConfiguration._configurationDATA = _configurationDATA;
	}

	/**
	 * get string value map
	 * </p>
	 */
    @Override	
	public String getConfigValue(String key)
	{
		return _configurationDATA.get(key);
	}

	/**
	 * get number value map
	 * </p>
	 */
    @Override	
	public int getConfigNumberValue(String key)
	{
		return Integer.parseInt( _configurationDATA.get(key));
	}
	
}
