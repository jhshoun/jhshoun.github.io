/**
 * 
 */
package test.mock;


import java.util.List;
import java.util.Map;

import com.quintiles.structures.db.DbPackage;


/**
 * @author q791213
 *
 */
public class MockDbPackage extends DbPackage {
    private List<Map<String, Object>> _listData=null;
    
	public List<Map<String, Object>> get_listData() {
		return _listData;
	}

	public void set_listData(List<Map<String, Object>> _listData) {
		this._listData = _listData;
	}

	public MockDbPackage() {
	}
	 @Override	
	public List<Map<String, Object>> run(Object... args)
	{
		return _listData;
	}
	
	
}
