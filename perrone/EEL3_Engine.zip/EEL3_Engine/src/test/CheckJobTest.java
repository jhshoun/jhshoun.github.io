package test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.opentext.api.LLValue;
import com.quintiles.lapi.Document;

public class CheckJobTest
{
	@Test
	public void upperCaseCountryCode()
	{
		Document doc;
		LLValue countries;
		String country_code_ = "aa";

		try {

			doc = new Document("etmf-stage");
			countries = doc.getChildrenInfo(-1078775, "subtype = 10100");
			if ( countries.size() < 1 ) {
				fail("no countries for project");
			}

			// get the child object ID, ISO code & name
			country_code_ = countries.toString(0, "EXATT1").toUpperCase();
		}
		catch (Exception e) {
			e.printStackTrace();
			fail("country case failed");
		}

		// did we get -1 back
		assertTrue( country_code_.equals(country_code_.toUpperCase()) );
	}

}
