package test;

import java.net.URISyntaxException;
import java.sql.SQLException;

import javax.naming.NamingException;

import org.springframework.mock.jndi.SimpleNamingContextBuilder;

import oracle.jdbc.pool.OracleDataSource;

/**
 * @author norris.shelton
 */
public class JunitTestUtility
{

	/**
	 * Performs environmental setup for Cam tests.
	 * 
	 * @throws NamingException
	 *             if unable to activate the builder
	 * @throws URISyntaxException
	 *             if unable to find the properties file by a classloader
	 */
	public static void setup() throws NamingException, URISyntaxException
	{
//		String propertiesFile = "resources/app.properties";
//		URL url = JunitTestUtility.class.getResource(propertiesFile);
		SimpleNamingContextBuilder builder;
		OracleDataSource ods = null;

		try {
			ods= new OracleDataSource();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		ods.setURL("jdbc:oracle:thin:@usadc-sdbxt47:1521:elvisdev");
		ods.setUser("eel3");
		ods.setPassword("eel3");

		builder = SimpleNamingContextBuilder.emptyActivatedContextBuilder();
		builder.bind("java:/comp/env/jdbc/eel3Datasource", ods);
	}

}
