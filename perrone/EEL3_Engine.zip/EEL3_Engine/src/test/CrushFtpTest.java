package test;

import static org.junit.Assert.*;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.*;

import com.google.gson.Gson;
import com.quintiles.structures.cloudrequests.crush.FTPRequests;
import com.quintiles.structures.cloudrequests.crush.FtpDirectory;

import java.io.FileInputStream;
import java.io.InputStream;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

// TODO, use new spring JUNIT configuration for database

@FixMethodOrder(MethodSorters.JVM)
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(
		locations = {
				"classpath*:applicationContext.xml"
		})
public class CrushFtpTest implements ApplicationContextAware
{

	@Test
	public void login()
	{
		String authCookie;

		authCookie = getAuth();
		if ( authCookie.startsWith("ERR:") ) {
			fail("could not authenticate - " + authCookie);

		}

		assertTrue( true );
	}

	@Test
	public void login1()
	{
		FTPRequests ftp;
		String authCookie;

		try {
			ftp = new FTPRequests("foo");

			authCookie = ftp.getAuth();
			if ( authCookie.startsWith("ERR:") ) {
				fail("could not authenticate - " + authCookie);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		assertTrue( true );
	}

	@Test
	public void dirListing()
	{
		String authCookie;
		String c2f;

		authCookie = getAuth();
		if ( authCookie.startsWith("ERR:") ) {
			fail("could not authenticate - " + authCookie);

		}
		c2f = authCookie.substring(authCookie.length() - 4);

		try {
			Response response;
			Client client;
			WebTarget target;
			Form form;
			Entity<Form> entity;
			String value;

			form = new Form();
			form.param("command", "getXMLListing")
				.param("format", "JSONOBJ")
				.param("path", "/devenv1/reports")
				.param("c2f", c2f);

			entity = Entity.form(form);

			client = ClientBuilder.newClient();
			target = client.target( "https://upload.mywingspan.com" );

			response = target
							.request(MediaType.APPLICATION_JSON)
							.cookie("CrushAuth", authCookie)
							.post(entity);

			if (response.getStatus() != 200)
			{
				fail("crush FTP folder listing bad status");
			};

			value = response.readEntity(String.class);
			System.out.println( value );

			FtpDirectory fred = new Gson().fromJson(value, FtpDirectory.class);
			System.out.println( fred.toString() );
		}
		catch (Exception e) {
			e.printStackTrace();
			fail("crush FTP folder listing failed");
		}

		// passed everything
		assertTrue( true );
	}

	@Test
	public void upload()
	{
		String authCookie;

		authCookie = getAuth();
		if ( authCookie.startsWith("ERR:") ) {
			fail("could not authenticate - " + authCookie);
		}

		try {
			Response response;
			Client client;
			WebTarget target;
			InputStream is;
			String value;

			is = new FileInputStream("c:/users/q766769/Desktop/sample001.xlsx");

			client = ClientBuilder.newClient();
			target = client
							.target( "https://upload.mywingspan.com" )
							.path("/devenv1/reports/so_RESTful.xls");

			response = target
							.request()
							.cookie("CrushAuth", authCookie)
							.put( Entity.entity(is, "application/octet-stream" ) );

			// sends 201 as "created" status for put
			if (response.getStatus() != 201)
			{
				fail("directory listing did not get 201 created");
			};

			value = response.readEntity(String.class);
			System.out.println( "upload confirmation id: " + value );
		}
		catch (Exception e) {
			e.printStackTrace();
			fail("crush FTP folder listing failed");
		}

		// did we get -1 back
		assertTrue( true );
	}


	public String getAuth()
	{
		String authCookie;

		try {
			Response response;


			{
				Client client;
				WebTarget target;
				Form form;
				Entity<Form> entity;

				form = new Form();
				form.param("command", "login")
					.param("username", "tmfhealth")
					.param("password", "4ks@eAVTZcck*w^b")
					.param("encoded", "true")
					.param("random", Double.toString(Math.random()) );

				entity = Entity.form(form);

				client = ClientBuilder.newClient();
				target = client.target( "https://upload.mywingspan.com" );

				response = target
								.request(MediaType.APPLICATION_XML)
								.post(entity);
			}

			if (response.getStatus() != 200)
			{
				return("ERR: authentication did not get 200 response");
			};

			// get the auth cookie
			{
				String header = response.getHeaderString("Set-Cookie");
				String cookie = header.split("; ")[0];
				authCookie = cookie.split("=")[1];
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			return("ERR: crush authentication failed");
		}

		// return the cookie
		return(authCookie);
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException
	{
		// TODO Auto-generated method stub
//		EelRequest.setSpringContext(applicationContext);
		
	}

	
}



