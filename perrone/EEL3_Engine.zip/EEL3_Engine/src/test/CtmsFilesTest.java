/**
 * 
 */
package test;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.mock.jndi.SimpleNamingContextBuilder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.quintiles.structures.cloudrequests.utility.CreateCTMSFiles;
/**
 * @author q791213
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "resources/test-app-context.xml")
public class CtmsFilesTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception
	{
		JunitTestUtility.setup();
	}

	@Before
	public void beforeTest()
	{
		SimpleNamingContextBuilder.getCurrentContextBuilder().deactivate();
	}

	/*
	 * create CTMS data files for a profile
	 */
	@Test
	public void createCtmsFiles()
	{
		CreateCTMSFiles ccf;
		String[] files;

		ccf = new CreateCTMSFiles();
		try
		{
			files = ccf.getContentGenerateFiles("tmf", 733);
			assertTrue("we have 5 files", files.length > 3);
			
			files = ccf.getContentGenerateFiles("health", 697);
			assertTrue("we have 5 files", files.length > 3);
		}
		catch (IOException e)
		{
			fail("ctms csv data generate error -- " + e.getMessage());
			e.printStackTrace();
		}
	}

}
