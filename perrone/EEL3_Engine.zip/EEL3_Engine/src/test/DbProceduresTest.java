package test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.mock.jndi.SimpleNamingContextBuilder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.quintiles.structures.db.DbPackage;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "resources/test-app-context.xml")
public class DbProceduresTest
{

	// setup
	@BeforeClass
	public static void setUpBeforeClass() throws Exception
	{
		JunitTestUtility.setup();
	}

	@Before
	public void beforeTest()
	{
		SimpleNamingContextBuilder.getCurrentContextBuilder().deactivate();
	}



	@Test
	public void getWsStatus()
	{
		List<Map<String, Object>> rs1;

		try {
			// get all status rows
			rs1 = new DbPackage.GetAllWingspanStatus().run();

			// did we get rows back
			assertTrue( rs1.size() > 0 );

			if (rs1.size() > 0) {
				Map<String, Object> rec = rs1.get(0);

				System.out.println( rec.get("profile_id") );
				System.out.println( rec.get("class_name") );
				System.out.println( rec.get("build_status") );
				System.out.println( rec.get("ws_id") );
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			fail("wingspan build lookup");
		}

	}

}
