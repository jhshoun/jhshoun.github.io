package test;

import static org.junit.Assert.fail;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

import org.junit.Test;

import com.quintiles.structures.cloudrequests.utility.GenerateFilesForUpload;
import com.quintiles.structures.cloudrequests.utility.ZipLoad;

public class GenerateCsvFilesTest
{

	
	@Test
	public void makeTestFiles()
	{
		String csvFile[] = { 
								"D:\\EELLogs\\wingspan\\csv-export\\abc-1.csv",
								"D:\\EELLogs\\wingspan\\csv-export\\abc-2.csv" 
							};
		FileWriter writer = null;
		for (int i = 0; i < csvFile.length; i++)
		{
			try
			{
				writer = new FileWriter(csvFile[i]);
			}
			catch (IOException e1)
			{
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			try
			{
				if (writer != null)
				{
					// for header
					// get it from config table using file name
					String tmp[] = { "Name", "Salary", "Age" };
					GenerateFilesForUpload.writeLine(writer, Arrays.asList(tmp));
					// body
					// get it from stored proc using file name
					GenerateFilesForUpload.writeLine(writer, Arrays.asList("a", "b", "c"), true);
					GenerateFilesForUpload.writeLine(writer, Arrays.asList("e", "f", "g"), true);
				}
			}
			catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				try
				{
					if (writer != null)
					{
						writer.flush();
						writer.close();
					}
				}
				catch (IOException e)
				{
					fail("gen file io exception: " + e.getLocalizedMessage());
				}

			}
		}

	}	
	
	@Test
	public void zipTestFiles()
	{
		ZipLoad zl;
		String csvFiles[] = { 
								"D:\\EELLogs\\wingspan\\csv-export\\study_details.csv",
								"D:\\EELLogs\\wingspan\\csv-export\\study_milestone.csv",
								"D:\\EELLogs\\wingspan\\csv-export\\site.csv",
								"D:\\EELLogs\\wingspan\\csv-export\\site_milestone.csv",
								"D:\\EELLogs\\wingspan\\csv-export\\site_investigator.csv" 
							};

		zl = new ZipLoad();
		try
		{
			zl.getZippy("D:\\EELLogs\\wingspan\\csv-export\\ctms.zip", csvFiles);
		}
		catch (IOException e)
		{
			fail("zip file io exception: " + e.getLocalizedMessage());
		}

	}	
	
}
