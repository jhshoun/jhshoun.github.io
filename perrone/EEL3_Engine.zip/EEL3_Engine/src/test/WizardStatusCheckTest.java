package test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.mock.jndi.SimpleNamingContextBuilder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.gson.Gson;

import com.quintiles.e3.data.dao.model.nodb.ProjectJobTypeEnum;
import com.quintiles.structures.cloudrequests.PrepareWizardStatusCheck;
import com.quintiles.structures.cloudrequests.TmfCountryWizardJSONResponse;
import com.quintiles.structures.cloudrequests.TmfSiteWizardJSONResponse;
import com.quintiles.structures.cloudrequests.TmfStudyWizardJSONResponse;

/**
 * @author q791213
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = "resources/test-app-context.xml")
@ContextConfiguration(locations = "resources/prod-app-context.xml")
public class WizardStatusCheckTest
{

	@BeforeClass
	public static void setUpBeforeClass() throws Exception
	{
		JunitTestUtility.setup();
	}

	@Before
	public void beforeTest()
	{
		SimpleNamingContextBuilder.getCurrentContextBuilder().deactivate();
	}

	// see if the health lookup works
	@Test
	public void health()
	{
		PrepareWizardStatusCheck wizardStatus;
		String response;
		TmfStudyWizardJSONResponse studies;
		TmfCountryWizardJSONResponse countries;
		TmfSiteWizardJSONResponse sites;

		try {
			wizardStatus = new PrepareWizardStatusCheck(ProjectJobTypeEnum.CTMS_UPDATE);
//			wizardStatus = new PrepareWizardStatusCheck(ProjectJobTypeEnum.CTMS_INIT);
//			wizardStatus.createRequestIns("health");
			wizardStatus.createRequestIns("tmf");
			response = (String) wizardStatus.execute();

			studies = new Gson().fromJson(response, TmfStudyWizardJSONResponse.class);
			assertEquals("OK", studies.message);
			assertTrue("we got many studies", studies.totalCount > 5);

			wizardStatus.createRequestIns("tmf", studies.data[0].links.countries);
			response = (String) wizardStatus.execute();
			countries = new Gson().fromJson(response, TmfCountryWizardJSONResponse.class);
			assertEquals("OK", countries.message);
			assertTrue("we got some countries", countries.totalCount > 0);

			wizardStatus.createRequestIns("tmf", studies.data[0].links.sites);
			response = (String) wizardStatus.execute();
			sites = new Gson().fromJson(response, TmfSiteWizardJSONResponse.class);
			assertEquals("OK", sites.message);
			assertTrue("we got some sites", sites.totalCount > 1);
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	
}
