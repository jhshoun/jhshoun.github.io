CREATE OR REPLACE PACKAGE "ENGINE"
AS

/**
	EEL3 Engine Package
	Revision History

Version     Date            User     Changes
=============================================================================
3.1.005     2013-OCT-22     JHS      bundled existing ad hoc queires into package
3.1.006     2013-NOV-07     JHS      updated the site history change queries
3.1.007     2013-DEC-10     JHS      the site change list now includes project and country
3.1.008     2014-JAN-23     JHS      additional routines for check job
3.1.009     2014-MAY-09     JHS      updated site lookups to scan old site numbers,
                                     added query to locate sites in CS10 
3.2.001     2015-AUG-06     JHS      extended unblinded permissions lookup
3.4.001     2016-JAN-20     JHS      updated legacy CTMS translation (mapping)
3.4.002     2016-FEB-09     JHS      check job audit trail for errors
3.7.000     2017-MAY-23     JHS      added procedures to extract CTMS data for Wingspan
3.7.001     2017-JUN-07     JHS      added Wingpsan wizard tracking
3.7.002     2017-AUG-14     JHS      misc updates to CTMS lookup, incremental data upload,
                                     project code aggregation
3.7.003     2017-SEP-11     JHS      updated CTMS study details query
4.0.001     2017-SEP-29     JHS      final update for the new release;
                                     corrected decode error in site personel lookup
4.0.002     2017-OCT-03     JHS      protocol number searches case insensitive
4.0.003     2017-OCT-11     JHS      additional exclusion filtering on health-check sites
4.0.004     2017-NOV-03     JHS      corrected study detail selection to force CTMS data
4.0.005     2017-NOV-06     JHS      removed project code from site lookup
4.0.006     2017-NOV-21     JHS      patch for new company name, upper case protocol names
4.3.000     2018-JUN-05     JHS      updated sort order for site personel (load PI first),
                                     removed override flag
4.4.000     2020-JUN-12     MAB      change "Novella" to "IQB" and append the service_line
                                     to the business unit.
4.5.000     2020-SEP-30     MAB      select CTMS_Stable_ID from study_milestones and site_milestones
                                     rather than null

**/

--
-- procedure declarations
--

PROCEDURE getTier (
	p_tid        IN NUMBER,
	p_tclass     IN NUMBER,
	p_result     OUT SYS_REFCURSOR
);

PROCEDURE createGroups (
	p_tid        IN NUMBER,
	p_result     OUT SYS_REFCURSOR
);

PROCEDURE getGroupLeaders (
	p_tid        IN NUMBER,
	p_result     OUT SYS_REFCURSOR
);

PROCEDURE getGroupMembers (
	p_tid        IN NUMBER,
	p_result     OUT SYS_REFCURSOR
);

PROCEDURE getNavigators (
	p_tid        IN NUMBER,
	p_result     OUT SYS_REFCURSOR
);

PROCEDURE getArtifactPermissions (
	p_fid          IN NUMBER,
	p_class_mask   IN NUMBER,
	p_tid          IN NUMBER,
	p_result       OUT SYS_REFCURSOR
);

PROCEDURE getUnblindedPermissions (
	p_fid          IN NUMBER,
	p_class_mask   IN NUMBER,
	p_tid          IN NUMBER,
	p_result       OUT SYS_REFCURSOR
);

PROCEDURE getFolderList (
	p_tid        IN NUMBER,
	p_tclass     IN NUMBER,
	p_all        IN NUMBER,
	p_result     OUT SYS_REFCURSOR
);

PROCEDURE getJITRecord (
	p_tid          IN NUMBER,
	p_tclass       IN NUMBER,
	p_zone         IN VARCHAR2,
	p_section      IN VARCHAR2,
	p_artifact     IN VARCHAR2,
	p_result       OUT SYS_REFCURSOR
);

PROCEDURE getParentList (
	p_fid        IN NUMBER,
	p_result     OUT SYS_REFCURSOR
);

PROCEDURE getCustomerFolder (
	p_cust_code  IN VARCHAR2,
	p_result     OUT SYS_REFCURSOR
);

PROCEDURE getCountryName (
	p_code       IN VARCHAR2,
	p_result     OUT SYS_REFCURSOR
);

PROCEDURE getSiteData (
	p_project    IN VARCHAR2,
	p_protocol   IN VARCHAR2,
	p_site       IN VARCHAR2,
	p_result     OUT SYS_REFCURSOR
);

PROCEDURE findCS10Site (
	p_folder     IN NUMBER,
	p_project    IN VARCHAR2,
	p_protocol   IN VARCHAR2,
	p_site       IN VARCHAR2,
	p_result     OUT SYS_REFCURSOR
);

PROCEDURE getSiteStatusConfig (
	p_cfg        IN VARCHAR2,
	p_result     OUT SYS_REFCURSOR
);

PROCEDURE findSiteUpdates (
	p_result     OUT SYS_REFCURSOR
);

PROCEDURE getSiteChanges (
	p_hist_id    IN NUMBER,
	p_ctms_id    IN VARCHAR2,
	p_result     OUT SYS_REFCURSOR
);

PROCEDURE getProjectData (
	p_customer   IN VARCHAR2,
	p_project    IN VARCHAR2,
	p_protocol   IN VARCHAR2,
	p_result     OUT SYS_REFCURSOR
);

PROCEDURE getJobErrorCount (
	p_job_id     IN NUMBER,
	p_result     OUT SYS_REFCURSOR
);

PROCEDURE legacyCGTSxlate (
	p_class         IN VARCHAR2,
	p_group         IN VARCHAR2,
	p_type          IN VARCHAR2,
	p_subtype       IN VARCHAR2,
	p_report_name   IN VARCHAR2,
	p_result        OUT SYS_REFCURSOR
);

PROCEDURE getCTMSdata (
	p_dataset        IN VARCHAR2,
	p_profile_id     IN NUMBER,
	p_result         OUT SYS_REFCURSOR
);

PROCEDURE getAllWingspanStatus (
	p_profile_id   IN NUMBER,
	p_result       OUT SYS_REFCURSOR
);

PROCEDURE setWingspanStatus (
	p_profile_id     IN NUMBER,
	p_class_name     IN VARCHAR2,
	p_country_code   IN VARCHAR2,
	p_site_id        IN VARCHAR2,
	p_ctms_transfer  IN NUMBER,
	p_build_status   IN NUMBER,
	p_ws_id          IN VARCHAR2,
	p_result         OUT SYS_REFCURSOR
);


END;
/


/******************************************
	 ---------- package body ----------
******************************************/
CREATE OR REPLACE PACKAGE BODY "ENGINE"
	AS


-- get the object type for tier
PROCEDURE getTier (
	p_tid          in NUMBER,
	p_tclass       in NUMBER,
	p_result     out SYS_REFCURSOR
) 
AS
BEGIN

	OPEN p_result FOR
		SELECT *
		FROM e3_container_hier
		WHERE template_id = p_tid
			and class_id = p_tclass;

END;

-- get dynamic groups that need to be created
PROCEDURE createGroups (
	p_tid        IN NUMBER,
	p_result     OUT SYS_REFCURSOR
)
AS
BEGIN

	OPEN p_result FOR
		SELECT group_name, dynamic_yn
		FROM e3_security_groups e1
		WHERE e1.template_id = p_tid
			and e1.dynamic_yn > 0;

END;

-- get leadership for groups
PROCEDURE getGroupLeaders (
	p_tid        IN NUMBER,
	p_result     OUT SYS_REFCURSOR
)
AS
BEGIN

	OPEN p_result FOR
		SELECT group_name, right_type, leadership
		FROM e3_security_groups e1
		WHERE e1.template_id = p_tid
			and e1.dynamic_yn > 0 
			and e1.leadership is not null;

END;

-- get dynamic group members
PROCEDURE getGroupMembers (
	p_tid        IN NUMBER,
	p_result     OUT SYS_REFCURSOR
)
AS
BEGIN

	OPEN p_result FOR
		SELECT group_name, right_type, membership
		FROM e3_security_groups e1 
		WHERE e1.template_id = p_tid
			and e1.membership is not null;

END;

-- get navigation (browse) permissions
PROCEDURE getNavigators (
	p_tid        IN NUMBER,
	p_result     OUT SYS_REFCURSOR
)
AS
BEGIN

	OPEN p_result FOR
		SELECT group_name, permission 
		FROM e3_security_groups e1 
		WHERE e1.template_id = p_tid
			and e1.navigation_yn = 1;

END;

-- get artifact permissions
PROCEDURE getArtifactPermissions (
	p_fid          IN NUMBER,
	p_class_mask   IN NUMBER,
	p_tid          IN NUMBER,
	p_result       OUT SYS_REFCURSOR
)
AS
BEGIN

	OPEN p_result FOR
		SELECT distinct group_name, permission 
		FROM e3_security_groups g 
		JOIN e3_folder_permission p 
			on g.permission_id = p.permission_id 
		JOIN e3_template_folders f 
			on f.folder_id = p.folder_id 
		WHERE f.folder_id = p_fid 
			and g.artifact_yn = 2 
			and (bitand(g.class_mask, p_class_mask) > 0) 
		UNION 
		SELECT group_name, permission 
		FROM e3_security_groups 
		WHERE artifact_yn = 1 
			and template_id = p_tid;

END;

-- unblinded artifact
PROCEDURE getUnblindedPermissions (
	p_fid          IN NUMBER,
	p_class_mask   IN NUMBER,
	p_tid          IN NUMBER,
	p_result     OUT SYS_REFCURSOR
)
AS
BEGIN

	-- unblinded access is now checked against the DIA_KEY
	-- 9xx series are IBR and external unblinded users are
	-- never allowed access
	OPEN p_result FOR
		SELECT distinct group_name, permission 
		FROM e3_security_groups g
		JOIN e3_template_folders f 
			on g.template_id = f.template_id
				and f.folder_id = p_fid
		WHERE g.unblinded_yn = 1 
			and g.template_id = p_tid
			and (
					f.dia_key not like '9__.__.__'
					or
					g.group_name not like '%EXTERNAL%'
				);

END;

-- get list of folders for the tier
PROCEDURE getFolderList (
	p_tid        IN NUMBER,
	p_tclass     IN NUMBER,
	p_all        IN NUMBER,
	p_result     OUT SYS_REFCURSOR
)
AS
BEGIN

	OPEN p_result FOR
		SELECT folder_id, parent_folder_id, 
			zone_id, zone_name, section_id, section_name, 
			artifact_id, artifact_name, artifact_seq, dia_key, 
			tmf_file_yn, unblinded_yn, jit_yn,
			e1.subtype, e1.document_category, e2.class_name AS TIER_NAME, 
			e1.description  
		FROM e3_template_folders e1, e3_container_hier e2 
		WHERE e1.template_id = p_tid 
			and e1.template_id = e2.template_id  
			and e2.class_id = p_tclass
			and ( 
				jit_yn = 0
				OR 
				1 = p_all
			)
			and (bitand(e1.artifact_class_mask, e2.class_mask) > 0)
		ORDER BY dia_key;

END;

-- get details for single JIT artifact
PROCEDURE getJITRecord (
	p_tid          IN NUMBER,
	p_tclass       IN NUMBER,
	p_zone         IN VARCHAR2,
	p_section      IN VARCHAR2,
	p_artifact     IN VARCHAR2,
	p_result       OUT SYS_REFCURSOR
)
AS
BEGIN

	OPEN p_result FOR
		SELECT folder_id, parent_folder_id,  
			zone_id, zone_name, section_id, section_name, 
			artifact_id, artifact_name, artifact_seq, dia_key,  
			tmf_file_yn, unblinded_yn,   
			e1.subtype, e1.document_category, e2.class_name AS TIER_NAME,  
			e1.description  
		FROM e3_template_folders e1, e3_container_hier e2  
		WHERE e1.template_id = p_tid 
			and e1.template_id = e2.template_id 
			and e2.class_id = p_tclass 
			and (bitand(e1.artifact_class_mask, e2.class_mask) > 0) 
			and zone_name = p_zone 
			and section_name = p_section 
			and artifact_name = p_artifact;

END;

-- parents for an artifact
PROCEDURE getParentList (
	p_fid        IN NUMBER,
	p_result     OUT SYS_REFCURSOR
)
AS
BEGIN

	OPEN p_result FOR
		SELECT zone_id, zone_name, section_id, section_name, dia_key 
		FROM e3_template_folders 
		start with folder_id = p_fid 
		connect by folder_id = prior parent_folder_id  
		ORDER BY section_id desc;

END getParentList;

-- get the customer folder from mapping table
PROCEDURE getCustomerFolder (
	p_cust_code  IN VARCHAR2,
	p_result     OUT SYS_REFCURSOR
)
AS
BEGIN

	OPEN p_result FOR
		SELECT customer_folder 
		FROM etmf.eelcustomermaptbl 
		WHERE customer_security_group_value = p_cust_code;

END;

-- lookup country name
PROCEDURE getCountryName (
	p_code       IN VARCHAR2,
	p_result     OUT SYS_REFCURSOR
)
AS
BEGIN

	OPEN p_result FOR
		SELECT country  
		FROM eel3.country 
		WHERE country_code = upper( p_code );

END;

-- lookup site data
-- get the site data, source history record
PROCEDURE getSiteData (
	p_project    IN VARCHAR2,
	p_protocol   IN VARCHAR2,
	p_site       IN VARCHAR2,
	p_result     OUT SYS_REFCURSOR
)
AS
BEGIN

	-- this query scans the site history table for the site number;
	-- handles case where request is for older site label that has
	-- been superceded
	OPEN p_result FOR
		SELECT s.project_code, s.protocol_number,  
			country AS country_name,  
			s.site_number, s.site_name, s.site_country_code, s.site_status, 
			s.principal_inv_full_name, 
			(
				select max(hist_id) 
				from elvis_ref.site_hist 
				where ctms_id = h.ctms_id 
			) AS hist_id 
		FROM site s, country c, elvis_ref.site_hist h  
		WHERE s.site_country_code = country_code 
			AND s.project_code = p_project 
			AND upper(s.protocol_number) = upper(p_protocol) 
			AND s.ctms_id = h.ctms_id
			AND h.site_number = p_site;

END;


-- search for a site object within CS10 folder
PROCEDURE findCS10Site (
	p_folder     IN NUMBER,
	p_project    IN VARCHAR2,
	p_protocol   IN VARCHAR2,
	p_site       IN VARCHAR2,
	p_result     OUT SYS_REFCURSOR
)
AS
BEGIN

	-- this query scans the site history table for the site number;
	-- this is matched by CTMS_ID to get a list of all know history ids
	-- which are tied to the SITE onject in CS10
	OPEN p_result FOR
		SELECT dataid, name, exatt2
		FROM etmf.dtree
		WHERE parentid = p_folder           -- country folder
			AND subtype = 10101             -- site subtype
			AND exatt2 IN (
					SELECT s.hist_id
					FROM elvis_ref.site_hist s, elvis_ref.site_hist h  
					WHERE s.project_code = p_project 
						AND upper(s.protocol_number) = upper(p_protocol) 
						AND s.ctms_id = h.ctms_id
						AND h.site_number = p_site
			);

END;


-- get site status (mapped to configuration)
PROCEDURE getSiteStatusConfig (
	p_cfg        IN VARCHAR2,
	p_result     OUT SYS_REFCURSOR
)
AS
BEGIN

	OPEN p_result FOR
		SELECT cfg_name 
		FROM e3_configuration  
		WHERE cfg_value = p_cfg 
			and cfg_name like '%site.status';

END;


-- find updated sites
PROCEDURE findSiteUpdates (
	p_result     OUT SYS_REFCURSOR
)
AS
BEGIN

	OPEN p_result FOR
		SELECT h1.dataid, h1.ctms_id, h1.hist_id, 
				sh.site_number, sh.project_code, sh.site_country_code
		FROM elvis_ref.site_hist sh,
			(
				SELECT dt.dataid, dt.exatt2, sh.hist_id, sh.ctms_id
				FROM etmf.dtree dt,
					elvis_ref.site_hist sh
				WHERE dt.subtype = 10101
					and dt.exatt2 = sh.hist_id
				UNION
				SELECT dt.dataid, dt.exatt2, sh.hist_id, sh.ctms_id
				FROM etmf.dtree dt,
					elvis_ref.site_hist_reject sh
				WHERE dt.subtype = 10101
					and dt.exatt2 = sh.hist_id
			) h1
		WHERE sh.ctms_id = h1.ctms_id
			and sh.hist_id > h1.hist_id;

END;

-- show changes for given site
PROCEDURE getSiteChanges (
	p_hist_id    IN NUMBER,
	p_ctms_id    IN VARCHAR2,
	p_result     OUT SYS_REFCURSOR
)
AS
BEGIN

	OPEN p_result FOR
		WITH arg as
		(
			SELECT p_hist_id as hist_id, p_ctms_id as ctms_id
			FROM dual
		)
		SELECT h1.ctms_id, h1.hist_id,
			site_number, site_name, site_status,
			site_country_code,
			principal_inv_first, principal_inv_last
		FROM elvis_ref.site_hist h1, arg
		WHERE h1.hist_id = arg.hist_id
		union
		SELECT h2.ctms_id, h2.hist_id,
			site_number, site_name, site_status,
			site_country_code,
			principal_inv_first, principal_inv_last
		FROM elvis_ref.site_hist_reject h2, arg
		WHERE h2.hist_id = arg.hist_id
		UNION
		SELECT distinct h3.ctms_id,
			h3.hist_id,
			h3.site_number, h3.site_name,
			h3.site_status,
			h3.site_country_code,
			h3.principal_inv_first,
			h3.principal_inv_last
		FROM elvis_ref.site_hist h3
		WHERE h3.hist_id = (
				select max(h4.hist_id)
				from elvis_ref.site_hist h4, arg
				where h4.ctms_id = arg.ctms_id );

END;

-- get general project data
PROCEDURE getProjectData (
	p_customer   IN VARCHAR2,
	p_project    IN VARCHAR2,
	p_protocol   IN VARCHAR2,
	p_result     OUT SYS_REFCURSOR
)
AS
BEGIN

	OPEN p_result FOR
		SELECT phase, therapeutic_area 
		FROM project p 
		WHERE customer = p_customer
			and project_code = p_project
			and upper(nvl(protocol_number, '-')) = upper(nvl(p_protocol, '-')); 

END;


-- get the customer folder from mapping table
PROCEDURE getJobErrorCount (
	p_job_id     IN NUMBER,
	p_result     OUT SYS_REFCURSOR
)
AS
BEGIN

	OPEN p_result FOR
		SELECT count('x') as "ERR_COUNT"
		FROM e3_audit_trail 
		WHERE project_job_id = p_job_id
			and description like '*ERR*%';

END;


-- legacy CLASS/GROUP/TYPE/SUBTYPE mapping
PROCEDURE legacyCGTSxlate (
	p_class         IN VARCHAR2,
	p_group         IN VARCHAR2,
	p_type          IN VARCHAR2,
	p_subtype       IN VARCHAR2,
	p_report_name   IN VARCHAR2,
	p_result        OUT SYS_REFCURSOR
)
AS
BEGIN

	OPEN p_result FOR
		SELECT e2.zone_name, e2.section_name, e2.artifact_name, 
				e1.abbreviation, 
				e1.tmf_item_id
		FROM e3_legacy_xlate e1, 
			e3_template_folders e2, 
			e3_container_hier e3 
		WHERE e3.class_name = p_class 
			and lgroup = p_group 
			and ltype = p_type 
			and NVL(lsubtype, 'NIL') = NVL(p_subtype, 'NIL') 
			and (
				NVL(report_name, 'NIL') = NVL(p_report_name, 'NIL') 
				or 
				report_name is null
			)
			and e1.dia_key = e2.dia_key 
			and e1.artifact_name = e2.artifact_name 
			and e2.template_id = ( 
					SELECT max(template_id) 
					FROM e3_template_versions 
					WHERE template_status = 'LOCKED' ) 
			and e2.template_id = e3.template_id 
			and (bitand(e2.artifact_class_mask, e3.class_mask) > 0)
		ORDER by report_name;

END;


-- get CTMS data for transmission to Wingspan
PROCEDURE getCTMSdata (
	p_dataset        IN VARCHAR2,
	p_profile_id     IN NUMBER,
	p_result         OUT SYS_REFCURSOR
)
AS
BEGIN

	CASE

		-- base study data
		-- NOTE: we have a problem with duplicate project data from multiple sources
		--       and other cases where the only sources are questionable,
		--       the return results are sorted in order of 'reliability',
		--       structures will only use the first value
		-- NOTE: any records without CTMS_ID will be excluded, otherwise they will
		--       be rejected by Wingspan
		WHEN p_dataset = 'study_details'
		THEN 
			OPEN p_result FOR
			WITH
			studies as (
				SELECT
					a.ctms_id as "CTMS_STABLE_ID",
					b.customer AS "PROGRAM_CODE",
					TRIM(a.protocol_number) AS "NAME",
                    DECODE(upper(SRC_LOC), 'NOVELLA', 'IQB', 'IQVIA') 
						|| nvl2(program_name, ' Program:' || program_name, '')
						|| ' - Project Codes:' 
						|| (
								SELECT LISTAGG (project_code, ',') WITHIN GROUP (order by project_code)
								FROM (
										SELECT project_code, protocol_number
										FROM elvis_ref.project
										UNION
										SELECT project_code, protocol_number
										FROM elvis_ref.project_mapping
									) z
								WHERE upper(z.protocol_number) = upper(a.protocol_number)
								GROUP BY upper(z.protocol_number)
							)
						|| nvl2(service_line, ' ' || service_line || ' ', '')
						|| decode(c.is_firewall, 1, ' (FIREWALLED)', '')
						as "STUDY_IDENTIFIER",
					a.study_design as "STUDY_DESCRIPTION",
					a.indications as "STUDY_TYPE",
					a.phase as "PHASE",
					null as "FINANCIAL_DISCLOSURE",
					a.therapeutic_area as "THERAPEUTIC_AREA",     -- aka DISEASE_AREA
					null as "COMPOUND",
					null as "GENERIC_NAME",
					a.study_status as "CTMS_STATUS",
					a.eudract_id as "EUDRACT_NUM",
                    DECODE(upper(SRC_LOC), 'NOVELLA', 'IQB', 'IQVIA')||' - '|| a.service_line as "SPONSORING_UNIT",
					b.customer as "BUSINESS_GROUP"
				FROM elvis_ref.project a
				JOIN elvis_ref.tmf_study_env_lookup_v b
					on a.protocol_number = b.protocol_number
				JOIN e3_study_profile c
					on a.protocol_number = c.protocol_number
						and b.customer = c.customer
						and (
								(p_profile_id = c.profile_id and (c.study_health = 1 or c.hosting_env = 'Wingspan') )
								or
								(p_profile_id = -2 and c.study_health = 1)
								or
								(p_profile_id = -3 and c.hosting_env = 'Wingspan')
							)
				WHERE 1 = 1
					and a.ctms_id is not null
					and (
						c.profile_id = p_profile_id
						or
						(
							p_profile_id in (-2, -3) 
							and 
							nvl(a.update_timestamp, a.insert_timestamp) > (
									select max(request_time)
									from e3_project_job
									where job_type = 6
										and status = 3
								)
						)
					)
				ORDER by 
					nvl2(a.ctms_id, 1, 9),
					decode(a.src_loc, 'CTMS', 1, 'NOVELLA', 2, 9)
			)
			SELECT *
			FROM studies
			WHERE p_profile_id < 0
				or rownum = 1;


		-- study milestone
		WHEN p_dataset = 'study_milestone'
		THEN 
			OPEN p_result FOR
				SELECT 
                    T1.CTMS_STABLE_ID as "CTMS_STABLE_ID",
					t1.protocol_number as "STUDY_NAME",
					t1.milestone_name,
					to_char(t1.planned_date, 'yyyy-mm-dd') as "PLANNED_DATE",
					to_char(t1.actual_date, 'yyyy-mm-dd') as "ACTUAL_DATE"
				FROM elvis_ref.study_milestones t1
				JOIN e3_study_profile t2
					on t1.protocol_number = t2.protocol_number
						and t1.customer = t2.customer
						and (
								(p_profile_id = t2.profile_id and (t2.study_health = 1 or t2.hosting_env = 'Wingspan') )
								or
								(p_profile_id = -2 and t2.study_health = 1)
								or
								(p_profile_id = -3 and t2.hosting_env = 'Wingspan')
							)
				WHERE 1 = 1
					and (
						t2.profile_id = p_profile_id
						or 
						( 
							p_profile_id in (-2, -3) 
							and 
							t1.trans_date > (
									select max(request_time) 
									from e3_project_job
									where job_type = 6
										and status = 3
								)
						)
					);

		-- base site data
		WHEN p_dataset = 'site'
		THEN 
			OPEN p_result FOR
				SELECT 
					t1.ctms_id as "CTMS_STABLE_ID",
					t1.protocol_number as "STUDY_NAME",
					t1.site_number as "CTMS_SITE_ID",
					t1.site_name as "NAME",
					t1.site_country_name as "COUNTRY",
					replace(t1.site_status, ',', '') as "SITE_STATUS",
					null as "ADDRESS_LINE_1",
					null as "ADDRESS_LINE_2",
					null as "CITY",
					null as "STATE_PROVINCE",
					null as "POSTAL_CODE",
					null as "ENROLLMENT_TARGET",       -- not required
					null as "ENROLLMENT"               -- not required
				FROM elvis_ref.site t1
				JOIN e3_study_profile t2
					on t1.protocol_number = t2.protocol_number
						and (
								(p_profile_id = t2.profile_id and (t2.study_health = 1 or t2.hosting_env = 'Wingspan') )
								or
								(p_profile_id = -2 and t2.study_health = 1)
								or
								(p_profile_id = -3 and t2.hosting_env = 'Wingspan')
							)
				WHERE 1 = 1
					and (
						t2.hosting_env = 'Wingspan' 
						or 
						(
							t1.site_number not like 'TBD%' 
							and 
							exists (
								select 'x' 
								from e3_configuration t3 
								where t3.cfg_name = 'health.upload.site.status_to_transmit'
									and t3.cfg_value = t1.site_status
							)
						)
					)
					and (
						t2.profile_id = p_profile_id
						or 
						( 
							p_profile_id in (-2, -3) 
							and 
							nvl(t1.update_timestamp, t1.insert_timestamp) > (
									select max(request_time) 
									from e3_project_job
									where job_type = 6
										and status = 3
								)
						)
					);

		-- site investigator data
		WHEN p_dataset = 'site_investigator'
		THEN 
			OPEN p_result FOR
				SELECT 
					t1.src_party_id as "CTMS_STABLE_ID",
					t1.protocol_number as "STUDY_NAME",
					t1.site_number as "CTMS_SITE_ID",
					t1.src_party_id as "INVESTIGATOR_ID",
					t1.first_name,
					t1.middle_name,
					t1.last_name,
					t1.pi_yn as "PRINCIPAL",
					'N' as "OVERRIDE",
					decode(t1.pi_yn, 'O', 'Other', null) as "ROLE",
					null as "EMAIL_ADDRESS"
				FROM elvis_ref.site_participants t1
				JOIN elvis_ref.tmf_study_env_lookup_v t2
					on t1.protocol_number = t2.protocol_number
				JOIN e3_study_profile t3
					on t1.protocol_number = t3.protocol_number
						and t2.customer = t3.customer
						and (
								(p_profile_id = t3.profile_id and (t3.study_health = 1 or t3.hosting_env = 'Wingspan') )
								or
								(p_profile_id = -2 and t3.study_health = 1)
								or
								(p_profile_id = -3 and t3.hosting_env = 'Wingspan')
							)
				WHERE 1 = 1
--					and t1.pi_yn != 'O'
					and (
							t3.profile_id = p_profile_id
							or 
						( 
							p_profile_id in (-2, -3) 
							and 
							nvl(t1.update_timestamp, t1.insert_timestamp) > (
									select max(request_time) 
									from e3_project_job
									where job_type = 6
										and status = 3
								)
						)
					)
				ORDER by decode(t1.pi_yn, 'Y', 1, 'N', 2, 3);

		-- site milestone data
		WHEN p_dataset = 'site_milestone'
		THEN 
			OPEN p_result FOR
				SELECT 
                    T1.CTMS_STABLE_ID as "CTMS_STABLE_ID",
					t1.protocol_number as "STUDY_NAME",
					t1.site_number as "CTMS_SITE_ID",
					t1.milestone_name,
					to_char(t1.planned_date, 'yyyy-mm-dd') as "PLANNED_DATE",
					to_char(t1.actual_date, 'yyyy-mm-dd') as "ACTUAL_DATE"
				FROM elvis_ref.site_milestones t1
				JOIN e3_study_profile t2
					on t1.protocol_number = t2.protocol_number
						and t1.customer = t2.customer
						and (
								(p_profile_id = t2.profile_id and (t2.study_health = 1 or t2.hosting_env = 'Wingspan') )
								or
								(p_profile_id = -2 and t2.study_health = 1)
								or
								(p_profile_id = -3 and t2.hosting_env = 'Wingspan')
							)
				WHERE 1 = 1
					and (
						t2.profile_id = p_profile_id
						or 
						( 
							p_profile_id in (-2, -3) 
							and 
							t1.trans_date > (
									select max(request_time) 
									from e3_project_job
									where job_type = 6
										and status = 3
								)
						)
					);

		ELSE
			OPEN p_result FOR
				SELECT *
				FROM dual;


	END CASE;

END;


-- get Wingspan wizard status
PROCEDURE getAllWingspanStatus (
	p_profile_id   IN NUMBER,
	p_result       OUT SYS_REFCURSOR
)
AS
BEGIN

	OPEN p_result FOR
		SELECT 
			t1.profile_id,
			t2.customer,
			t2.project_code,
			t2.protocol_number,
			t1.class_name,
			t1.country_code,
			t1.site_id,
			t1.ctms_transfer,
			t1.build_status,
			t1.ws_id,
			case
				when t2.study_health = 1 then 'health'
				when t2.hosting_env = 'Wingspan' then 'tmf'
				else 'invalid'
			end as "CLOUD_TYPE",
			t1.trans_timestamp
		FROM e4_wingspan_build t1
		JOIN e3_study_profile t2
			on t1.profile_id = t2.profile_id
		WHERE 1 = 1
			and class_name = 'Core'
			and (t1.profile_id = p_profile_id
				or p_profile_id is null);

END;


-- get Wingspan wizard status
PROCEDURE setWingspanStatus (
	p_profile_id     IN NUMBER,
	p_class_name     IN VARCHAR2,
	p_country_code   IN VARCHAR2,
	p_site_id        IN VARCHAR2,
	p_ctms_transfer  IN NUMBER,
	p_build_status   IN NUMBER,
	p_ws_id          IN VARCHAR2,
	p_result         OUT SYS_REFCURSOR
)
AS
BEGIN

	MERGE 
			into e4_wingspan_build t1 
			using (
					select 
						p_profile_id as pid,
						p_class_name as pclass,
						nvl(p_country_code, '-') as pcountry,
						nvl(p_site_id, '-') as psite
					from dual
				) t2 
				on (
					t2.pid = t1.profile_id
					and t2.pclass = t1.class_name
					and t2.pcountry = t1.country_code
					and t2.psite = t1.site_id
				)
		WHEN matched 
			THEN 
				update set 
					ctms_transfer = p_ctms_transfer, 
					build_status = p_build_status, 
					ws_id = p_ws_id,
					trans_timestamp = sysdate
		WHEN not matched 
			THEN 
				insert (
					profile_id, 
					class_name, 
					country_code, 
					site_id, 
					ctms_transfer, 
					build_status, 
					ws_id
				) 
				values (
					p_profile_id, 
					p_class_name, 
					nvl(p_country_code, '-'), 
					nvl(p_site_id, '-'),
					p_ctms_transfer, 
					p_build_status, 
					p_ws_id
				);

	OPEN p_result FOR
		select 1 as "STATUS"
		from dual;

	EXCEPTION
		WHEN OTHERS THEN
			OPEN p_result FOR
				select -1 as "STATUS"
				from dual;

END;


END;
/
