create or replace function drop_e3_profile 
	(
		old_profile_id in number  
	) 
	return number
AS 
PRAGMA AUTONOMOUS_TRANSACTION;

	rec_count number;

BEGIN

	rec_count := 0;
	
	delete e4_wingspan_build
	where profile_id = old_profile_id;
	rec_count := rec_count + SQL%ROWCOUNT;
	
	delete e3_audit_trail
	where profile_id = old_profile_id;
	rec_count := rec_count + SQL%ROWCOUNT;

	delete e3_project_job_events
	where profile_id = old_profile_id;
	rec_count := rec_count + SQL%ROWCOUNT;

	delete e3_project_job
	where profile_id = old_profile_id;
	rec_count := rec_count + SQL%ROWCOUNT;

	delete e3_study_profile_rendering
	where profile_id = old_profile_id;
	rec_count := rec_count + SQL%ROWCOUNT;

	delete e3_study_profile
	where profile_id = old_profile_id;
	rec_count := rec_count + SQL%ROWCOUNT;

	commit;

	return rec_count;

end drop_e3_profile;

