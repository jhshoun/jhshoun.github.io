
SET DEFINE OFF;
SET TIMING ON;
set feedback off;
select to_char(sysdate, 'YYYY-MON-DD HH24:MI:SS') as run_date from dual;
set feedback on;

--
-- WINGSPAN_UPLOAD  (Package Body) 
--
CREATE OR REPLACE PACKAGE BODY TMF_HEALTH.WINGSPAN_UPLOAD 
AS

/**

3.0.1       23-MAY-2019     JShoun          new job start routines for HC 2.0
3.0.5       19-JUL-2019     JKinnaird       fixes for update process for HC 2.0
3.0.8       18-SEP-2019     MBurmeister     Added routing to exp_run_study to set docs from dropped sites to Deleted in Export table
3.0.9       13-MAY-2021     JShoun          changed the delimiter from '|' to '0X1E' (RS) to protect doc names

**/


PROCEDURE SET_JOB_STATUS (
		p_jobid       in NUMBER,
		p_jobstatus   in VARCHAR2
	)
AS
BEGIN

	update exp_job_master
	set jobstatus = p_jobstatus
	where jobid = p_jobid;

	commit;

END SET_JOB_STATUS;


PROCEDURE SET_DOC_UPLOAD_STATUS (
		p_dataid              in NUMBER,
		p_wingspan_id         in VARCHAR2,
		p_wingspan_response   in VARCHAR2,
		p_error_group         in VARCHAR2
	)
AS

  v_curr_rec_type   varchar2(100);

BEGIN
    
    -- check if the rec type 
	SELECT rec_type INTO v_curr_rec_type
	FROM exp_document_export
	WHERE dataid = p_dataid; 

    IF v_curr_rec_type = 'UPDATE' THEN
        IF p_error_group = 'METADATA' OR p_error_group = 'MATCH' THEN
            -- no match or failed finalize, but the delete ocurred
            UPDATE exp_document_export
            SET wingspan_id = p_wingspan_id,
				wingspan_response = substr(p_wingspan_response,0,2000),
				error_group = substr(p_error_group,0,80),
                rec_type = 'UPLOAD'
            WHERE dataid = p_dataid;
        ELSE
            -- failed on the delete step so run as update next run
            UPDATE exp_document_export
            SET wingspan_id = p_wingspan_id,
				wingspan_response = substr(p_wingspan_response,0,2000),
				error_group = substr(p_error_group,0,80)
            WHERE dataid = p_dataid;
        
        END IF;
    ELSE
        --no change to rec_type needed
        UPDATE exp_document_export
        SET wingspan_id = p_wingspan_id,
			wingspan_response = substr(p_wingspan_response,0,2000),
			error_group = substr(p_error_group,0,80)
        WHERE dataid = p_dataid;
    
    END IF;

	COMMIT;

END SET_DOC_UPLOAD_STATUS;



PROCEDURE REMOVE_STAGING_DOC (
		p_jobid        in NUMBER,
		p_order       in NUMBER
	)
AS
BEGIN

	DELETE exp_stg_export
	WHERE jobid = p_jobid
		and line_order = p_order;

	commit;

END REMOVE_STAGING_DOC;


PROCEDURE GET_JOB_EXPORT_DOCS (
		p_jobid        in NUMBER,
		p_offset       in NUMBER,
		p_result       out SYS_REFCURSOR
	)
AS
BEGIN

	-- ignore the offset and hard code to 15k recs at a time to avoid the re-read issue
	OPEN p_result FOR
        SELECT *
		FROM (
				SELECT distinct
                       dataid,
                       jobid,
                       'FILE.CSV' as "FILE_NAME",
                       line_order,
                       file_line
                  FROM exp_stg_export
                 WHERE jobid = p_jobid
					and line_order != 0
				ORDER BY line_order
			) a
		WHERE rownum <= 15000
        ORDER BY line_order;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN 
            -- don't raise an error to stop processing
            DBMS_OUTPUT.PUT_LINE('No Data found selecting job rows from exp_stg_export. ');

        WHEN OTHERS THEN 
            RAISE_APPLICATION_ERROR(-20033, 'ERROR selecting job rows from exp_stg_export: '||SQLERRM,FALSE);


END GET_JOB_EXPORT_DOCS;


PROCEDURE GET_JOB_RUN_QUEUE (
		p_result       out SYS_REFCURSOR
	)
AS
BEGIN

	-- get next studies to process based on oldest run date and
	-- not executed on the current calendar day
	OPEN p_result FOR
		SELECT 
			a.sponsor, 
			a.protocol_number
		FROM exp_study_list a
		-- status of the last job
		LEFT OUTER JOIN (
				select
				jobcreated,
				jobstatus,
				jobparam
				from exp_job_master b1
				where jobid = (
								select max(jobid) 
								from exp_job_master b2 
								where b2.jobparam = b1.jobparam
							)
			) b
			on b.jobparam = a.sponsor||':'||a.protocol_number
		-- error runs for current day
		LEFT OUTER JOIN (
				select
					count(1) as "ERR_COUNT",
					jobparam
				from exp_job_master
				where exportcount = -1
					and to_char(jobcreated, 'DD') = to_char(sysdate, 'DD')
				group by jobparam
			) c
			on c.jobparam = a.sponsor||':'||a.protocol_number
		WHERE 1 = 1
			and a.all_job_yn = 'Y'
			and nvl(b.jobstatus, 'NEW') in ('COMPLETED', 'NEW')
			and (
				-- no job run today
				to_char(sysdate, 'DD') != to_char( b.jobcreated, 'DD')
				or
				b.jobcreated is null
				or
				-- current day errored and runs are 3 or less
				c.err_count between 1 and 2
			)
		ORDER BY nvl(a.last_jobid, 0) asc;

	EXCEPTION
		WHEN NO_DATA_FOUND THEN 
			-- don't raise an error to stop processing
			DBMS_OUTPUT.PUT_LINE('No studies ready for job run.');

END GET_JOB_RUN_QUEUE;


-- remove temp records from document staging
PROCEDURE CLEAR_EXP_STAGE
AS
BEGIN

    execute immediate 'TRUNCATE TABLE exp_stg_export REUSE STORAGE';

END CLEAR_EXP_STAGE;

-- change job status to completed
PROCEDURE SET_COMPLETED (
    p_jobid IN NUMBER
)
AS
BEGIN

	UPDATE exp_job_master
	SET jobstatus = 'COMPLETED'
	WHERE jobid = p_jobid;

	UPDATE exp_study_list
	SET curr_status = 'COMPLETED'
	WHERE sponsor || ':' || protocol_number = (
			select jobparam
			from exp_job_master
			where jobid = p_jobid
		);

	commit;

END SET_COMPLETED;


-- procedure to update single row of all changed metadata
PROCEDURE updateDocMetaData (
    in_dataid in NUMBER, 
    in_inclusion_code in VARCHAR2,
    in_inclusion_reason in VARCHAR2,
    in_jobid in NUMBER,
    out_complete out NUMBER 

) AS                               

    v_doc_exp_row exp_document_export%ROWTYPE;

BEGIN
    out_complete := 0;

    SELECT * INTO v_doc_exp_row FROM exp_document_export WHERE dataid = in_dataid;

    v_doc_exp_row.REC_TYPE := in_inclusion_code;
    v_doc_exp_row.EXPORT_REASON := in_inclusion_reason;
    v_doc_exp_row.EXPORTID := in_jobid;

    SELECT a.DATAID DATAID,
           a.CUSTOMER Sponsor,
           a.PROTOCOL_NUMBER,
           a.project_code,
           a.country,
           a.country_code,
           a.site_id,
           a.site_name,
           CASE 
            WHEN a.site_id IS NOT NULL
                THEN pi_lookup(a.protocol_number, a.site_id)    
            ELSE
                NULL
           END as "INVESTIGATOR_NAME",
           e.doc_class class,
           e.doc_zone zone,
           e.doc_section section,
           e.doc_artifact artifact,
           e.dia_key,
           trim(BOTH ' ' FROM e.doc_abbreviation) as doc_abbreviation,
           e.is_unblinded,
           e.doc_full_name,
           CASE
              WHEN e.DOC_DATE IS NULL
               AND e.SUBTYPE = 749
              THEN
                 (SELECT TRUNC (NVL (NVL (o.OTEMAILSENTDATE, o.OTEMAILRECEIVEDDATE), dt.createdate))
                    FROM ETMF.OTEMAILPROPERTIES o, ETMF.DTREE DT
                   WHERE o.nodeid(+) = dt.dataid
                     AND dt.dataid = e.DATAID)
              WHEN e.DOC_DATE IS NULL
              THEN
                 TRUNC (b.createdate)
              ELSE
                 e.DOC_DATE
           END AS "DOC_DATE",
           b.createdate,
           CASE
            WHEN e.doc_lang IS NULL AND e.lang_abbreviation IS NULL
                THEN NULL
            ELSE
                LANG_LOOKUP(a.dataid, 1) 
           END AS "NEW_LANG", 
           CASE
            WHEN e.doc_lang IS NULL AND e.lang_abbreviation IS NULL
                THEN NULL
           ELSE
               LANG_LOOKUP(a.dataid, 0) 
           END as "NEW_ABBREV",          
           E.LANG_ID "LANGUAGEIDENTIFIER",
           ELVIS_REF.ASCII_REPLACE(ELVIS_REF.NAME_INIT(E.FIRST_NAME)),
           ELVIS_REF.ASCII_REPLACE(ELVIS_REF.NAME_INIT(E.LAST_NAME)),
           E.ORGANIZATION_ID,
           E.DRUG_TYPE,
           E.VISIT_TYPE,
           E.VISIT_DOC_ID,
           E.REPORT_VERSION,
           E.EVENT_ID "EVENTIDENTIFIER",
           SYSDATE,
           b.parentid,
           b.ownerid
     INTO  v_doc_exp_row.DATAID, 
           v_doc_exp_row.SPONSOR, 
           v_doc_exp_row.PROTOCOL_NUMBER, 
           v_doc_exp_row.PROJECT_CODE, 
           v_doc_exp_row.COUNTRY, 
           v_doc_exp_row.COUNTRY_CODE, 
           v_doc_exp_row.SITE_ID, 
           v_doc_exp_row.SITE_NAME, 
           v_doc_exp_row.INVESTIGATOR_NAME, 
           v_doc_exp_row.CLASS, 
           v_doc_exp_row.ZONE, 
           v_doc_exp_row.SECTION, 
           v_doc_exp_row.ARTIFACT, 
           v_doc_exp_row.DIA_KEY, 
           v_doc_exp_row.DOC_ABBREVIATION, 
           v_doc_exp_row.IS_UNBLINDED, 
           v_doc_exp_row.DOC_FULL_NAME, 
           v_doc_exp_row.DOC_DATE, 
           v_doc_exp_row.CREATEDATE, 
           v_doc_exp_row.DOCUMENTLANGUAGE, 
           v_doc_exp_row.LANGUAGEABBREVIATION, 
           v_doc_exp_row.LANGUAGEIDENTIFIER, 
           v_doc_exp_row.FIRST_NAME, 
           v_doc_exp_row.LAST_NAME, 
           v_doc_exp_row.ORGANIZATION_ID, 
           v_doc_exp_row.DRUG_TYPE, 
           v_doc_exp_row.VISIT_TYPE, 
           v_doc_exp_row.VISIT_DOC_ID, 
           v_doc_exp_row.REPORT_VERSION, 
           v_doc_exp_row.EVENTIDENTIFIER, 
           v_doc_exp_row.LAST_UPD_DT, 
           v_doc_exp_row.PARENTID, 
           v_doc_exp_row.PROJECT_DATAID
      FROM ETMF.EEL_PROJECT_DATA_MV a,
           ETMF.DTREE b,
           ETMF.EEL_CAT_DOC_DATA_MV e,
           (SELECT ownerid FROM ETMF.dtree WHERE subtype = 3030) rec
     WHERE a.dataid = in_dataid
       AND a.dataid = b.dataid
       AND a.dataid = e.dataid
       AND b.ownerid != rec.ownerid
       AND e.date_id <> 'LLF'
       AND e.is_tmf = 'YES';

    UPDATE exp_document_export
       SET ROW = v_doc_exp_row
     WHERE dataid = in_dataid;

    COMMIT;

    EXCEPTION
        WHEN TOO_MANY_ROWS THEN 
            RAISE_APPLICATION_ERROR(-20030,' MULTIPLE ROWS RETURNED WHILE UPDATING DOCUMENT METADATA. Dataid: '||to_char(in_dataid)||' Job id: '||to_char(in_jobid),FALSE);
            out_complete := 1;
        WHEN NO_DATA_FOUND THEN 
            -- don't raise an error to stop processing
            DBMS_OUTPUT.PUT_LINE('No Data found while updating record. Dataid: '||to_char(in_dataid)||' Job id: '||to_char(in_jobid));
            -- TODO: handle as a FAILED UPDATE outside of exception
            out_complete := 0;
        WHEN OTHERS THEN 
            RAISE_APPLICATION_ERROR(-20032, 'AN ERROR HAS OCCURRED WHILE UPDATING DOCUMENT METADATA. Dataid: '||to_char(in_dataid)||' Job id: '||to_char(in_jobid),FALSE);
            out_complete := 1;   

END updateDocMetaData;    

PROCEDURE   exp_run_study
(
p_sponsor IN VARCHAR2,
p_protocol_number IN VARCHAR2,
p_run_dt IN DATE,
p_jobid IN NUMBER
)
AS
    v_cnt_chk       NUMBER;
    v_run_dt        DATE DEFAULT SYSDATE;
    v_status        VARCHAR2(25) := 'NO_UPDATES';
    v_protnum_std   VARCHAR2(255 CHAR);
    v_q_url         VARCHAR2(1000 CHAR);
    v_rec_type      VARCHAR2(20 BYTE);
    o_return_val    NUMBER := 0;
    v_last_jobid    NUMBER := 0; 
    v_last_status   VARCHAR2(25);
    v_rec_count     NUMBER := 0;
    -- Document Moved within the project
    CURSOR C1 is 
    	 SELECT	a.dataid,
                a.wingspan_id
           FROM	EXP_DOCUMENT_EXPORT a,
                ETMF.dtree b,
                ETMF.EEL_PROJECT_DATA_MV ep,
                (SELECT ownerid FROM ETMF.dtree WHERE subtype = 3030) rec
         WHERE	a.dataid = b.dataid
			AND a.protocol_number = p_protocol_number
        	AND b.MODIFYDATE >= A.LAST_UPD_DT
			AND a.dataid = ep.dataid
			AND a.parentid != b.parentid
			AND b.ownerid != rec.ownerid
            AND b.ownerid = a.project_dataid
			AND NVL(ep.site_id,'0') NOT LIKE 'TBD%'
			AND a.REC_TYPE != 'DELETE';      

    -- Document Name changed
	CURSOR C2 is 
		 SELECT	a.dataid,
                a.wingspan_id
		   FROM	EXP_DOCUMENT_EXPORT a,
				ETMF.dtree b,
				ETMF.EEL_CAT_DOC_DATA_MV e,
				ETMF.EEL_PROJECT_DATA_MV ep,
    			(SELECT ownerid FROM ETMF.dtree WHERE subtype = 3030) rec
		  WHERE	a.dataid = b.dataid
			AND a.dataid = e.dataid
			AND a.protocol_number = p_protocol_number
			AND b.MODIFYDATE >= A.LAST_UPD_DT
			AND a.doc_full_name != e.doc_full_name
			AND a.parentid = b.parentid
            AND b.ownerid = a.project_dataid
			AND b.ownerid != rec.ownerid
			AND a.dataid = ep.dataid
			AND NVL(ep.site_id,'0') NOT LIKE 'TBD%'
			AND a.REC_TYPE != 'DELETE';    

	-- Site Number changed and possible move
	CURSOR C3 is 
		 SELECT	a.dataid,
                a.wingspan_id
		   FROM	EXP_DOCUMENT_EXPORT a,
				ETMF.dtree b,
				ETMF.EEL_PROJECT_DATA_MV ep,
				(SELECT ownerid FROM ETMF.dtree WHERE subtype = 3030) rec
		  WHERE	a.dataid = b.dataid
			AND a.protocol_number = p_protocol_number
			AND b.MODIFYDATE >= A.LAST_UPD_DT
			AND a.dataid = ep.dataid
			AND a.site_id != ep.site_id
            AND b.ownerid = a.project_dataid
			AND NVL(ep.site_id,'0') NOT LIKE 'TBD%'
			AND b.ownerid != rec.ownerid
			AND a.REC_TYPE != 'DELETE';  

   	-- unDelete processing
	CURSOR C4 is 
		 SELECT	a.dataid,
                a.wingspan_id
		   FROM	EXP_DOCUMENT_EXPORT a, 
				ETMF.DTREE b,
 	            ETMF.EEL_PROJECT_DATA_MV ep,
				ETMF.EEL_CAT_DOC_DATA_MV ec,
			    (SELECT ownerid FROM ETMF.dtree WHERE subtype = 3030) rec
		  WHERE	a.protocol_number = p_protocol_number
			AND	a.rec_type = 'DELETE'
			AND a.dataid = b.dataid
            AND a.project_dataid = b.ownerid
			AND a.dataid = ep.dataid
			AND a.dataid = ec.dataid
			AND ec.is_tmf = 'YES'
			AND NVL(ep.site_id,'0') NOT LIKE 'TBD%'
            AND ec.date_id <> 'LLF'
            AND b.ownerid != rec.ownerid;

BEGIN

  IF p_run_dt IS NOT NULL THEN
     v_run_dt := p_run_dt;
  END IF;

  SELECT count(*)
    INTO v_cnt_chk
    FROM tmf_health.exp_study_list a
   WHERE a.sponsor = p_sponsor
     AND a.protocol_number = p_protocol_number;

  SELECT var_value
    INTO v_q_url
    FROM tmf_health.exp_job_config
   WHERE var_name='EXP_Q_URL';

  IF v_cnt_chk > 0 THEN

    DBMS_OUTPUT.PUT_LINE('1. exp_run_study: start for protocol: '||p_protocol_number|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));            
    --existing sponsor/protocol number
    SELECT curr_status, last_jobid, last_status 
      INTO v_status, v_last_jobid, v_last_status
      FROM tmf_health.exp_study_list a
     WHERE a.sponsor = p_sponsor
       AND a.protocol_number = p_protocol_number;

    IF v_status = 'ERROR' THEN
       --raise some error
       raise_application_error(-20996, 'Previous ERROR for :'||p_protocol_number||' ,investigation and manual intervention required.');
    ELSE

        -- UPDATE  DOCUMENT_MOVED
        DBMS_OUTPUT.PUT_LINE('2. exp_run_study: DOCUMENT_MOVED update'|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
        FOR myrec in C1 LOOP
            v_status := 'UPDATED';
            IF myrec.wingspan_id IS NULL THEN 
                v_rec_type := 'UPLOAD'; 
            ELSE 
                v_rec_type := 'UPDATE'; 
            END IF;

            updateDocMetaData( myrec.dataid, v_rec_type, 'DOCUMENT_MOVED', p_jobid, o_return_val);
            IF o_return_val > 0 THEN
                RAISE_APPLICATION_ERROR(-20006, 'ERROR updating DOCUMENT_MOVED export run record for dataid: '||to_char(myrec.dataid),FALSE);
            END IF;
            COMMIT;
            v_rec_count := v_rec_count + 1;
        END LOOP;
        DBMS_OUTPUT.PUT_LINE('2. exp_run_study: DOCUMENT_MOVED complete. rec_count: '|| to_char(v_rec_count) || ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
        v_rec_count := 0;

        -- UPDATE  DOCUMENT_NAME_CHANGE
        DBMS_OUTPUT.PUT_LINE('3. exp_run_study: DOCUMENT_NAME_CHANGE update'|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
        FOR myrec in C2 LOOP
            v_status := 'UPDATED';
            IF myrec.wingspan_id IS NULL THEN 
                v_rec_type := 'UPLOAD'; 
            ELSE 
                v_rec_type := 'UPDATE'; 
            END IF;

            updateDocMetaData( myrec.dataid, v_rec_type, 'DOCUMENT_NAME_CHANGE', p_jobid, o_return_val);
            IF o_return_val > 0 THEN
                RAISE_APPLICATION_ERROR(-20006, 'ERROR updating DOCUMENT_NAME_CHANGE export run record for dataid: '||to_char(myrec.dataid),FALSE);
            END IF;
            COMMIT;
            v_rec_count := v_rec_count + 1;
        END LOOP;
        DBMS_OUTPUT.PUT_LINE('3. exp_run_study: DOCUMENT_NAME_CHANGE complete. rec_count: '|| to_char(v_rec_count) || ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
        v_rec_count := 0;

        -- UPDATE    SITE_NUMBER_CHANGED
        DBMS_OUTPUT.PUT_LINE('4. exp_run_study: SITE_NUMBER_CHANGED update'|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
        FOR myrec in C3 LOOP
            v_status := 'UPDATED';
            IF myrec.wingspan_id IS NULL THEN 
                v_rec_type := 'UPLOAD'; 
            ELSE 
                v_rec_type := 'UPDATE'; 
            END IF;

            updateDocMetaData( myrec.dataid, v_rec_type, 'SITE_NUMBER_CHANGED', p_jobid, o_return_val);
            IF o_return_val > 0 THEN
                RAISE_APPLICATION_ERROR(-20006, 'ERROR updating SITE_NUMBER_CHANGED export run record for dataid: '||to_char(myrec.dataid),FALSE);
            END IF;
            COMMIT;
            v_rec_count := v_rec_count + 1;
        END LOOP; 
        DBMS_OUTPUT.PUT_LINE('4. exp_run_study: SITE_NUMBER_CHANGED complete. rec_count: '|| to_char(v_rec_count) || ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
        v_rec_count := 0; 

        -- UPDATE UNDELETED documents
        DBMS_OUTPUT.PUT_LINE('5. exp_run_study: DOCUMENT_UNDELETE update'|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
        FOR myrec in C4 LOOP
            v_status := 'UPDATED';
            IF myrec.wingspan_id IS NULL THEN 
                v_rec_type := 'UPLOAD'; 
            ELSE 
                v_rec_type := 'UPDATE'; 
            END IF;

            updateDocMetaData( myrec.dataid, v_rec_type, 'DOCUMENT_UNDELETE', p_jobid, o_return_val);
            IF o_return_val > 0 THEN
                RAISE_APPLICATION_ERROR(-20006, 'ERROR updating UNDELETE export run record for dataid: '||to_char(myrec.dataid),FALSE);
            END IF;
            COMMIT;
            v_rec_count := v_rec_count + 1;
        END LOOP;     
        DBMS_OUTPUT.PUT_LINE('5. exp_run_study: DOCUMENT_UNDELETE complete. rec_count: '|| to_char(v_rec_count) || ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
        v_rec_count := 0; 

        -- Update records that have been deleted
        -- Use of NVL2: For records that have a NULL wingspan id, set the export id to 0 so they will not be sent as there is nothing to delete in health app
        DBMS_OUTPUT.PUT_LINE('5. exp_run_study: DOCUMENT_DELETED update'|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
        UPDATE EXP_DOCUMENT_EXPORT
           SET REC_TYPE = 'DELETE',
               EXPORT_REASON = 'DOCUMENT_DELETED',
               EXPORTID = NVL2(wingspan_id, p_jobid, 0),
               LAST_UPD_DT = SYSDATE
         WHERE dataid in ( SELECT a.dataid
                             FROM EXP_DOCUMENT_EXPORT a,
                                  ETMF.DTREE b,
                                  (SELECT ownerid FROM ETMF.DTREE WHERE subtype = 3030) c
                            WHERE a.dataid = b.dataid
                              AND b.ownerid = c.ownerid
                              AND a.protocol_number = p_protocol_number
                              AND a.rec_type != 'DELETE'
                            UNION
                            SELECT c.dataid
                              FROM (SELECT a.dataid, b.dataid AS dtree_dataid
                                      FROM EXP_DOCUMENT_EXPORT a, ETMF.DTREE b
                                     WHERE a.dataid = b.dataid(+)
                                       AND a.protocol_number = p_protocol_number
                                       AND a.rec_type != 'DELETE') c
                             WHERE c.dtree_dataid IS NULL );  

        v_rec_count := SQL%ROWCOUNT; 

        IF SQL%ROWCOUNT > 0 THEN  v_status := 'UPDATED'; END IF;
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('5. exp_run_study: DOCUMENT_DELETED complete. rec_count: '|| to_char(v_rec_count) || ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
        v_rec_count := 0;

        DBMS_OUTPUT.PUT_LINE('6. exp_run_study: DELETE NOT_TMF_DOCUMENT update'|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
        UPDATE EXP_DOCUMENT_EXPORT e1
           SET REC_TYPE = 'DELETE',
               EXPORT_REASON = 'NOT_TMF_DOCUMENT',
               EXPORTID = NVL2(wingspan_id, p_jobid, 0),
               LAST_UPD_DT = SYSDATE
         WHERE e1.dataid in ( SELECT a.dataid
                                FROM EXP_DOCUMENT_EXPORT a,
                                     ETMF.EEL_CAT_DOC_DATA_MV b
                               WHERE a.dataid = b.dataid
                                 AND a.protocol_number = p_protocol_number
                                 AND b.IS_TMF = 'NO'
                                 AND a.rec_type != 'DELETE' );     

        v_rec_count := SQL%ROWCOUNT; 
        IF SQL%ROWCOUNT > 0 THEN  v_status := 'UPDATED'; END IF;
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('6. exp_run_study: DELETE NOT_TMF_DOCUMENT complete. rec_count: '|| to_char(v_rec_count) || ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
        v_rec_count := 0;

        -- Update to set delete for documents which are moved out of project and not in a WorkFlow
        DBMS_OUTPUT.PUT_LINE('7. exp_run_study: DELETE DOCUMENT_MOVED_OUT_OF_PROJECT update'|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));        
        UPDATE EXP_DOCUMENT_EXPORT e1
           SET REC_TYPE = 'DELETE',
               EXPORT_REASON = 'DOCUMENT_MOVED_OUT_OF_PROJECT',
               EXPORTID = NVL2(wingspan_id, p_jobid, 0),
               LAST_UPD_DT = SYSDATE
         WHERE e1.dataid in ( SELECT a.dataid
                                FROM EXP_DOCUMENT_EXPORT a,
                                     ETMF.DTREE b,
                                     (SELECT ownerid FROM ETMF.dtree WHERE subtype = 161) wf
                               WHERE a.dataid = b.dataid
                                 AND a.project_dataid != b.ownerid
                                 AND b.ownerid != wf.ownerid
                                 AND a.protocol_number = p_protocol_number
                                 AND a.rec_type != 'DELETE' );     

        v_rec_count := SQL%ROWCOUNT; 
        IF SQL%ROWCOUNT > 0 THEN  v_status := 'UPDATED'; END IF;
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('7. exp_run_study: DELETE DOCUMENT_MOVED_OUT_OF_PROJECT complete. rec_count: '|| to_char(v_rec_count) || ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
        v_rec_count := 0;

        -- Add New Records : updated to do in 3 sections, core country site
        DBMS_OUTPUT.PUT_LINE('8. exp_run_study: Insert CORE documents'|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS')); 
        BEGIN 
           INSERT INTO tmf_health.exp_document_export ( DATAID, SPONSOR, PROTOCOL_NUMBER, 
               PROJECT_CODE, COUNTRY, COUNTRY_CODE, SITE_ID, SITE_NAME, INVESTIGATOR_NAME, 
               CLASS, ZONE, SECTION, ARTIFACT, DIA_KEY, DOC_ABBREVIATION, IS_UNBLINDED, 
               DOC_FULL_NAME, DOC_DATE, CREATEDATE, DOCUMENTLANGUAGE, LANGUAGEABBREVIATION, 
               LANGUAGEIDENTIFIER, FIRST_NAME, LAST_NAME, ORGANIZATION_ID, DRUG_TYPE, 
               VISIT_TYPE, VISIT_DOC_ID, REPORT_VERSION, EVENTIDENTIFIER, URL, REC_TYPE, 
               LAST_UPD_DT, PARENTID, PROJECT_DATAID, EXPORTID, EXPORT_REASON )
              ( SELECT a.DATAID DATAID,
                       a.CUSTOMER Sponsor,
                       a.PROTOCOL_NUMBER,
                       a.project_code,
                       a.country,
                       a.country_code,
                       a.site_id,
                       a.site_name,
                       a.investigator_name,
                       e.doc_class class,
                       e.doc_zone zone,
                       e.doc_section section,
                       e.doc_artifact artifact,
                       e.dia_key,
                       trim(BOTH ' ' FROM e.doc_abbreviation) as doc_abbreviation,
                       e.is_unblinded,
                       e.doc_full_name,
                       CASE
                          WHEN e.DOC_DATE IS NULL
                           AND e.SUBTYPE = 749
                          THEN
                             (SELECT TRUNC (NVL (NVL (o.OTEMAILSENTDATE, o.OTEMAILRECEIVEDDATE), dt.createdate))
                                FROM ETMF.OTEMAILPROPERTIES o, ETMF.DTREE DT
                               WHERE o.nodeid(+) = dt.dataid
                                 AND dt.dataid = e.DATAID)
                          WHEN e.DOC_DATE IS NULL
                          THEN
                             TRUNC (b.createdate)
                          ELSE
                             e.DOC_DATE
                       END AS "DOC_DATE",
                       b.createdate,
                       CASE
                        WHEN e.doc_lang IS NULL AND e.lang_abbreviation IS NULL
                            THEN NULL
                        ELSE
                            LANG_LOOKUP(a.dataid, 1) 
                       END AS "NEW_LANG", 
                       CASE
                        WHEN e.doc_lang IS NULL AND e.lang_abbreviation IS NULL
                            THEN NULL
                       ELSE
                           LANG_LOOKUP(a.dataid, 0) 
                       END as "NEW_ABBREV",
                       E.LANG_ID "LANGUAGEIDENTIFIER",
                       ELVIS_REF.ASCII_REPLACE(ELVIS_REF.NAME_INIT(E.FIRST_NAME)),
                       ELVIS_REF.ASCII_REPLACE(ELVIS_REF.NAME_INIT(E.LAST_NAME)),
                       E.ORGANIZATION_ID,
                       E.DRUG_TYPE,
                       E.VISIT_TYPE,
                       E.VISIT_DOC_ID,
                       E.REPORT_VERSION,
                       E.EVENT_ID "EVENTIDENTIFIER",
                       v_q_url || E.DATAID URL,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        --hardcoded string to be replaced by value from config table
                       'UPLOAD',
                       v_run_dt,
                       b.parentid,
                       b.ownerid,
                       p_jobid as EXPORTID,
                       'NEW_DOCUMENT'
                  FROM ETMF.EEL_PROJECT_DATA_MV a,
                       ETMF.DTREE b,
                       ETMF.EEL_CAT_DOC_DATA_MV e,
                       (SELECT ownerid
                          FROM ETMF.dtree
                         WHERE subtype = 3030) rec
                 WHERE a.dataid = b.dataid
                   AND a.dataid NOT IN (SELECT ede.dataid
                                          FROM exp_document_export ede
                                         WHERE ede.sponsor = p_sponsor
                                           AND ede.protocol_number = p_protocol_number)
                   AND a.customer = p_sponsor
                   AND a.protocol_number = p_protocol_number
                   AND E.date_id <> 'LLF'
                   AND b.ownerid != rec.ownerid
                   AND a.dataid = e.dataid
                   AND E.IS_TMF = 'YES'
                   AND a.subtype IN (144, 749)
                   AND e.doc_class = 'Core' );

          v_rec_count := SQL%ROWCOUNT;
          IF SQL%ROWCOUNT > 0 THEN  v_status := 'UPDATED'; END IF;
          COMMIT;
       EXCEPTION WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20008, 'ERROR INSERT Core Documents: '||SQLERRM,FALSE);
       END;
       DBMS_OUTPUT.PUT_LINE('8. exp_run_study: Insert CORE documents complete. rec_count: '|| to_char(v_rec_count) || ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS')); 
       v_rec_count := 0;

      -- filtered country records
      DBMS_OUTPUT.PUT_LINE('9. exp_run_study: Insert COUNTRY documents'|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS')); 
      BEGIN
          INSERT INTO tmf_health.exp_document_export ( DATAID, SPONSOR, PROTOCOL_NUMBER, 
               PROJECT_CODE, COUNTRY, COUNTRY_CODE, SITE_ID, SITE_NAME, INVESTIGATOR_NAME, 
               CLASS, ZONE, SECTION, ARTIFACT, DIA_KEY, DOC_ABBREVIATION, IS_UNBLINDED, 
               DOC_FULL_NAME, DOC_DATE, CREATEDATE, DOCUMENTLANGUAGE, LANGUAGEABBREVIATION, 
               LANGUAGEIDENTIFIER, FIRST_NAME, LAST_NAME, ORGANIZATION_ID, DRUG_TYPE, 
               VISIT_TYPE, VISIT_DOC_ID, REPORT_VERSION, EVENTIDENTIFIER, URL, REC_TYPE, 
               LAST_UPD_DT, PARENTID, PROJECT_DATAID, EXPORTID, EXPORT_REASON )
              ( SELECT a.DATAID DATAID,
                       a.CUSTOMER Sponsor,
                       a.PROTOCOL_NUMBER,
                       a.project_code,
                       a.country,
                       a.country_code,
                       a.site_id,
                       a.site_name,
                       a.investigator_name,
                       e.doc_class class,
                       e.doc_zone zone,
                       e.doc_section section,
                       e.doc_artifact artifact,
                       e.dia_key,
                       trim(BOTH ' ' FROM e.doc_abbreviation) as doc_abbreviation,
                       e.is_unblinded,
                       e.doc_full_name,
                       CASE
                          WHEN e.DOC_DATE IS NULL
                           AND e.SUBTYPE = 749
                          THEN
                             (SELECT TRUNC (NVL (NVL (o.OTEMAILSENTDATE, o.OTEMAILRECEIVEDDATE), dt.createdate))
                                FROM ETMF.OTEMAILPROPERTIES o, ETMF.DTREE DT
                               WHERE o.nodeid(+) = dt.dataid
                                 AND dt.dataid = e.DATAID)
                          WHEN e.DOC_DATE IS NULL
                          THEN
                             TRUNC (b.createdate)
                          ELSE
                             e.DOC_DATE
                       END AS "DOC_DATE",
                       b.createdate,
                       CASE
                        WHEN e.doc_lang IS NULL AND e.lang_abbreviation IS NULL
                            THEN NULL
                        ELSE
                            LANG_LOOKUP(a.dataid, 1) 
                       END AS "NEW_LANG", 
                       CASE
                        WHEN e.doc_lang IS NULL AND e.lang_abbreviation IS NULL
                            THEN NULL
                       ELSE
                           LANG_LOOKUP(a.dataid, 0) 
                       END as "NEW_ABBREV",
                       E.LANG_ID "LANGUAGEIDENTIFIER",
                       ELVIS_REF.ASCII_REPLACE(ELVIS_REF.NAME_INIT(E.FIRST_NAME)),
                       ELVIS_REF.ASCII_REPLACE(ELVIS_REF.NAME_INIT(E.LAST_NAME)),
                       E.ORGANIZATION_ID,
                       E.DRUG_TYPE,
                       E.VISIT_TYPE,
                       E.VISIT_DOC_ID,
                       E.REPORT_VERSION,
                       E.EVENT_ID "EVENTIDENTIFIER",
                       v_q_url || E.DATAID URL,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        --hardcoded string to be replaced by value from config table
                       'UPLOAD',
                       v_run_dt,
                       b.parentid,
                       b.ownerid,
                       p_jobid as EXPORTID,
                       'NEW_DOCUMENT'
                  FROM ETMF.EEL_PROJECT_DATA_MV a,
                       ETMF.DTREE b,
                       ETMF.EEL_CAT_DOC_DATA_MV e,
                       (SELECT ownerid
                          FROM ETMF.dtree
                         WHERE subtype = 3030) rec,
                       (select a.protocol_number, a.site_country_name as country_name
                          from elvis_ref.site a,
                               eel3.e3_configuration b,
                               exp_study_list c
                         where a.protocol_number = c.protocol_number
                           and a.site_status = b.cfg_value
                           and b.cfg_name = 'health.upload.site.status_to_transmit'
                           and a.site_number not like 'TBD-%'
                         group by a.protocol_number, a.site_country_name ) crec
                 WHERE a.dataid = b.dataid
                   AND a.dataid NOT IN (SELECT ede.dataid
                                          FROM exp_document_export ede
                                         WHERE ede.sponsor = p_sponsor
                                           AND ede.protocol_number = p_protocol_number)
                   AND a.customer = p_sponsor
                   AND a.protocol_number = p_protocol_number
                   AND E.date_id <> 'LLF'
                   AND b.ownerid != rec.ownerid
                   AND a.dataid = e.dataid
                   AND E.IS_TMF = 'YES'
                   AND a.subtype IN (144, 749)
                   AND e.doc_class = 'Country'
                   AND a.country = crec.country_name
                   and a.protocol_number = crec.protocol_number );

          v_rec_count := SQL%ROWCOUNT;  
          IF SQL%ROWCOUNT > 0 THEN  v_status := 'UPDATED'; END IF;
          COMMIT;
      EXCEPTION WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20009, 'ERROR INSERT Country Documents: '||SQLERRM,FALSE);
      END;
      DBMS_OUTPUT.PUT_LINE('9. exp_run_study: Insert COUNTRY documents complete. rec_count: '|| to_char(v_rec_count) || ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
      v_rec_count := 0;

      -- filtered site records
      DBMS_OUTPUT.PUT_LINE('10. exp_run_study: Insert SITE documents'|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS')); 
      BEGIN
          INSERT INTO tmf_health.exp_document_export ( DATAID, SPONSOR, PROTOCOL_NUMBER, 
               PROJECT_CODE, COUNTRY, COUNTRY_CODE, SITE_ID, SITE_NAME, INVESTIGATOR_NAME, 
               CLASS, ZONE, SECTION, ARTIFACT, DIA_KEY, DOC_ABBREVIATION, IS_UNBLINDED, 
               DOC_FULL_NAME, DOC_DATE, CREATEDATE, DOCUMENTLANGUAGE, LANGUAGEABBREVIATION, 
               LANGUAGEIDENTIFIER, FIRST_NAME, LAST_NAME, ORGANIZATION_ID, DRUG_TYPE, 
               VISIT_TYPE, VISIT_DOC_ID, REPORT_VERSION, EVENTIDENTIFIER, URL, REC_TYPE, 
               LAST_UPD_DT, PARENTID, PROJECT_DATAID, EXPORTID, EXPORT_REASON )
              ( SELECT a.DATAID DATAID,
                       a.CUSTOMER Sponsor,
                       a.PROTOCOL_NUMBER,
                       a.project_code,
                       a.country,
                       a.country_code,
                       a.site_id,
                       a.site_name,
                       CASE 
                        WHEN a.SITE_ID IS NOT NULL
                            THEN PI_LOOKUP(a.protocol_number, a.site_id)    
                        ELSE
                            NULL
                       END as "INVESTIGATOR_NAME",
                       e.doc_class class,
                       e.doc_zone zone,
                       e.doc_section section,
                       e.doc_artifact artifact,
                       e.dia_key,
                       trim(BOTH ' ' FROM e.doc_abbreviation) as doc_abbreviation,
                       e.is_unblinded,
                       e.doc_full_name,
                       CASE
                          WHEN e.DOC_DATE IS NULL
                           AND e.SUBTYPE = 749
                          THEN
                             (SELECT TRUNC (NVL (NVL (o.OTEMAILSENTDATE, o.OTEMAILRECEIVEDDATE), dt.createdate))
                                FROM ETMF.OTEMAILPROPERTIES o, ETMF.DTREE DT
                               WHERE o.nodeid(+) = dt.dataid
                                 AND dt.dataid = e.DATAID)
                          WHEN e.DOC_DATE IS NULL
                          THEN
                             TRUNC (b.createdate)
                          ELSE
                             e.DOC_DATE
                       END AS "DOC_DATE",
                       b.createdate,
                       CASE
                        WHEN e.doc_lang IS NULL AND e.lang_abbreviation IS NULL
                            THEN NULL
                        ELSE
                            LANG_LOOKUP(a.dataid, 1) 
                       END AS "NEW_LANG", 
                       CASE
                        WHEN e.doc_lang IS NULL AND e.lang_abbreviation IS NULL
                            THEN NULL
                       ELSE
                           LANG_LOOKUP(a.dataid, 0) 
                       END as "NEW_ABBREV",
                       E.LANG_ID "LANGUAGEIDENTIFIER",
                       ELVIS_REF.ASCII_REPLACE(ELVIS_REF.NAME_INIT(E.FIRST_NAME)),
                       ELVIS_REF.ASCII_REPLACE(ELVIS_REF.NAME_INIT(E.LAST_NAME)),
                       E.ORGANIZATION_ID,
                       E.DRUG_TYPE,
                       E.VISIT_TYPE,
                       E.VISIT_DOC_ID,
                       E.REPORT_VERSION,
                       E.EVENT_ID "EVENTIDENTIFIER",
                       v_q_url || E.DATAID URL,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        --hardcoded string to be replaced by value from config table
                       'UPLOAD',
                       v_run_dt,
                       b.parentid,
                       b.ownerid,
                       p_jobid as EXPORTID,
                       'NEW_DOCUMENT'
                  FROM ETMF.EEL_PROJECT_DATA_MV a,
                       ETMF.DTREE b,
                       ETMF.EEL_CAT_DOC_DATA_MV e,
                       (SELECT ownerid
                          FROM ETMF.dtree
                         WHERE subtype = 3030) rec,
                       (select a.protocol_number, a.site_country_name as country_name, a.site_number, a.site_status
                          from elvis_ref.site a,
                               eel3.e3_configuration b,
                               exp_study_list c
                         where A.PROTOCOL_NUMBER = c.protocol_number
                           and a.site_status = b.cfg_value
                           and b.cfg_name = 'health.upload.site.status_to_transmit'
                           and a.site_number not like 'TBD-%' ) srec
                 WHERE a.dataid = b.dataid
                   AND a.dataid NOT IN (SELECT ede.dataid
                                          FROM exp_document_export ede
                                         WHERE ede.sponsor = p_sponsor
                                           AND ede.protocol_number = p_protocol_number)
                   AND a.customer = p_sponsor
                   AND a.protocol_number = p_protocol_number
                   AND E.date_id <> 'LLF'
                   AND b.ownerid != rec.ownerid
                   AND a.dataid = e.dataid
                   AND E.IS_TMF = 'YES'
                   AND a.subtype IN (144, 749)
                   AND e.doc_class = 'Site'
                   and a.protocol_number = srec.protocol_number
                   AND a.country = srec.country_name
                   and a.site_id = srec.site_number );

          v_rec_count := SQL%ROWCOUNT;
          IF SQL%ROWCOUNT > 0 THEN  v_status := 'UPDATED'; END IF;
          COMMIT;
      EXCEPTION WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20010, 'ERROR INSERT Site Documents: '||SQLERRM,FALSE);
      END;
      DBMS_OUTPUT.PUT_LINE('10. exp_run_study: Insert SITE documents complete. rec_count: '|| to_char(v_rec_count) || ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS')); 
      v_rec_count := 0;

      -- update the export id for all records where the exportid is out of sync and the wingspan id is null
      DBMS_OUTPUT.PUT_LINE('11. exp_run_study: Set JOB ID for previous docs with NULL WS ID'|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS')); 
      UPDATE tmf_health.exp_document_export
         SET exportid = p_jobid
       WHERE protocol_number = p_protocol_number
         AND NVL(exportid,-1) != p_jobid
         AND wingspan_id is null
         AND REC_TYPE <> 'DELETE';

      v_rec_count := SQL%ROWCOUNT;
      IF SQL%ROWCOUNT > 0 THEN v_status := 'UPDATED'; END IF;
      COMMIT;
      DBMS_OUTPUT.PUT_LINE('11. exp_run_study: Set JOB ID for previous docs with NULL WS ID complete. rec_count: '|| to_char(v_rec_count) || ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS')); 
      v_rec_count := 0;

      -- update the -export id for all/updates deletes for previous failed job
      DBMS_OUTPUT.PUT_LINE('12. exp_run_study: Set JOB ID for previous error docs with WS ID'|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));       
      IF v_last_status = 'ERROR' THEN
        UPDATE tmf_health.exp_document_export
           SET exportid = p_jobid
         WHERE protocol_number = p_protocol_number
           AND exportid = v_last_jobid;

        v_rec_count := SQL%ROWCOUNT;
        IF SQL%ROWCOUNT > 0 THEN v_status := 'UPDATED'; END IF;
        COMMIT;
      END IF;
      DBMS_OUTPUT.PUT_LINE('12. exp_run_study: Set JOB ID for previous error docs with WS ID complete. rec_count: '|| to_char(v_rec_count) || ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
      v_rec_count := 0;

      -- update any previous failed/incomplete jobs
      DBMS_OUTPUT.PUT_LINE('13. exp_run_study: Set JOB ID for previous process/incomplete errors '|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));       
      UPDATE tmf_health.exp_document_export
         SET exportid = p_jobid
       WHERE protocol_number = p_protocol_number
         AND NVL(ERROR_GROUP, 'NOTOK') <> 'OK';

       v_rec_count := SQL%ROWCOUNT;
      IF SQL%ROWCOUNT > 0 THEN v_status := 'UPDATED'; END IF;
      COMMIT;
      DBMS_OUTPUT.PUT_LINE('13. exp_run_study: Set JOB ID for previous process/incomplete errors. rec_count: '|| to_char(v_rec_count) || ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
      v_rec_count := 0;    

      -- Set Status, default = NO_UPDATES
      DBMS_OUTPUT.PUT_LINE('14. exp_run_study: update Status'|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS')); 
      UPDATE tmf_health.exp_study_list
         SET curr_status = v_status,
             last_update = v_run_dt
       WHERE sponsor = p_sponsor
         AND protocol_number = p_protocol_number;

       -- Update to set delete for documents from dropped sites
        DBMS_OUTPUT.PUT_LINE('15. exp_run_study: DELETE DOCUMENT_DROPPED_SITE update'|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));

        UPDATE EXP_DOCUMENT_EXPORT e1
           SET REC_TYPE = 'DELETE',
               EXPORT_REASON = 'DROPPED_SITE',
      --         EXPORTID = NVL2(wingspan_id, p_jobid, 0),
               LAST_UPD_DT = SYSDATE
         WHERE e1.dataid in ( 
         						SELECT a.dataid
                                  FROM EXP_DOCUMENT_EXPORT a
                                  JOIN ELVIS_REF.SITE s
                                    on A.PROTOCOL_NUMBER = S.PROTOCOL_NUMBER
                                   and A.PROJECT_CODE = S.PROJECT_CODE
                                   and A.SITE_ID = S.SITE_NUMBER
                                   and S.SITE_STATUS = 'Dropped'
                                 WHERE 1=1
                                   AND a.protocol_number = p_protocol_number
                                   AND a.rec_type != 'DELETE'
                                   and a.site_id is not null
                         );

        v_rec_count := SQL%ROWCOUNT; 
        IF SQL%ROWCOUNT > 0 THEN  v_status := 'UPDATED'; END IF;
      COMMIT;     
        DBMS_OUTPUT.PUT_LINE('15. exp_run_study: DELETE DOCUMENT_DROPPED_SITE complete. rec_count: '|| to_char(v_rec_count) || ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));

        v_rec_count := 0;

        COMMIT;

      DBMS_OUTPUT.PUT_LINE('16. exp_run_study: complete for protocol: '||p_protocol_number|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
    END IF;

  ELSE
    -- new sponsor/protocol number
    DBMS_OUTPUT.PUT_LINE('1. exp_run_study start: New protocol: '||p_protocol_number|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
    SELECT REGEXP_REPLACE(p_protocol_number, '[^a-zA-Z0-9]+', '')
      INTO v_protnum_std
      FROM dual;

    DBMS_OUTPUT.PUT_LINE('2. exp_run_study : add study record.'|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
    INSERT INTO tmf_health.exp_study_list (SPONSOR, PROTOCOL_NUMBER, PROTOCOL_NUMBER_STND, CURR_STATUS, ALL_JOB_YN )
    VALUES (p_sponsor, p_protocol_number, v_protnum_std, 'STARTED', 'Y');

    COMMIT;

    -- filtered Core Docs
    DBMS_OUTPUT.PUT_LINE('3. exp_run_study: add CORE docs start. TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
    BEGIN
        INSERT INTO tmf_health.exp_document_export (DATAID, SPONSOR, PROTOCOL_NUMBER, 
            PROJECT_CODE, COUNTRY, COUNTRY_CODE, SITE_ID, SITE_NAME, INVESTIGATOR_NAME, 
            CLASS, ZONE, SECTION, ARTIFACT, DIA_KEY, DOC_ABBREVIATION, IS_UNBLINDED, 
            DOC_FULL_NAME, DOC_DATE, CREATEDATE, DOCUMENTLANGUAGE, LANGUAGEABBREVIATION, 
            LANGUAGEIDENTIFIER, FIRST_NAME, LAST_NAME, ORGANIZATION_ID, DRUG_TYPE, 
            VISIT_TYPE, VISIT_DOC_ID, REPORT_VERSION, EVENTIDENTIFIER, URL, REC_TYPE, 
            LAST_UPD_DT, PARENTID, PROJECT_DATAID, EXPORTID, EXPORT_REASON )
          ( SELECT a.DATAID DATAID,
                   a.CUSTOMER Sponsor,
                   a.PROTOCOL_NUMBER,
                   a.project_code,
                   a.country,
                   a.country_code,
                   a.site_id,
                   a.site_name,
                   a.investigator_name,
                   e.doc_class class,
                   e.doc_zone zone,
                   e.doc_section section,
                   e.doc_artifact artifact,
                   e.dia_key,
                   trim(BOTH ' ' FROM e.doc_abbreviation) as doc_abbreviation,
                   e.is_unblinded,
                   e.doc_full_name,
                   CASE
                      WHEN e.DOC_DATE IS NULL
                       AND e.SUBTYPE = 749
                      THEN
                         (SELECT TRUNC (NVL (NVL (o.OTEMAILSENTDATE, o.OTEMAILRECEIVEDDATE), dt.createdate))
                            FROM ETMF.OTEMAILPROPERTIES o, ETMF.DTREE DT
                           WHERE o.nodeid(+) = dt.dataid
                             AND dt.dataid = e.DATAID)
                      WHEN e.DOC_DATE IS NULL
                      THEN
                         TRUNC (b.createdate)
                      ELSE
                         e.DOC_DATE
                   END AS "DOC_DATE",
                   b.createdate,
                   CASE
                    WHEN e.doc_lang IS NULL AND e.lang_abbreviation IS NULL
                        THEN NULL
                    ELSE
                        LANG_LOOKUP(a.dataid, 1) 
                   END AS "NEW_LANG", 
                   CASE
                    WHEN e.doc_lang IS NULL AND e.lang_abbreviation IS NULL
                        THEN NULL
                   ELSE
                       LANG_LOOKUP(a.dataid, 0) 
                   END as "NEW_ABBREV",                   
                   E.LANG_ID "LANGUAGEIDENTIFIER",
                   ELVIS_REF.ASCII_REPLACE(ELVIS_REF.NAME_INIT(E.FIRST_NAME)),
                   ELVIS_REF.ASCII_REPLACE(ELVIS_REF.NAME_INIT(E.LAST_NAME)),
                   E.ORGANIZATION_ID,
                   E.DRUG_TYPE,
                   E.VISIT_TYPE,
                   E.VISIT_DOC_ID,
                   E.REPORT_VERSION,
                   E.EVENT_ID "EVENTIDENTIFIER",
                   v_q_url || E.DATAID URL,
                   'UPLOAD',
                   v_run_dt,
                   b.parentid,
                   b.ownerid,
                   p_jobid as EXPORTID,
                   'NEW_STUDY'
              FROM ETMF.EEL_PROJECT_DATA_MV a,
                   ETMF.DTREE b,
                   ETMF.EEL_CAT_DOC_DATA_MV e,
                   (SELECT ownerid
                      FROM ETMF.dtree
                     WHERE subtype = 3030) rec
             WHERE a.dataid = b.dataid
               AND a.customer = p_sponsor
               AND a.protocol_number = p_protocol_number
               AND E.date_id <> 'LLF'
               AND b.ownerid != rec.ownerid
               AND a.dataid = e.dataid
               AND e.doc_class = 'Core'
               AND E.IS_TMF = 'YES'
               AND a.subtype IN (144, 749) );

          v_rec_count := SQL%ROWCOUNT;
          IF SQL%ROWCOUNT > 0 THEN  v_status := 'UPDATED'; END IF;
          COMMIT;
      EXCEPTION WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20003, 'ERROR INSERT NEW-Study Core Documents: '||SQLERRM,FALSE);
      END;    
      DBMS_OUTPUT.PUT_LINE('3. exp_run_study: add CORE docs complete. rec_count: '|| to_char(v_rec_count) || ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
      v_rec_count := 0;

      -- filtered country records
      DBMS_OUTPUT.PUT_LINE('4. exp_run_study: add COUNTRY docs start. TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));   
      BEGIN   
          INSERT INTO tmf_health.exp_document_export ( DATAID, SPONSOR, PROTOCOL_NUMBER, 
               PROJECT_CODE, COUNTRY, COUNTRY_CODE, SITE_ID, SITE_NAME, INVESTIGATOR_NAME, 
               CLASS, ZONE, SECTION, ARTIFACT, DIA_KEY, DOC_ABBREVIATION, IS_UNBLINDED, 
               DOC_FULL_NAME, DOC_DATE, CREATEDATE, DOCUMENTLANGUAGE, LANGUAGEABBREVIATION, 
               LANGUAGEIDENTIFIER, FIRST_NAME, LAST_NAME, ORGANIZATION_ID, DRUG_TYPE, 
               VISIT_TYPE, VISIT_DOC_ID, REPORT_VERSION, EVENTIDENTIFIER, URL, REC_TYPE, 
               LAST_UPD_DT, PARENTID, PROJECT_DATAID, EXPORTID, EXPORT_REASON )
              ( SELECT a.DATAID DATAID,
                       a.CUSTOMER Sponsor,
                       a.PROTOCOL_NUMBER,
                       a.project_code,
                       a.country,
                       a.country_code,
                       a.site_id,
                       a.site_name,
                       a.investigator_name,
                       e.doc_class class,
                       e.doc_zone zone,
                       e.doc_section section,
                       e.doc_artifact artifact,
                       e.dia_key,
                       trim(BOTH ' ' FROM e.doc_abbreviation) as doc_abbreviation,
                       e.is_unblinded,
                       e.doc_full_name,
                       CASE
                          WHEN e.DOC_DATE IS NULL
                           AND e.SUBTYPE = 749
                          THEN
                             (SELECT TRUNC (NVL (NVL (o.OTEMAILSENTDATE, o.OTEMAILRECEIVEDDATE), dt.createdate))
                                FROM ETMF.OTEMAILPROPERTIES o, ETMF.DTREE DT
                               WHERE o.nodeid(+) = dt.dataid
                                 AND dt.dataid = e.DATAID)
                          WHEN e.DOC_DATE IS NULL
                          THEN
                             TRUNC (b.createdate)
                          ELSE
                             e.DOC_DATE
                       END AS "DOC_DATE",
                       b.createdate,
                       CASE
                        WHEN e.doc_lang IS NULL AND e.lang_abbreviation IS NULL
                            THEN NULL
                        ELSE
                            LANG_LOOKUP(a.dataid, 1) 
                       END AS "NEW_LANG", 
                       CASE
                        WHEN e.doc_lang IS NULL AND e.lang_abbreviation IS NULL
                            THEN NULL
                       ELSE
                           LANG_LOOKUP(a.dataid, 0) 
                       END as "NEW_ABBREV",                          
                       E.LANG_ID "LANGUAGEIDENTIFIER",
                       ELVIS_REF.ASCII_REPLACE(ELVIS_REF.NAME_INIT(E.FIRST_NAME)),
                       ELVIS_REF.ASCII_REPLACE(ELVIS_REF.NAME_INIT(E.LAST_NAME)),
                       E.ORGANIZATION_ID,
                       E.DRUG_TYPE,
                       E.VISIT_TYPE,
                       E.VISIT_DOC_ID,
                       E.REPORT_VERSION,
                       E.EVENT_ID "EVENTIDENTIFIER",
                       v_q_url || E.DATAID URL,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        --hardcoded string to be replaced by value from config table
                       'UPLOAD',
                       v_run_dt,
                       b.parentid,
                       b.ownerid,
                       p_jobid as EXPORTID,
                       'NEW_DOCUMENT'
                  FROM ETMF.EEL_PROJECT_DATA_MV a,
                       ETMF.DTREE b,
                       ETMF.EEL_CAT_DOC_DATA_MV e,
                       (SELECT ownerid
                          FROM ETMF.dtree
                         WHERE subtype = 3030) rec,
                       (select a.protocol_number, a.site_country_name as country_name
                          from elvis_ref.site a,
                               eel3.e3_configuration b,
                               exp_study_list c
                         where a.protocol_number = c.protocol_number
                           and a.site_status = b.cfg_value
                           and b.cfg_name = 'health.upload.site.status_to_transmit'
                           and a.site_number not like 'TBD-%'
                         group by a.protocol_number, a.site_country_name ) crec
                 WHERE a.dataid = b.dataid
                   AND a.customer = p_sponsor
                   AND a.protocol_number = p_protocol_number
                   AND E.date_id <> 'LLF'
                   AND b.ownerid != rec.ownerid
                   AND a.dataid = e.dataid
                   AND E.IS_TMF = 'YES'
                   AND a.subtype IN (144, 749)
                   AND e.doc_class = 'Country'
                   and a.protocol_number = crec.protocol_number
                   AND a.country = crec.country_name );

          v_rec_count := SQL%ROWCOUNT;
          IF SQL%ROWCOUNT > 0 THEN  v_status := 'UPDATED'; END IF;
          COMMIT;
      EXCEPTION WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20004, 'ERROR INSERT NEW-Study Country Documents: '||SQLERRM,FALSE);
      END;          
      DBMS_OUTPUT.PUT_LINE('4. exp_run_study start: add COUNTRY docs complete. rec_count: '|| to_char(v_rec_count) || ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
      v_rec_count := 0;

      -- filtered site records
      DBMS_OUTPUT.PUT_LINE('5. exp_run_study: add SITE docs start. TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
      BEGIN
          INSERT INTO tmf_health.exp_document_export ( DATAID, SPONSOR, PROTOCOL_NUMBER, 
               PROJECT_CODE, COUNTRY, COUNTRY_CODE, SITE_ID, SITE_NAME, INVESTIGATOR_NAME, 
               CLASS, ZONE, SECTION, ARTIFACT, DIA_KEY, DOC_ABBREVIATION, IS_UNBLINDED, 
               DOC_FULL_NAME, DOC_DATE, CREATEDATE, DOCUMENTLANGUAGE, LANGUAGEABBREVIATION, 
               LANGUAGEIDENTIFIER, FIRST_NAME, LAST_NAME, ORGANIZATION_ID, DRUG_TYPE, 
               VISIT_TYPE, VISIT_DOC_ID, REPORT_VERSION, EVENTIDENTIFIER, URL, REC_TYPE, 
               LAST_UPD_DT, PARENTID, PROJECT_DATAID, EXPORTID, EXPORT_REASON )
              ( SELECT a.DATAID DATAID,
                       a.CUSTOMER Sponsor,
                       a.PROTOCOL_NUMBER,
                       a.project_code,
                       a.country,
                       a.country_code,
                       a.site_id,
                       a.site_name,
                       CASE 
                        WHEN a.SITE_ID IS NOT NULL
                            THEN PI_LOOKUP(a.protocol_number, a.site_id)    
                        ELSE
                            NULL
                       END as "INVESTIGATOR_NAME",
                       e.doc_class class,
                       e.doc_zone zone,
                       e.doc_section section,
                       e.doc_artifact artifact,
                       e.dia_key,
                       trim(BOTH ' ' FROM e.doc_abbreviation) as doc_abbreviation,
                       e.is_unblinded,
                       e.doc_full_name,
                       CASE
                          WHEN e.DOC_DATE IS NULL
                           AND e.SUBTYPE = 749
                          THEN
                             (SELECT TRUNC (NVL (NVL (o.OTEMAILSENTDATE, o.OTEMAILRECEIVEDDATE), dt.createdate))
                                FROM ETMF.OTEMAILPROPERTIES o, ETMF.DTREE DT
                               WHERE o.nodeid(+) = dt.dataid
                                 AND dt.dataid = e.DATAID)
                          WHEN e.DOC_DATE IS NULL
                          THEN
                             TRUNC (b.createdate)
                          ELSE
                             e.DOC_DATE
                       END AS "DOC_DATE",
                       b.createdate,
                       CASE
                        WHEN e.doc_lang IS NULL AND e.lang_abbreviation IS NULL
                            THEN NULL
                        ELSE
                            LANG_LOOKUP(a.dataid, 1) 
                       END AS "NEW_LANG", 
                       CASE
                        WHEN e.doc_lang IS NULL AND e.lang_abbreviation IS NULL
                            THEN NULL
                       ELSE
                           LANG_LOOKUP(a.dataid, 0) 
                       END as "NEW_ABBREV",   
                       E.LANG_ID "LANGUAGEIDENTIFIER",
                       ELVIS_REF.ASCII_REPLACE(ELVIS_REF.NAME_INIT(E.FIRST_NAME)),
                       ELVIS_REF.ASCII_REPLACE(ELVIS_REF.NAME_INIT(E.LAST_NAME)),
                       E.ORGANIZATION_ID,
                       E.DRUG_TYPE,
                       E.VISIT_TYPE,
                       E.VISIT_DOC_ID,
                       E.REPORT_VERSION,
                       E.EVENT_ID "EVENTIDENTIFIER",
                       v_q_url || E.DATAID URL,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        --hardcoded string to be replaced by value from config table
                       'UPLOAD',
                       v_run_dt,
                       b.parentid,
                       b.ownerid,
                       p_jobid as EXPORTID,
                       'NEW_DOCUMENT'
                  FROM ETMF.EEL_PROJECT_DATA_MV a,
                       ETMF.DTREE b,
                       ETMF.EEL_CAT_DOC_DATA_MV e,
                       (SELECT ownerid
                          FROM ETMF.dtree
                         WHERE subtype = 3030) rec,
                       (select a.protocol_number, a.site_country_name as country_name, a.site_number, a.site_status
                          from elvis_ref.site a,
                               eel3.e3_configuration b,
                               exp_study_list c
                         where A.PROTOCOL_NUMBER = c.protocol_number
                           and a.site_status = b.cfg_value
                           and b.cfg_name = 'health.upload.site.status_to_transmit'
                           and a.site_number not like 'TBD-%' ) srec
                 WHERE a.dataid = b.dataid
                   AND a.customer = p_sponsor
                   AND a.protocol_number = p_protocol_number
                   AND E.date_id <> 'LLF'
                   AND b.ownerid != rec.ownerid
                   AND a.dataid = e.dataid
                   AND E.IS_TMF = 'YES'
                   AND a.subtype IN (144, 749)
                   AND e.doc_class = 'Site'
                   and a.protocol_number = srec.protocol_number
                   AND a.country = srec.country_name
                   and a.site_id = srec.site_number );

          v_rec_count := SQL%ROWCOUNT;
          IF SQL%ROWCOUNT > 0 THEN  v_status := 'UPDATED'; END IF;
          COMMIT;
      EXCEPTION WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20005, 'ERROR INSERT NEW-Study Site Documents: '||SQLERRM,FALSE);
      END;
      DBMS_OUTPUT.PUT_LINE('5. exp_run_study: add SITE docs complete. rec_count: '|| to_char(v_rec_count) || 'TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));    

      DBMS_OUTPUT.PUT_LINE('6. exp_run_study: update Status'|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));     
      UPDATE tmf_health.exp_study_list
         SET curr_status = v_status,
             last_update = v_run_dt
       WHERE sponsor = p_sponsor
         AND protocol_number = p_protocol_number;

      COMMIT;
      DBMS_OUTPUT.PUT_LINE('7. exp_run_study: complete for protocol: '||p_protocol_number|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));    
  END IF;

END EXP_RUN_STUDY;



PROCEDURE  exp_spool_study ( 
p_sponsor IN VARCHAR2,
p_protocol_number IN VARCHAR2,
p_run_dt IN DATE,
p_jobid IN NUMBER
)
AS
  -- cursor updated to use JOB ID as primary selection criteria
  -- Sort the output file, DELETES, UPDATES, UPLOADS so records can be managed in one process round
  CURSOR c_data IS
      SELECT dataid,
             sponsor,
             protocol_number,
             project_code,
             country,
             country_code,
             site_id,
             site_name,
             investigator_name,
             class,
             zone,
             section,
             artifact,
             dia_key,
             doc_abbreviation,
             is_unblinded,
             doc_full_name,
             TO_CHAR(doc_date,'YYYY-MM-DD HH24:MI:SS') doc_date,
             TO_CHAR(createdate,'YYYY-MM-DD HH24:MI:SS') createdate,
             documentlanguage,
             languageabbreviation,
             languageidentifier,
             first_name,
             last_name,
             organization_id,
             drug_type,
             visit_type,
             visit_doc_id,
             report_version,
             eventidentifier,
             url,
             rec_type,
             wingspan_id,
             exportid
        FROM tmf_health.exp_document_export a
       WHERE a.sponsor = p_sponsor
         AND a.protocol_number = p_protocol_number
         AND a.exportid = p_jobid
       ORDER BY DECODE(rec_type, 'DELETE', 0, 'UPDATE', 1, 'UPLOAD', 2, 3), decode(CLASS,'Core',1,'Country',2,3), COUNTRY, SITE_ID;

  v_env_type        varchar2(100);
  v_cnt_chk         number := 0;
  v_status          varchar2(25);
  v_protnum_std     varchar2(255 char);
  v_file_line       varchar2(4000);
  v_fname           varchar2(200);
  v_run_dt          date default sysdate;
  v_proc_type       varchar2(100);
  v_exp_language    varchar2(255);
  v_lang_sql        varchar2(2000);
  v_file_ext        varchar2(10) := 'csv';
  v_rec_count       number := 0;
  v_reject_count    number := 0;
  v_rs              varchar2(1);
  v_rs2             varchar2(3);

BEGIN

  IF p_run_dt is not null THEN
     v_run_dt := p_run_dt;
  END IF;

  DBMS_OUTPUT.PUT_LINE('1. exp_spool_study: Start for protocol: '||p_protocol_number|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
  select count(1)
    into v_cnt_chk
    from tmf_health.exp_document_export a
   where a.sponsor = p_sponsor
     and a.protocol_number = p_protocol_number
      AND a.exportid = p_jobid;

  IF v_cnt_chk > 0 THEN
      --docs to spool

      -- set language query:
      v_lang_sql := 'SELECT MAX (z.new_lang) as language '||
                    '  FROM (SELECT NVL (b.language_name, DECODE (LOWER (:1), ''eng'', ''English'', :2)) AS new_lang '||
                    '          FROM etmf.cflanguagestbl b '||
                    '         WHERE LOWER (:3) = LOWER (b.language_code) '||
                    '        UNION '||
                    '        SELECT :4 AS new_lang '||
                    '          FROM DUAL '||
                    '         WHERE NOT EXISTS '||
                    '                  (SELECT b.language_name, DECODE (LOWER (:5), ''eng'', ''English'', :6) AS new_lang '||
                    '                     FROM etmf.cflanguagestbl b '||
                    '                    WHERE LOWER (:7) = LOWER (b.language_code))) z ';

      -- add check for Initate to add new file extension
      select decode(cloud_mode,'V','validate','process'), decode(cloud_mode,'I','csvi','csv') 
        into v_proc_type, v_file_ext
        from ELVIS_REF.TMF_STUDY_ENV_LOOKUP_V
       where TMF_HEALTH_ENV = 1
         and customer = p_sponsor
         and protocol_number = p_protocol_number;

      select var_value
        into v_env_type
        from tmf_health.exp_job_config
       where var_name='ENV_TYPE'; 

      select protocol_number_stnd
        into v_protnum_std
        from tmf_health.exp_study_list a
       where a.sponsor = p_sponsor
         and a.protocol_number = p_protocol_number;

      -- use file extension CSVI to avoid being picked up by processor 
      v_fname:= p_sponsor||'_'||v_protnum_std||'_'||to_char(v_run_dt,'YYYY-MM-DD-HH24-MI')||'.'||v_env_type||'.'||v_proc_type||'.'||v_file_ext;

      DBMS_OUTPUT.PUT_LINE('2. exp_spool_study: creating file: '||v_fname|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));

	-- v2.0 add New columns : documentId => Wingspan id  Disposition => values are case sensitive UPDATE, UPLOAD, DELETE
	v_file_line := '"DATAID","Sponsor","Protocol Number","Project Code","Country","Country Code","Site ID'||
		'","Site Name","Investigator Name","Class","Zone","Section","Artifact","Dia Key","Abbreviation'||
		'","Unblinded","Document Name","Document Date","Create Date","Document Language'||
		'","Language Abbreviation","Language Identifier","First Name","Last Name","Organization ID'||
		'","Drug Type","Visit Type","Visit Document ID","Report Version","Event Identifier","URL","Disposition","documentId"';

    -- v3.0 start the DB spool 
	INSERT into exp_stg_export
		(jobid, file_name, line_order, dataid, file_line)
	VALUES
		(p_jobid, v_fname, 0, 0, v_file_line);

      FOR cur_rec IN c_data LOOP
        -- Add Language update
        IF cur_rec.DOCUMENTLANGUAGE is null and cur_rec.LANGUAGEABBREVIATION is null THEN
            v_exp_language := NULL;
        ELSE
            v_exp_language := cur_rec.DOCUMENTLANGUAGE;
            BEGIN
                IF cur_rec.DOCUMENTLANGUAGE is null THEN
                   EXECUTE IMMEDIATE v_lang_sql INTO v_exp_language USING cur_rec.LANGUAGEABBREVIATION, cur_rec.LANGUAGEABBREVIATION,
                     cur_rec.LANGUAGEABBREVIATION, cur_rec.LANGUAGEABBREVIATION, cur_rec.LANGUAGEABBREVIATION, cur_rec.LANGUAGEABBREVIATION, cur_rec.LANGUAGEABBREVIATION;
                ELSE
                    EXECUTE IMMEDIATE v_lang_sql INTO v_exp_language USING cur_rec.DOCUMENTLANGUAGE,cur_rec.DOCUMENTLANGUAGE,
                        cur_rec.DOCUMENTLANGUAGE, cur_rec.DOCUMENTLANGUAGE, cur_rec.DOCUMENTLANGUAGE, cur_rec.DOCUMENTLANGUAGE, cur_rec.DOCUMENTLANGUAGE;
                END IF;
            EXCEPTION WHEN OTHERS THEN
                -- note the sql ERROR
                DBMS_OUTPUT.PUT_LINE('ERROR retreiving updated language for dataid: '||to_char(cur_rec.DATAID)||' doc lang: '||cur_rec.DOCUMENTLANGUAGE );
            END;
        END IF;            

        -- reject records where the UPLOAD has a valid wingspan_id to stop the duplicate creation.
        IF cur_rec.rec_type = 'UPLOAD' AND cur_rec.wingspan_id IS NOT NULL THEN
            DBMS_OUTPUT.PUT_LINE('2.1 exp_spool_study: REJECT:'||cur_rec.rec_type||' ID:'||to_char(cur_rec.dataid)||' EXP_ID:'||to_char(cur_rec.exportid)|| ' WS_ID:'||cur_rec.wingspan_id|| ' TS:'||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));
            v_reject_count := v_reject_count + 1;
        ELSE
        	-- use record separator (RS) to delimit fields
	        v_rs := chr(30);
  			v_rs2 := chr(30) || ',' || chr(30);

            -- use replace to ensure any " delimiters are escaped
			v_file_line := v_rs
				|| cur_rec.DATAID || v_rs2
			   	|| cur_rec.Sponsor || v_rs2 
                || cur_rec.PROTOCOL_NUMBER || v_rs2
                || cur_rec.project_code || v_rs2
                || cur_rec.country || v_rs2
                || cur_rec.country_code || v_rs2
                || cur_rec.site_id || v_rs2
                || cur_rec.site_name || v_rs2
                || cur_rec.investigator_name || v_rs2
                || cur_rec.class || v_rs2
                || cur_rec.zone || v_rs2
                || cur_rec.section || v_rs2
                || cur_rec.artifact || v_rs2
                || cur_rec.dia_key || v_rs2
                || nvl(cur_rec.doc_abbreviation,' ') || v_rs2
                || cur_rec.is_unblinded || v_rs2
                || cur_rec.doc_full_name || v_rs2
                || cur_rec.DOC_DATE || v_rs2
                || cur_rec.createdate || v_rs2
                || v_exp_language || v_rs2
                || cur_rec.LANGUAGEABBREVIATION || v_rs2
                || cur_rec.LANGUAGEIDENTIFIER || v_rs2
                || cur_rec.FIRST_NAME || v_rs2
                || cur_rec.LAST_NAME || v_rs2
                || cur_rec.ORGANIZATION_ID || v_rs2
                || cur_rec.DRUG_TYPE || v_rs2
                || cur_rec.VISIT_TYPE || v_rs2
                || cur_rec.VISIT_DOC_ID || v_rs2
                || cur_rec.REPORT_VERSION || v_rs2
                || cur_rec.EVENTIDENTIFIER || v_rs2
                || cur_rec.URL || v_rs2
                || cur_rec.rec_type || v_rs2
                || cur_rec.wingspan_id || v_rs;

			v_file_line := replace(v_file_line, '"', '""'); 
			v_file_line := replace(v_file_line, v_rs, '"'); 

			v_rec_count := c_data%ROWCOUNT;

			--V3.0 add line to export staging
			INSERT into exp_stg_export
				(jobid, file_name, line_order, dataid, file_line)
			VALUES
				(p_jobid, v_fname, v_rec_count, cur_rec.DATAID, v_file_line);

        END IF;

      END LOOP;

      DBMS_OUTPUT.PUT_LINE('3. exp_spool_study: file complete. Recs Added: '||to_char(v_rec_count)||' Recs Rejected: '||to_char(v_reject_count)|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));

      -- update: set the date for the last export time joined by job_id
      UPDATE tmf_health.exp_document_export a
         SET a.last_exp_dt = v_run_dt
       WHERE a.sponsor = p_sponsor
         AND a.protocol_number = p_protocol_number
         AND a.exportid = p_jobid;

  /*** removed as part of HC 2.0 ****************
  * Save for now in case of rollback to old process, will remove next full app release
  *    -- Update to reset wingspan id to keep sending updates, if document change does not find document
  *    UPDATE tmf_health.exp_document_export a
  *       SET a.wingspan_id = null,
  *           a.rec_type = 'UPLOAD'
  *     WHERE a.sponsor = p_sponsor
  *       AND a.protocol_number = p_protocol_number
  *       AND a.exportid = p_jobid
  *       AND a.wingspan_id is not null
  *       AND a.rec_type = 'UPDATE';
  ***********************************************/
     -- Reset ERROR_GROUP for new run
      UPDATE tmf_health.exp_document_export a
         SET a.ERROR_GROUP = null
       WHERE a.sponsor = p_sponsor
         AND a.protocol_number = p_protocol_number
         AND a.exportid = p_jobid;

     update tmf_health.exp_study_list
         set curr_status ='SPOOLED',
             last_update = SYSDATE
       where sponsor = p_sponsor
         and protocol_number = p_protocol_number;

      COMMIT;

  ELSE
    -- No documents to export
    update tmf_health.exp_study_list
       set curr_status = 'SPOOL REVIEWED',
           last_update = SYSDATE
     where sponsor = p_sponsor
       and protocol_number = p_protocol_number;

    COMMIT;

  END IF;

 DBMS_OUTPUT.PUT_LINE('4. exp_spool_study: complete'|| ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));  

END EXP_SPOOL_STUDY;


-- creates a job for the referenced study
PROCEDURE EXP_BATCH_JOB (
	P_SPONSOR IN VARCHAR2,
	P_PROTOCOL IN VARCHAR2,
	P_JOBID IN NUMBER
) 
AS

    v_cnt_chk     number;
	v_param       varchar2(255 char);
	v_run_dt      date default sysdate;
    v_msg         varchar(4000 char);
    v_last_msg    varchar(4000 char);
    v_last_jobid  number;

BEGIN

	v_param := P_SPONSOR || ':' || P_PROTOCOL;

	-- checks before job submit/start
	SELECT count(*)
	INTO v_cnt_chk
	FROM exp_job_master
	WHERE jobstatus <> 'COMPLETED'
		and jobparam = v_param;

	IF v_cnt_chk > 0 THEN
		--raise error that active jobs are currently running
		raise_application_error(-20999, 'Previous job still running; check status.');
	END IF;


	INSERT INTO exp_job_master
		(jobid, jobcreated, jobstatus, jobtype, jobparam)
	SELECT
		p_jobid,
		v_run_dt,
		'SUBMITTED',
		'BATCH',
		v_param
	FROM exp_study_list
	WHERE 1 = 1
		and sponsor = P_SPONSOR
		and protocol_number = P_PROTOCOL
		and rownum = 1;

	COMMIT;

	-- start the document update and spooling
	-- V2.3 Delete processed deleted records for this study
    DELETE FROM exp_document_export
     WHERE rec_type = 'DELETE'
       AND WINGSPAN_ID IS NULL
       AND SPONSOR = P_SPONSOR
       AND PROTOCOL_NUMBER = P_PROTOCOL;
    
    COMMIT;

    DBMS_OUTPUT.PUT_LINE(
    			'1. EXP_BATCH_JOB_START: REMOVE DELETED entries from export. delete count: ' 
    			|| to_char(SQL%ROWCOUNT) 
    			|| ' TS: '
    			||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS')
    		);

	-- use max value in case new study and has no been part of ALL JOB yet
	SELECT 
		max(last_jobid),
		' LAST ERROR: JOB_ID - ' || max(last_jobid) || ' MSG: ' || max(last_message)
	INTO v_last_jobid, v_last_msg
	FROM EXP_STUDY_LIST 
	WHERE 1 = 1
		and sponsor = P_SPONSOR
		and protocol_number = P_PROTOCOL;

	BEGIN
		exp_run_study(P_SPONSOR, P_PROTOCOL, v_run_dt, p_jobid);

		UPDATE exp_job_master
		SET jobstatus = 'UPDATED'
		WHERE jobid = p_jobid;

		COMMIT;

		exp_spool_study(P_SPONSOR, P_PROTOCOL, v_run_dt, p_jobid);

		-- update export list
		UPDATE exp_study_list
		SET last_update = sysdate,
			last_jobid = p_jobid,
			last_status = 'COMPLETE',
			last_message = null
		WHERE 1 = 1
			and sponsor = P_SPONSOR
            and protocol_number = P_PROTOCOL;

		COMMIT;

		EXCEPTION WHEN OTHERS THEN
			-- log error
			v_msg := SUBSTR('BATCH ERR: '|| SQLERRM || ' - ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 4000);
			IF v_last_msg like '%ERROR%' AND v_last_jobid is not NULL THEN
				v_msg := SUBSTR(v_msg || v_last_msg , 1, 4000);
			END IF;

			-- Prepend Error Message
			UPDATE exp_study_list
			SET curr_status = 'ERROR',
				last_update = SYSDATE,
				last_jobid = p_jobid,
				last_status = 'ERROR',
				last_message = v_msg 
			WHERE 1 = 1 
				and sponsor = p_sponsor
				and protocol_number = p_protocol;

	END;

	UPDATE exp_job_master
	SET jobstatus = 'SPOOLED',
		exportcount = (
				select count(1) - 1
				from exp_stg_export
				where jobid = p_jobid
			)
	WHERE jobid = p_jobid;

	COMMIT;

END EXP_BATCH_JOB;


-- creates a master job record
PROCEDURE  EXP_MASTER_JOB (
	P_TYPE IN VARCHAR2,
    P_PARAM IN VARCHAR2 DEFAULT NULL  --is ignored if p_type ='ALL'
) 
AS

    v_run_dt date default sysdate;
    v_cnt_chk number;
    v_jobid number;

    v_sponsor varchar2(255 char);   
    v_protocol_number varchar2(255 char);

BEGIN
    --checks before job submit/start
    SELECT COUNT(*)
      INTO v_cnt_chk
      FROM EXP_JOB_MASTER
     WHERE JOBSTATUS <> 'COMPLETED';

  IF v_cnt_chk > 0 THEN
    --raise error that active jobs are currently running
    raise_application_error(-20999, 'Previous job has not finished, please review last job run');
  ELSE
    IF p_type = 'ALL' or (p_type ='MANUAL' and p_param is not null) THEN
      --check that param is in agreed format=>sponsor:protocol_number
      v_sponsor:=substr(p_param,1,INSTR(p_param,':')-1);
      v_protocol_number:=substr(p_param,INSTR(p_param,':')+1,LENGTH(p_param));
      IF p_type <> 'ALL' THEN
         --check that sponsor/protocol info is valid
         select count(*)
           into v_cnt_chk
           from ETMF.EEL_PROJECT_DATA_MV a
          where a.customer = v_sponsor
            and a.protocol_number = v_protocol_number;

         IF v_cnt_chk = 0 THEN
            --raise invalid sponsor/protocol number combination error
            raise_application_error(-20998, 'Invalid sponsor/protocol combination provided');
         END IF;
      END IF;
    ELSE
      --raise invalid type and parameter combination
      raise_application_error(-20997, 'Invalid type and parameter combination submitted');
      NULL;

    END IF;
  END IF;

  --submit job
  SELECT job_seq.NEXTVAL INTO v_jobid FROM DUAL;

  INSERT INTO exp_job_master
  VALUES (v_jobid, v_run_dt, 'SUBMITTED', p_type, p_param, null);

  COMMIT;

END EXP_MASTER_JOB;

-- starts a job based on the id 
PROCEDURE  EXP_MASTER_JOB_START (
	P_JOBID IN NUMBER
) 
AS
    -- v2.0 filter all health studies that have a valid wingspan id
    -- V2.1 Add ALL job filter to allow finer control of which studies run
    CURSOR allps IS
        SELECT z.customer, z.protocol_number, b.curr_status, b.last_jobid, b.last_status, b.last_message
          FROM (SELECT a.CUSTOMER, a.PROTOCOL_NUMBER
                  FROM ELVIS_REF.TMF_STUDY_ENV_LOOKUP_V a
                 WHERE a.TMF_HEALTH_ENV = 1
                   AND a.WS_PROJECT_ID IS NOT NULL) z,
               TMF_HEALTH.EXP_STUDY_LIST b
         WHERE LOWER (z.protocol_number) = LOWER (b.protocol_number(+))
           AND 'Y' = upper(NVL(B.ALL_JOB_YN,'Y'))
        ORDER BY z.CUSTOMER, z.PROTOCOL_NUMBER;    

    -- update CURSOR to handle possible multiple success items
    CURSOR CSUC IS
        SELECT suc.data_id, suc.wingspan_id
          FROM tmf_health.exp_document_export doc,
               tmf_health.exp_stg_success suc
         WHERE suc.data_id = doc.dataid
         ORDER BY suc.data_id, suc.wingspan_id;

    v_run_dt            date default sysdate;
    v_cnt_chk           number;
    v_jobid             number;

    v_sponsor           varchar2(255 char);
    v_protocol_number   varchar2(255 char);

    p_type              varchar2(100 char);
    p_param             varchar2(255 char);

    v_last_status       varchar2(255 char);
    v_last_jobid        number;
    v_last_message      varchar(4000 char);
    v_mesg              varchar(4000 char);

BEGIN

    SELECT jobtype, jobparam, jobcreated
      INTO p_type, p_param, v_run_dt
      FROM exp_job_master
     WHERE jobid = p_jobid;

    -- process success records if less that 3 digits treat as null to avoid ~ or ~~ etc.
    FOR srec in CSUC LOOP
        UPDATE tmf_health.exp_document_export doc
           SET doc.wingspan_id = decode(length(srec.wingspan_id), 0,NULL,1,NULL,2,NULL,3,NULL,srec.wingspan_id)
         WHERE doc.dataid = srec.data_id;

        IF MOD(CSUC%ROWCOUNT,100) = 0 THEN COMMIT; END IF;
    END LOOP;
    COMMIT;

    -- v2.0 now truncate table as all values have been updated
    EXECUTE IMMEDIATE 'truncate table tmf_health.exp_stg_success';
    COMMIT;

    --V2.3 Delete processed deleted records
    EXECUTE IMMEDIATE 'delete from exp_document_export where rec_type = ''DELETE'' and WINGSPAN_ID IS NULL';
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('1. EXP_MASTER_JOB_START: REMOVE DELETED entries from export. delete count: '|| to_char(SQL%ROWCOUNT) || ' TS: '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS'));

 IF p_type = 'ALL' THEN

     FOR c IN allps LOOP
       -- catch Errors per study to allow ALL job to complete
       BEGIN
            exp_run_study(c.customer, c.protocol_number, v_run_dt, p_jobid);            
       EXCEPTION WHEN OTHERS THEN
            -- set message
            v_mesg := SUBSTR('UPDATE ERR: '||SQLERRM||' - '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 4000);

            -- log error
            IF c.last_status = 'ERROR' AND c.last_jobid is not NULL THEN
                -- add old message
                 v_mesg := SUBSTR(v_mesg||' LAST ERROR: JOB_ID - '||c.last_jobid|| ' MSG: '||c.last_message , 1, 4000);
                -- update the last job ID recs with the new one
                update exp_document_export set EXPORTID = p_jobid where EXPORTID = c.last_jobid;
            END IF;

            -- Prepend Error Message
            UPDATE TMF_HEALTH.EXP_STUDY_LIST 
               SET CURR_STATUS = 'ERROR',
                   LAST_UPDATE = SYSDATE,
                   LAST_JOBID = p_jobid,
                   LAST_STATUS = 'ERROR',
                   LAST_MESSAGE = v_mesg
            WHERE SPONSOR = c.customer
              AND PROTOCOL_NUMBER = c.protocol_number;
       END;

     END LOOP;

     UPDATE exp_job_master
        SET jobstatus = 'UPDATED'
      WHERE jobid = P_JOBID;

     COMMIT;

     FOR c IN allps LOOP
       -- SKIP previous ERROR'd JOBS as the data is incomplete to export
       IF c.curr_status <> 'ERROR' THEN
           -- catch Errors per study to allow ALL job to complete
           BEGIN
                exp_spool_study(c.customer, c.protocol_number, v_run_dt, p_jobid);
                -- clear the last error if success
                UPDATE TMF_HEALTH.EXP_STUDY_LIST 
                    SET LAST_UPDATE = SYSDATE,
                        LAST_JOBID = p_jobid,
                        LAST_STATUS = 'COMPLETE',
                        LAST_MESSAGE =  null
                  WHERE SPONSOR = c.customer
                    AND PROTOCOL_NUMBER = c.protocol_number;
           EXCEPTION WHEN OTHERS THEN
                -- log error                            
                -- set message
                v_mesg := SUBSTR('SPOOL ERR: '||SQLERRM||' - '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 4000);

                -- log error
                IF c.last_status = 'ERROR' AND c.last_jobid is not NULL THEN
                    -- add old message
                     v_mesg := SUBSTR(v_mesg||' LAST ERROR: JOB_ID - '||c.last_jobid|| ' MSG: '||c.last_message , 1, 4000);
                END IF;

                UPDATE TMF_HEALTH.EXP_STUDY_LIST 
                   SET CURR_STATUS = 'SPOOL ERROR',
                       LAST_UPDATE = SYSDATE,
                       LAST_JOBID = p_jobid,
                       LAST_STATUS = 'ERROR',
                       LAST_MESSAGE =  v_mesg
                WHERE SPONSOR = c.customer
                  AND PROTOCOL_NUMBER = c.protocol_number;
           END;
       END iF;

     END LOOP;

     UPDATE exp_job_master
        SET jobstatus = 'SPOOLED'
      WHERE jobid = P_JOBID;

     COMMIT;

 ELSE
     --manual run for individual protocol
     v_sponsor:=substr(p_param,1,INSTR(p_param,':')-1);
     v_protocol_number:=substr(p_param,INSTR(p_param,':')+1,LENGTH(p_param));

     -- use max value in case new study and has no been part of ALL JOB yet
     SELECT max(last_status), max(last_jobid), max(last_message)
       INTO v_last_status, v_last_jobid, v_last_message
       FROM EXP_STUDY_LIST 
      WHERE SPONSOR = v_sponsor
        AND PROTOCOL_NUMBER = v_protocol_number;

     BEGIN
         exp_run_study(v_sponsor, v_protocol_number, v_run_dt, p_jobid);

         UPDATE exp_job_master
            SET jobstatus = 'UPDATED'
          WHERE jobid = p_jobid;

         COMMIT;

         exp_spool_study(v_sponsor, v_protocol_number, v_run_dt, p_jobid);

         -- Update Export List  
         UPDATE TMF_HEALTH.EXP_STUDY_LIST 
            SET LAST_UPDATE = SYSDATE,
                LAST_JOBID = p_jobid,
                LAST_STATUS = 'COMPLETE',
                LAST_MESSAGE =  null
          WHERE SPONSOR = v_sponsor
            AND PROTOCOL_NUMBER = v_protocol_number;


         COMMIT;
     EXCEPTION WHEN OTHERS THEN
        -- log error
        v_mesg := SUBSTR('MANUAL ERR: '|| SQLERRM||' - '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 4000);
        IF v_last_status = 'ERROR' AND v_last_jobid is not NULL THEN
            v_mesg := SUBSTR(v_mesg||' LAST ERROR: JOB_ID - '||v_last_jobid|| ' MSG: '||v_last_message , 1, 4000);
            -- update the last job ID recs with the new one
            update exp_document_export set EXPORTID = p_jobid where EXPORTID = v_last_jobid;
        END IF;

        -- Prepend Error Message
        UPDATE TMF_HEALTH.EXP_STUDY_LIST 
           SET CURR_STATUS = 'ERROR',
               LAST_UPDATE = SYSDATE,
               LAST_JOBID = p_jobid,
               LAST_STATUS = 'ERROR',
               LAST_MESSAGE = v_mesg 
        WHERE SPONSOR = v_sponsor
          AND PROTOCOL_NUMBER = v_protocol_number;
     END;

     UPDATE exp_job_master
        SET jobstatus = 'SPOOLED'
      WHERE jobid = p_jobid;

 END IF;

END EXP_MASTER_JOB_START;

FUNCTION PI_LOOKUP( p_protocol IN VARCHAR2,
                    p_sitenum  IN VARCHAR2 )
         RETURN VARCHAR2
IS
    v_pi_name       VARCHAR2(255);
    v_lookup_sql    VARCHAR2(4000);

-- set the return format the same as ELVIS-DIA. 
BEGIN
    v_lookup_sql := 'SELECT last_name || '', '' || first_name AS pi  '||
                    '  FROM elvis_ref.site_participants             '||
                    ' WHERE PI_YN = ''Y''                           '||
                    '   AND protocol_number = :1 AND site_number = :2 ';

    execute immediate v_lookup_sql INTO v_pi_name USING p_protocol, p_sitenum;

    RETURN v_pi_name;

    EXCEPTION WHEN OTHERS THEN
        -- note the sql ERROR
        DBMS_OUTPUT.PUT_LINE('PI_LOOKUP ERROR: error geting PI for '||p_protocol||' site: '||p_sitenum||' ERR:'||SQLERRM||' - '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN NULL;

END PI_LOOKUP;        

FUNCTION LANG_LOOKUP( p_dataid IN NUMBER,
                      p_level  IN NUMBER DEFAULT 1 )
         RETURN VARCHAR2
-- p_level: 1 for Languange or anything else for Abbreviation
IS
        v_lookup_sql    VARCHAR2(4000);
        v_lang          VARCHAR2(255);
        v_abbrev        VARCHAR2(255);

BEGIN        
    v_lookup_sql :=  'SELECT '||     
                     '  CASE '||
                     '   WHEN lower(A.DOC_LANG) = ''english'' OR lower(LANG_ABBREVIATION) = ''eng'' '||
                     '       THEN ''English'' '||
                     '   WHEN A.DOC_LANG IS NOT NULL AND b.language_name IS NOT NULL '||
                     '       THEN trim(BOTH '' '' FROM b.language_name) '||
                     '   ELSE trim(BOTH '' '' FROM c.language_name) '||
                     '  END as NEW_LANGUAGE, '||
                     '  CASE '||
                     '   WHEN lower(A.DOC_LANG) = ''english'' OR lower(LANG_ABBREVIATION) = ''eng'' '|| 
                     '       THEN ''eng'' '||
                     '   WHEN A.DOC_LANG IS NOT NULL AND b.language_name IS NOT NULL '||
                     '       THEN trim(BOTH '' '' FROM b.language_code) '||
                     '   ELSE trim(BOTH '' '' FROM c.language_code) '||
                     '  END as NEW_LANGUAGE_CODE '||
                     ' FROM etmf.eel_cat_doc_data_mv a, etmf.cflanguagestbl b, etmf.cflanguagestbl c '||
                     'WHERE a.DOC_LANG = b.language_name(+) '||
                     '  AND lower(a.LANG_ABBREVIATION) = c.language_code(+) '||
                     '  AND A.DATAID = :1 ';

    EXECUTE IMMEDIATE v_lookup_sql INTO v_lang, v_abbrev USING p_dataid;

    IF p_level = 1 THEN
        RETURN v_lang;
    ELSE
        RETURN v_abbrev;
    END IF;

    EXCEPTION WHEN OTHERS THEN
        -- note the sql ERROR
        DBMS_OUTPUT.PUT_LINE('LANG_LOOKUP ERROR: no lang for dataid: '||to_char(p_dataid)||' ERR:'||SQLERRM||' - '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN NULL;

END LANG_LOOKUP;

END WINGSPAN_UPLOAD;
/
