
SET DEFINE OFF;
SET TIMING ON;
set feedback off;
select to_char(sysdate, 'YYYY-MON-DD HH24:MI:SS') as run_date from dual;
set feedback on;

--
-- WINGSPAN_UPLOAD  (Package) 
--
CREATE OR REPLACE PACKAGE TMF_HEALTH.WINGSPAN_UPLOAD 
AS 

/**

Package to load download/upload eTMF Wingspan records via csv

TMF_HEALTH Wingspan download/upload data process Package Build History

Version		Date			User 			Changes
======================================================================================
1.0.0		06-JUL-2017	    LZulueta	    Initial Release
1.0.1       03-AUG-2017     LZulueta        Modification to "properly quote" '"' chars
2.0.0       13-OCT-2017     JKinnaird & DJordan     Add Document update/delete capability, 
                                                    add checks for active studies, 
                                                    update document selection based on appropriate sites
                                                    truncate success data after succeess update
                                                    Update output file to include disposition and wingspan id     
2.0.0       23-OCT-2017     JKinnaird       Add filter when submitting all study updates that only thos with a
                                            Wingspan ID will be submitted 
                                            Manual loads will work regardless of the Wingspan ID
2.0.0       25-OCT-2017     JKinnaird       Success records need a cursor to process updates, and commits every 100 records.
2.0.0       27-OCT-2017     JKinnaird       Fix to exp_run_study to update ids which may be null
2.0.0       06-NOV-2017     JKinnaird       Fixes to updates in EXP_SPOOL_STUDY: remove wingspan id on updates after spooled,
                                            update last export date after spooled
2.1.0       23-MAR-2018     JKinnaird       Add DBMS out, log study error, no halt on any error, all job inclusion,
                                            not to save WS_ID < 3 char, Langauge fix, all job recovery  
2.1.1       29-MAR-2018     JKinnaird       Fix inclusion of previous jobs by excluding previous deleted items.
2.2.0       06-JUN-2018     JKinnaird       Add update to change processing to Intiate file CSVI to be manually moved, 
                                            change when initiated file is available, 
                                            add INSERT when manual run and study is processing for the first time. 
2.2.1       01-AUG-2018     JKinnaird       Filter spooling to ensure no UPLOAD with WINGSPAN_ID are sent, which causes duplicates
                                            Add commits after all updates.
2.2.2       02-AUG-2018     JShoun          new build procedure to return refcursor
2.2.3       14-AUG-2018     JShoun          corrected ordering of process output, added job id
2.2.4       15-AUG-2018     JShoun          moved script SQL into package
2.3.0       10-AUG-2018     JKinnaird       Changes to export to correct for name mismatches and special characters FN and LN fields,
                                            trim excess whitespace on all EXP_DOCUMENT_EXPORT docs,
                                            Delete processed DELETE records so there is no impact if undeleted
2.3.0       27-AUG-2018     JKinnaird       Add PI_LOOKUP funciton to change to PI name to pull from CTMS data 
                                            not ELVIS to match same PI names
                                            Add LANG_LOOKUP to Fix language ID attributes
                                            Now Corrrespondence Added to the data list.
2.3.0       30-AUG-2018     JKinnaird       Remove all UTL-FILE commands to avoid writing export file to DB server 

2.4.0       16-JAN-2018     JKinnaird       Change Personnel first/last names to use same format as
                                            ELVIS_REF.SITE_PARTICIPANTS including case and special chars   
2.4.0       21-JAN-2018     JKinnaird       Trim leading and trailing spaces from language values in LANG_LOOKUP function    

3.0.1       23-MAY-2019     JShoun          new job batch start routines for HC 2.0
3.0.2       31-MAY-2019     JShoun          moved MyBatis code to procedures
3.0.3       17-JUL-2019     JKinnaird       updated SET_DOC_UPLOAD_STATUS to set rec type for next run, removed function
                                            in EXP_SPOOL_STUDY to reset the rec_type attibute
3.0.4       18-JUL-2019     JKinnaird       Changed the GET_JOB_EXPORT_DOCS to ensure distinct records
3.0.5       19-JUL-2019     JKinnaird       Changed delete statement to be thread safe in EXP_BATCH_JOB, 
                                            updated reload of unprocessed docs in exp_run_study
3.0.6       22-JUL-2019     JKinnaird       Updated the sppol to set the doc_abbreviation to space char
                                            when it is null - temp until app can handle null
3.0.7       24-JUL-2019     JShoun          added procedure to get the next jobs from batch queue
3.0.8       18-SEP-2019     MBurmeister     Added routing to exp_run_study to set docs from dropped sites to Deleted in Export table
3.0.9       13-MAY-2021     JShoun          changed the delimiter from '|' to '0X1E' (RS) to protect doc names

**/

-- proc used to submit jobs (For the daily job p_type => 'ALL', p_param is null)
--                         (For manual protocol number submissions p_type => 'MANUAL', 
--                              p_param format is sponsor:protocol_number
--                           example: exp_master_job('MANUAL','BAXTER:CSPIVTCHN001');
PROCEDURE EXP_MASTER_JOB (p_type IN VARCHAR2, p_param IN VARCHAR2 DEFAULT NULL);

-- will be called by scheduled script
PROCEDURE EXP_MASTER_JOB_START (p_jobid IN NUMBER);

-- register job and spool documents for batch service
PROCEDURE EXP_BATCH_JOB (
	P_SPONSOR IN VARCHAR2,
	P_PROTOCOL IN VARCHAR2,
	P_JOBID IN NUMBER
);


-- remove records from export stage table 
PROCEDURE CLEAR_EXP_STAGE;

-- mark job completed
PROCEDURE SET_COMPLETED (p_jobid IN NUMBER);

-- lookup the current PI name
FUNCTION PI_LOOKUP( p_protocol IN VARCHAR2, p_sitenum  IN VARCHAR2 ) RETURN VARCHAR2;

-- lookup Language or language code for given dataid, defaults to Language value returned
FUNCTION LANG_LOOKUP( p_dataid IN NUMBER, p_level  IN NUMBER DEFAULT 1 ) RETURN VARCHAR2;


PROCEDURE SET_JOB_STATUS (
		p_jobid       in NUMBER,
		p_jobstatus   in VARCHAR2
	);

PROCEDURE SET_DOC_UPLOAD_STATUS (
		p_dataid              in NUMBER,
		p_wingspan_id         in VARCHAR2,
		p_wingspan_response   in VARCHAR2,
		p_error_group         in VARCHAR2
	);

PROCEDURE REMOVE_STAGING_DOC (
		p_jobid        in NUMBER,
		p_order       in NUMBER
	);

PROCEDURE GET_JOB_EXPORT_DOCS (
		p_jobid        in NUMBER,
		p_offset       in NUMBER,
		p_result       out SYS_REFCURSOR
	);

PROCEDURE GET_JOB_RUN_QUEUE (
		p_result       out SYS_REFCURSOR
	);



END WINGSPAN_UPLOAD;
/
