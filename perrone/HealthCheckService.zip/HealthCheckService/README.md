# TMF Health Check Service

The Health Check Service is a Tomcat application that synchornizes 
document content between ELVIS-DIA (ETMF) and Wingspan Health Check. 
The services scans for change records in the health sehema and 
uses the Wingspan API to make corresponding additions/updates to the
tracking documents in health check.

A key component is the health check transform engine that maps
ETMF documents into Wingspan placeholders. The transform consists
of an engine (Java) and rules package (JSON). This was developed by
Wingspan.

The health check service is a Spring Boot application. It is designed
as a container application where the app and Tomcat are bundled into
a runnable JAR. The web interface is implemented in Thymeleaf.
