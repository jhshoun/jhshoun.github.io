package com.iqvia.healthcheck.dao;


import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.iqvia.healthcheck.dao.models.DocExport;
import com.iqvia.healthcheck.dao.models.Document;

import lombok.AllArgsConstructor;

@Mapper
public interface DocumentMapper
{

	// get a document by data id
	Document getDocById(
					@Param("p_dataid") Long dataid
				);

	// get list of export records from export queue
	List<DocExport> getSpoolDocsForJob( ExportSearchParms parms);

	// remove doc from export staging
	void removeFromExportStaging( 
					@Param("p_jobid") Long job, 
					@Param("p_order") int order
				);

	// set document upload status
	void setUploadStatus(
					@Param("p_dataid") Long dataid,
					@Param("p_wingspan_id") String iid,
					@Param("p_error_group") String errGroup,
					@Param("p_wingspan_response") String response
				);


	// get docs from delete list
	List<Document> deleteDocList(
					@Param("p_protocol_number") String protocol_number
				);

	// get docs from duplicate list
	List<Document> duplicateDocList(
					@Param("p_protocol_number") String protocol_number
				);

	// get all docs for a protocol (not all columns fetched) 
	List<Document> getDocsByStudy(
					@Param("p_protocol_number") String protocol_number
				);





	/*
	 * parameter classes: required to get RESULTSET (ref cursors)
	 * back from Oracle
	 */
	@AllArgsConstructor
	public class ExportSearchParms
	{
		public Long p_jobid;
		public int p_offset;        // mis-named, this controls the size of the cursor fetch
		public ArrayList<DocExport> p_result;
	}


}