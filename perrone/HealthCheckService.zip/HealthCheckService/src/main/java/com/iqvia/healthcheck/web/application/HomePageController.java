package com.iqvia.healthcheck.web.application;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.iqvia.healthcheck.dao.BatchMapper;

import lombok.Getter;
import lombok.Setter;
import oracle.sql.TIMESTAMP;


@Controller
@RequestMapping(value="/")
public class HomePageController
{

	@Autowired
	private BatchMapper batcher;

	@SuppressWarnings("rawtypes")
	@RequestMapping(method = RequestMethod.GET)
	public String systemStatus(Model model) 
	{
		Map<Long, JobStatus> batches;
		List<Map> batchList;

		// get execution data from batch repository tables
		batchList = batcher.getAll();


		batches = new LinkedHashMap<Long, JobStatus>();
		for (Map exec : batchList)
		{
			JobStatus jstat;
			String description;

			Long instance;
//			Long exec_id;
			String status;
			int export_count;
			int pending_count;
			double pcnt_complete = 100.0;

			// load batch job status
			jstat = new JobStatus();

			instance = ((BigDecimal) exec.get("JOB_INSTANCE_ID")).longValue();
//			exec_id = ((BigDecimal) exec.get("JOB_EXECUTION_ID")).longValue();

			export_count = ((BigDecimal) exec.get("EXPORTCOUNT")).intValue();
			pending_count = ((BigDecimal) exec.get("PENDINGCOUNT")).intValue();
			if (pending_count > 0) {
				pcnt_complete = (1.0 - ((double) pending_count/export_count)) * 100.0;
			}

			status = (String) exec.get("STATUS");
			if ( "STARTED".equals(status) ) {
				jstat.setStoplight("go.png");
			}
			else if ( "FAILED".equals(status) ) {
				jstat.setStoplight("caution.png");
			}
			else {
				jstat.setStoplight("stop.png");
			}


			jstat.setJobId(
							String.format("Job ID: %s", (BigDecimal) exec.get("JOB_ID")+"")
						);
			jstat.setContext(
							String.format("Context: %s / %s", (String) exec.get("SPONSOR"), (String) exec.get("PROTOCOL"))
						);
			jstat.setStartTime(
							String.format("Start Time: %s", (TIMESTAMP) exec.get("START_TIME"))
						);
			jstat.setEndTime(
							String.format("End Time: %s ", (TIMESTAMP) exec.get("END_TIME"))
						);

			description = (String) exec.get("EXIT_MESSAGE");
			description = description == null ? " --- " : description;
			description = description.length() > 350 ? description.substring(0, 340) + " ..." : description;
			jstat.setExitStatus(
							String.format("Exit: %s ", description)
						);

			// setup the progress bar
			if (export_count < 1) {
				jstat.setProgressNo("100");
				jstat.setProgressType("progress-bar-warning");
				jstat.setProgressStatus("No documents in export.");
			}
			else if ( "FAILED".equals(status) ) {
				jstat.setProgressNo("100");
				jstat.setProgressType("progress-bar-danger");
				jstat.setProgressStatus(
						String.format("%d of %d processed", 
								export_count - pending_count,
								export_count,
								pcnt_complete)
					);
			}
			else if ( "STARTED".equals(status) ) {
				jstat.setProgressNo( String.format("%.0f", pcnt_complete) );
				jstat.setProgressType("progress-bar-info");
				jstat.setProgressStatus(
						String.format("%d of %d processed (%.1f%%)", 
								export_count - pending_count,
								export_count,
								pcnt_complete)
					);
			}
			else {
				jstat.setProgressNo( String.format("%.0f", pcnt_complete) );
				jstat.setProgressType("progress-bar-success");
				jstat.setProgressStatus(
								String.format("%d of %d processed (%.1f%%)", 
										export_count - pending_count,
										export_count,
										pcnt_complete)
							);
			}

			batches.put(instance, jstat);
		}

		model.addAttribute("batch_jobs", batches);
		return "index";
	}


	/*
	 * model holding batch job status, passed to Thymeleaf
	 */
	@Getter
	@Setter
	public class JobStatus
	{
		private String stoplight;
		private String jobId;
		private String context;
		private String startTime;
		private String endTime;
		private String exitStatus;
		private String progressNo;
		private String progressStatus;
		private String progressType;

	}


}
