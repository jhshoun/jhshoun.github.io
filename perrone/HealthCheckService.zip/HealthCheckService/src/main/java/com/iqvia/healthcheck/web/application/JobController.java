package com.iqvia.healthcheck.web.application;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.iqvia.healthcheck.dao.models.Job;
import com.iqvia.healthcheck.service.HealthService;

@Controller
@RequestMapping(value="/jobs")
public class JobController
{

	@Autowired
	private HealthService healthService;

	@RequestMapping(method= RequestMethod.GET)
	public String getAllJobs(Model model)
	{
		List<Job> jobList;

		jobList = this.healthService.getAllJobs();
		model.addAttribute("jobs", jobList);
		return "joblist";
	}


}
