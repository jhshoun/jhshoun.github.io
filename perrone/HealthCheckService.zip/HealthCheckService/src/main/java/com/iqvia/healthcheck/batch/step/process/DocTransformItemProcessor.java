package com.iqvia.healthcheck.batch.step.process;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.iqvia.healthcheck.dao.DocumentMapper;
import com.iqvia.healthcheck.dao.models.DocExport;
import com.iqvia.healthcheck.dao.models.Document;

/**
 * processor for transforming an exported ELVIS-DIA 
 * metadata record into a Document object
 * 
 * @author q766769
 *
 */
public class DocTransformItemProcessor implements ItemProcessor<DocExport, Document>
{
	private Logger logger_ = LoggerFactory.getLogger(DocTransformItemProcessor.class);

	@Autowired
	private DocumentMapper doccer;

	@Override
	public Document process(DocExport exDoc) throws Exception
	{
		Document transformed;

		// create TMF document from spooled CSV data
		transformed = exDoc.asDocument();
		logger_.debug("xform new doc: {}", transformed);

		// remove record from staging table
		doccer.removeFromExportStaging(exDoc.getJobId(), exDoc.getLineOrder());
		logger_.debug("stage item removed: job {} / item {}", exDoc.getJobId(), exDoc.getCsvLine());

		return transformed;
	}

}
