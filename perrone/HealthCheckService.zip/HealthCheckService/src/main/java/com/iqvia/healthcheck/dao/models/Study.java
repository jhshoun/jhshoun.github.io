package com.iqvia.healthcheck.dao.models;

import java.io.Serializable;
import java.sql.Date;

import lombok.Getter;
import lombok.Setter;

public class Study implements Serializable
{
	/** * */ private static final long serialVersionUID = 7031279660840592698L;

	@Getter @Setter
	private String sponsor;

	@Getter @Setter
	private String protocolNumber;

	@Getter @Setter
	private String protocolStnd;

	@Getter @Setter
	private Date LastUpdate;

	@Getter @Setter
	private String currStatus;

	@Getter @Setter
	private String lastJobId;

	@Getter @Setter
	private String lastStatus;

	@Getter @Setter
	private String lastMessage;

	@Getter @Setter
	private String allJobYn;

	@Override
	public String toString()
	{
		return getSponsor() + " " + getProtocolNumber() + " - " + getCurrStatus();
	}

	// accessors

	// reads the all job y/n flag
	public boolean active()
	{
		return "Y".equals( getAllJobYn() );
	}
	public boolean isAll()
	{
		return "Y".equals( getAllJobYn() );
	}
	public boolean isManual()
	{
		return "N".equals( getAllJobYn() );
	}
	public boolean isInit()
	{
		return "I".equals( getAllJobYn() );
	}

}
