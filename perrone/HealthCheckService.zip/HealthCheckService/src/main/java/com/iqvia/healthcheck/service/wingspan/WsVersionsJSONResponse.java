package com.iqvia.healthcheck.service.wingspan;

/**
 * document versions
 * @author q766769
 *
 * POJO to de-serialize the Wingspan
 * response to a document versions API request
 */
public class WsVersionsJSONResponse
{
	public String message;
	public String version;
	public Data[] data;

	// sub models
	public static class Data
	{
		public String id;
		public String chronicleId;
		public String name;
		public String createdDate;
		public String versionMajor;
		public String versionMinor;
		public String versionMajorMinor;
		public DocStatus documentStatus;
		public String finalizationDate;
		public String latest;
		public String sourceDescription;

	}

	public static class DocStatus
	{
		public String value;
		public String name;
	}

	public static class Links
	{
		public String qc;
		public String self;
		public String finalize;
		public String content;
	}

	// default constructor
	public WsVersionsJSONResponse()
	{
		// NOOP
	}

}

