package com.iqvia.healthcheck.service.wingspan;

import java.io.IOException;
import java.nio.charset.Charset;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.StreamUtils;

public class ReqRespLoggingInterceptor implements ClientHttpRequestInterceptor
{

	private final Logger logger_ = LoggerFactory.getLogger(this.getClass());

	@Override
	public ClientHttpResponse intercept(
					HttpRequest request, 
					byte[] body,
					ClientHttpRequestExecution execution
				) throws IOException
	{
		logRequest(request, body);
		ClientHttpResponse response = execution.execute(request, body);
		logResponse(response);
		return response;
	}

	private void logRequest(HttpRequest request, byte[] body) throws IOException
	{
		logger_.error(
					"===========================request begin================================================");
		logger_.error("URI         : {}", request.getURI());
		logger_.error("Method      : {}", request.getMethod());
		logger_.error("Headers     : {}", request.getHeaders());
		logger_.error("Request body: {}", new String(body, "UTF-8"));
		logger_.error(
					"==========================request end================================================");
	}

	private void logResponse(ClientHttpResponse response) throws IOException
	{
		logger_.error(
					"============================response begin==========================================");
		logger_.error("Status code  : {}", response.getStatusCode());
		logger_.error("Status text  : {}", response.getStatusText());
		logger_.error("Headers      : {}", response.getHeaders());
		logger_.error("Response body: {}", StreamUtils.copyToString(
					response.getBody(), Charset.defaultCharset()));
		logger_.error(
					"=======================response end=================================================");
	}

}
