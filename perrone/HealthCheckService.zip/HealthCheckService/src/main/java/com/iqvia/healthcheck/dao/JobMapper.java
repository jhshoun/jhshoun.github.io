package com.iqvia.healthcheck.dao;


import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import com.iqvia.healthcheck.dao.models.Job;

@Mapper
public interface JobMapper
{

	// get details for a single job
	Job findById(
					@Param("p_jobid") Long job
				);

	// get all jobs
	List<Job> getAll( );

	// set job status
	void setStatus(
					@Param("p_jobid") Long job,
					@Param("p_jobstatus") String status
				);

	// set job as completed
	void setCompleted(
					@Param("p_jobid") Long job
				);

	// get next job id
	Long getNextJobId(
					@Param("p_sponsor") String sponsor,
					@Param("p_protocol") String protocol
				);

	// get count of running jobs
	Long getRunCount();

	// create new job for study
	void expBatchJob(
					@Param("p_sponsor") String sponsor,
					@Param("p_protocol") String protocol,
					@Param("p_jobid") Long job
				);


}
