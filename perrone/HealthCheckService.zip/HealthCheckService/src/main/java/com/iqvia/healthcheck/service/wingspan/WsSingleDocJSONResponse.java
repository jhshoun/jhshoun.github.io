package com.iqvia.healthcheck.service.wingspan;

/**
 * @author q766769
 *
 * very simple POJO class to de-serialize the Wingspan
 * response to a single document lookup
 */
public class WsSingleDocJSONResponse implements WsJSONResponse
{
	public String version;
	public String message;
	public Data data;

	public static class Data
	{
		public String id;
		public String name;
		public String tmfItemId;
	}



	// generic constructor
	public WsSingleDocJSONResponse()
	{
		// NOOP
	}


	@Override
	public String getMessage()
	{
		return null;
	}

	@Override
	public String getIid()
	{
		return null;
	}
}

