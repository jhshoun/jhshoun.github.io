package com.iqvia.healthcheck.service.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.iqvia.healthcheck.service.HealthService;

@RestController
@RequestMapping(value="/api")
public class StudyServiceController
{

	@Autowired
	private HealthService healthService;

	// call db procedure to update the all-jobs flag for a study
	@RequestMapping(method=RequestMethod.POST, value="/studies/{protocol}")
	public void setAllFlag(
					@PathVariable(name="protocol", required=true) String protocolNumber,
					@RequestParam(name="all", required=true) String allJob
				)
	{
		this.healthService.setAllJobsFlag( protocolNumber, allJob );
	}


}
