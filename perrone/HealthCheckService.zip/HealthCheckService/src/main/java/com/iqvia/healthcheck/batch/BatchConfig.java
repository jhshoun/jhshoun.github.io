package com.iqvia.healthcheck.batch;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.batch.BasicBatchConfigurer;
import org.springframework.boot.autoconfigure.batch.BatchProperties;
import org.springframework.boot.autoconfigure.transaction.TransactionManagerCustomizers;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

import com.iqvia.healthcheck.batch.step.ExportProcessorTask;
import com.iqvia.healthcheck.batch.step.SpoolSudyDocumentsTask;

@Configuration
@EnableBatchProcessing
public class BatchConfig extends BasicBatchConfigurer
{
	private static final Logger logger_ = LoggerFactory.getLogger(BatchConfig.class);

	protected BatchConfig(BatchProperties properties, DataSource dataSource,
						TransactionManagerCustomizers transactionManagerCustomizers)
	{
		super(properties, dataSource, transactionManagerCustomizers);
	}

	@Autowired
	private JobBuilderFactory jobFactory;

	@Autowired
	private StepBuilderFactory stepFactory;

	@Autowired
	SqlSessionFactory sqlSessionFactory;

	// configure the repository
	@Autowired
	private PlatformTransactionManager transactionManager;

	@Autowired
	private DataSource db;

	// needed to change the isolation level so it will 
	// work with Oracle
	@Override
	protected JobRepository createJobRepository() throws Exception
	{
		JobRepositoryFactoryBean factory;

		factory = new JobRepositoryFactoryBean();
		factory.setDataSource(db);
		factory.setTransactionManager(transactionManager);
//		factory.setTransactionManager(dsManager);
		factory.setIsolationLevelForCreate("ISOLATION_READ_COMMITTED");
		factory.setMaxVarCharLength( 2000 );

		return factory.getObject(); 
	}

	@Bean
	public JobLauncher asyncJobLauncher() throws Exception
	{
		SimpleJobLauncher sjl = new SimpleJobLauncher();
		SimpleAsyncTaskExecutor sate = new SimpleAsyncTaskExecutor();

		sjl.setJobRepository( this.getJobRepository() );
		sjl.setTaskExecutor( sate );

		return sjl;
	}


	/**
	 * job, step, task, and item processors defined here
	 */

	// tag::task-exporter[]
	@Bean
	@Scope("prototype")
	public SpoolSudyDocumentsTask spooler()
	{
		return new SpoolSudyDocumentsTask();
	}

	@Bean
	@Scope("prototype")
	public Step docExporter()
	{
		return stepFactory
					.get("exportDocs")
					.tasklet( spooler() )
					.build();
	}

	@Bean
	@Scope("prototype")
	public ExportProcessorTask uploader()
	{
		return new ExportProcessorTask();
	}

	@Bean
	@Scope("prototype")
	public Step docUploader()
	{
		return stepFactory
					.get("uploadDocs")
					.tasklet( uploader() )
					.build();
	}
	// tag::task-exporter[]

	// tag::jobs-step[]
	@Bean
	@Scope("prototype")
	public Job exportHealthJob(JobCompletionNotifier listener)
	{

logger_.info("***** built joblauncher");

		return jobFactory
				.get("healthExportJob")
//				.preventRestart()
				.incrementer( new RunIdIncrementer() )
				.listener( listener )
				.start( docExporter() )
				.next( docUploader() )
				.build();
	}


	@Bean
	@Scope("prototype")
	public Job transferHealthJob(JobCompletionNotifier listener)
	{

logger_.info("***** built restart joblauncher");

		return jobFactory
				.get("transferHealthJob")
//				.preventRestart()
				.incrementer( new RunIdIncrementer() )
				.listener( listener )
				.start( docUploader() )
				.build();
	}

	// end::job-step[]


}


