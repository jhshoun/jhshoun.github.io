package com.iqvia.healthcheck.service.api;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.iqvia.healthcheck.dao.ConfigurationMapper;
import com.iqvia.healthcheck.dao.JobMapper;
import com.iqvia.healthcheck.dao.StudyMapper;
import com.iqvia.healthcheck.dao.models.Study;

/**
 * overall controller for triggering jobs
 * can initiate a job for a specific study or
 * run a block of jobs based on last run
 * and available slots
 * 
 * @author q766769
 *
 */
@RestController
@RequestMapping(value = "/api")
public class BatchServiceController
{
	private static final Logger logger_ = LoggerFactory.getLogger(BatchServiceController.class);


	@Autowired
	private ApplicationContext appCtx;

	@Autowired
	@Qualifier("asyncJobLauncher")
	private JobLauncher jobLauncher;

	@Autowired
	private JobMapper jobber;

	@Autowired
	private StudyMapper study;

	@Autowired
	private ConfigurationMapper config;


	// initiate ad hoc job for a single study
	@RequestMapping(method = RequestMethod.GET, value = "/batch/run/study")
	public String startBatchStudy(
					@RequestParam(name="sponsor", required=true) String sponsor,
					@RequestParam(name="protocol", required=true) String protocol
				) throws Exception
	{
		Study target;
		boolean init;

		target = study.getByProtocol(protocol);
		init = ( "I".equals(target.getAllJobYn()) );

		return startStudyBatchRun(sponsor, protocol, "MANUAL", init);
	}

	// schedule the launch loop
	// delay 10 minutes after startup, poll every 5 minutes
	@Scheduled(fixedRate = 300000L, initialDelay = 300000L)
	public void scheduleBatchRun()
	{
		logger_.info("start study processing {}", new Date());
		if ( "Y".equals( config.getByName("EXP_DAILY_JOB_ENABLED").getVarValue() ) ) {

			try {
				logger_.info("launch: {}", this.startBatchRun());
			}
			catch (Exception e) {
				logger_.info("failed to start new batch group", e);
			}
		}
		else {
			logger_.info("automatic run disabled");
		}

	}

	// gets the list of pending studies and creates new jobs based
	// on current running and configured thread limit
	@RequestMapping(method = RequestMethod.GET, value = "/batch/run/all")
	public String startBatchRun( ) throws Exception
	{
		List<Study> queue;
		StudyMapper.StudySearchParms parms;
		String response = "LAUNCH ALL";
		int running;
		int free;
		int MAX_THREADS;

		// get the list of jobs ready to run from all job list
		// ordered based on oldest run for idle studies
		parms = new StudyMapper.StudySearchParms(null);
		study.getRunQueue(parms);
		queue = parms.p_result;
		if (queue == null || queue.size() < 1) {
			return "LAUNCH: no available studies to run.";
		}

		// get a list (count) of running jobs
		MAX_THREADS = Integer.parseInt( config.getByName("wingspan.thread_limit").getVarValue() );
		logger_.info("Thread limit is {}", MAX_THREADS);
		running = jobber.getRunCount().intValue();
		free = MAX_THREADS - running;
		if (free < 1) {
			return "LAUNCH: no available threads for new jobs.";
		}

		// create new runs based on available threads
		for (Study s : queue)
		{
			String status;

			status = startStudyBatchRun(s.getSponsor(), s.getProtocolNumber(), "AUTO", false);

			response += "\r\n" + s.getSponsor() + " / " + s.getProtocolNumber() + " - ";
			if ( status.startsWith("Go go go") ) {
				response += "start OK";
			}
			else {
				response += "ERR: " + status;
			}

			// decrement the queue and break if slots are full
			if (--free == 0) {
				break;
			}
		}

		return response;
	}

	private String startStudyBatchRun( String sponsor, String protocol, String mode, boolean initialize)
	{
		Long jobid;
		JobExecution jx;
		JobParametersBuilder parmBuilder;
		Job exportHealthJob;


		// get the export job id
		jobid = jobber.getNextJobId(sponsor, protocol);
		if (jobid == null) {
			logger_.error("job for {} / {} is still running", sponsor, protocol);
			return "ERR: a job for " + sponsor + " / " + protocol + " is currently running.";
		}

		// launch the batch job
		// 'mode' flag controls whether a new job run will initiate when
		// job execution ends (AUTO will re-trigger runs)
		parmBuilder = new JobParametersBuilder()
							.addString("sponsor", sponsor)
							.addString("protocol", protocol)
							.addLong("jobid", jobid)
							.addString("mode", mode)
							.addString("initialize", Boolean.toString(initialize) );
//		    				.addLong("time", System.currentTimeMillis());

		// get a JOB
		// NOTE: this could have been injected, but a singleton bean
		// is not threadsafe -- so we get a new JOB each run,
		// the health job us PROTOTYPE scope and created new each request
		exportHealthJob = (Job) appCtx.getBean("exportHealthJob");

		try {
			jx = jobLauncher.run(
								exportHealthJob, 
								parmBuilder.toJobParameters()
							);
			return "Go go go --->> " + jx.toString();
		}
		catch (JobExecutionAlreadyRunningException jeare) {
			logger_.error("job instance already running", jeare);
			return jeare.getMessage();
		}
		catch (JobRestartException jre) {
			logger_.error("job restart issue", jre);
			return jre.getMessage();
		}
		catch (Exception e) {
			logger_.error("job launch problem", e);
			return "Could not start batch job " + e.getMessage();
		}

	}


}

