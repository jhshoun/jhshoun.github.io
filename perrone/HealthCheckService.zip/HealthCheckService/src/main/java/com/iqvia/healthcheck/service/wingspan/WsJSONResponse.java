package com.iqvia.healthcheck.service.wingspan;

/**
 * @author q766769
 *
 * supertype for all API response classes
 */
public interface WsJSONResponse
{
	public String getMessage();
	public String getIid();

}

