package com.iqvia.healthcheck.service.wingspan;

/**
 * @author q766769
 *
 * very simple POJO class to de-serialize the Wingspan
 * response to a document search request
 */
public class WsDocumentJSONResponse implements WsJSONResponse
{
	public String version;
	public String message;
	public int totalCount;
	public Data[] data;

	public static class Data
	{
		public String id;
		public String name;
		public String tmfItemId;
	}



	// generic constructor
	public WsDocumentJSONResponse()
	{
		// NOOP
	}


	@Override
	public String getMessage()
	{
		return null;
	}

	@Override
	public String getIid()
	{
		return null;
	}
}

