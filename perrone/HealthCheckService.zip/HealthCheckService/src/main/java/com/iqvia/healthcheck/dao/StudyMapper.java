package com.iqvia.healthcheck.dao;


import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.iqvia.healthcheck.dao.models.Study;

import lombok.AllArgsConstructor;

@Mapper
public interface StudyMapper
{

	// get all studies
	List<Study> getAll( );

	// get a single study
	Study getByProtocol( 
					@Param("protocol") String protocolNumber
				);

	// get "all job" studies by priority
	List<Study> getRunQueue(StudySearchParms params);

	// set the all jobs flag
	void setAllJob(
					@Param("protocol") String protocolNumber,
					@Param("flag") String yes_no
				);



	/*
	 * parameter classes: required to get RESULTSET (ref cursors)
	 * back from Oracle
	 */
	@AllArgsConstructor
	public class StudySearchParms
	{
		public ArrayList<Study> p_result;
	}


}