package com.iqvia.healthcheck.dao.models;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

public class Configuration implements Serializable
{
	/** * */ private static final long serialVersionUID = -4172428321192365025L;

	@Getter @Setter
	private String varName;

	@Getter @Setter
	private String varValue;


	@Override
	public String toString()
	{
		return getVarName() + " / " + getVarValue();
	}
}
