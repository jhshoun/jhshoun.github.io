package com.iqvia.healthcheck.service.wingspan;

/**
 * @author q766769
 *
 * very simple POJO class to de-serialize the Wingspan
 * response to a document upload request
 */
public class WsUploadJSONResponse implements WsJSONResponse
{
	public String message;
	public String version;
	public Data data;
	public Error[] errors;

	public static class Data
	{
		public String id;
		public String name;
		public String createdBy;
		public String createdDate;
		public String modifiedBy;
		public String modifiedDate;
		public String documentDate;
		public String documentLanguage;
		public String documentOwner;
		public String documentStatus;
		public String documentSubmitter;
		public String receiptDate;
		public String hardcopyIndicator;
		public String hasContent;
		public String isSignedOrSealed;
		public String restrictedContent;
		public String primaryContentType;
		public String source;
		public String sourceDescription;
		public String tmfItemDescription;
		public String tmfItemId;
		public String tmfItemType;
		public String refModelSubtype;
		public String tmfLevel;
		public String study;
		public String subject;
		public String organization;
		public String milestoneName;
		public String programCode;
		public Links links;
		public int scanPageCount;
		public int scanOcrConfidence;
	}

	public static class Links
	{
		public String qc;
		public String self;
		public String finalize;
		public String content;
		public String delete;
		public String commands;
		public String versions;
	}

	public static class Error
	{
		public String invalidValue;
		public String parameter;
		public String message;

		public String toString()
		{
			String msg;

			msg = String.format("%s - [ %s ]", message, parameter);
			if (invalidValue != null) {
				msg += " invalid value (" + invalidValue + ")";
			}
			return msg;
		}
	}

	// generic constructor
	public WsUploadJSONResponse()
	{
		// NOOP
	}

	// empty error response
	public WsUploadJSONResponse(String err)
	{
		message = err;
		errors = new Error[0];
	}

	@Override
	public String getMessage()
	{
		String completeMessage = "Wingspan: " + message;

		for (int k = 0; k < errors.length; ++k) {
			completeMessage += "\n" + errors[k].toString();
		}

		return completeMessage;
	}

	@Override
	public String getIid()
	{
		if (data != null) {
			return data.id;
		}
		return null;
	}
}

