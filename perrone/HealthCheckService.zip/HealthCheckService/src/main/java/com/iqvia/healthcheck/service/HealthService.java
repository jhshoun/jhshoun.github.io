package com.iqvia.healthcheck.service;

import com.iqvia.healthcheck.dao.JobMapper;
import com.iqvia.healthcheck.dao.StudyMapper;
import com.iqvia.healthcheck.dao.models.Job;
import com.iqvia.healthcheck.dao.models.Study;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HealthService
{
	private JobMapper jobber;
	private StudyMapper studier;

	@Autowired
	public HealthService(JobMapper jobMapper, StudyMapper studyMapper)
	{
		this.jobber = jobMapper;
		this.studier = studyMapper;
	}

	public List<Job> getAllJobs()
	{
		return jobber.getAll();
	}

	public List<Study> getAllStudies()
	{
		return studier.getAll();
	}

	public void setAllJobsFlag(String protocol, String allFlag)
	{

		studier.setAllJob(protocol, allFlag);
	}



}
