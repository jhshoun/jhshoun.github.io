package com.iqvia.healthcheck.batch.step;

import org.apache.ibatis.annotations.Param;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.iqvia.healthcheck.dao.DocumentMapper;
import com.iqvia.healthcheck.dao.DocumentMapper.ExportSearchParms;
import com.iqvia.healthcheck.dao.JobMapper;
import com.iqvia.healthcheck.dao.StudyMapper;
import com.iqvia.healthcheck.dao.models.DocExport;
import com.iqvia.healthcheck.dao.models.Document;
import com.iqvia.healthcheck.dao.models.Study;
import com.iqvia.healthcheck.service.Configure;
import com.iqvia.healthcheck.service.wingspan.WingspanClient2;

import com.iqvia.ElvisToEtmfTransformer;
import com.iqvia.PdfGenerator;
import com.iqvia.model.ElvisModel;
import com.iqvia.model.EtmfModel;

/**
 * (Spring Batch Tasklet)
 * 
 * takes the export document list and processes each document
 * as an individual record (typical process)
 *     1 - transform the IQVIA model to a Wingspan model
 *     2 - upload the document to the Wingspan workarea
 *     3 - finalize the document in Wingspan
 * 
 * if successful, the IID from Wingspan is recorded,
 * otherwise any error is tracked
 * 
 * this tasklet will be made 're-startable'
 * 
 * @author q766769
 *
 */
public class ExportProcessorTask  implements Tasklet, StepExecutionListener
{
	private Logger logger_ = LoggerFactory.getLogger(ExportProcessorTask.class);

	private static final int _document_cursor_fetch = 1000;
	private static final int _max_error_message = 1900;

	private Long jobid;
	private Study currentStudy;

	@Autowired
	private StudyMapper study;

	@Autowired
	private DocumentMapper doccer;

	@Autowired
	private JobMapper jobber;

	public ExportProcessorTask()
	{
		logger_.info("***** construct ExportProcessorTask <<<");
	}


	@Override
	public void beforeStep(StepExecution stepExecution)
	{

		jobid = stepExecution.getJobParameters().getLong("jobid");

		// remove header row from staging
		doccer.removeFromExportStaging(jobid, 0);

		// get the job type (is this initialize?)
		currentStudy = study.getByProtocol( 
						stepExecution.getJobParameters().getString("protocol")
					);

		// update the job status to transmitting
		jobber.setStatus(jobid, "TRANSMITTING");

		logger_.info( "/{}/ prep export table ({})", jobid, new Date());
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution)
	{
		logger_.debug("/{}/ upload processing complete ({})", jobid,  new Date());

		return ExitStatus.COMPLETED;
	}


	@Override
	public RepeatStatus execute(
								StepContribution contribution, 
								ChunkContext chunkContext
							) throws Exception
	{
		List<DocExport> docList;
		Document aDoc;

		docList = read();
		while (docList.size() > 0)
		{

			for (DocExport de : docList)
			{
				aDoc = transform(de);
				transfer(aDoc);
			}

			// get another batch of docs
			docList = read();
		}

//		return RepeatStatus.CONTINUABLE;
		return RepeatStatus.FINISHED;
	}

	/**
	 * retrieve a block of records from export list table
	 * 
	 * @return
	 */
	private List<DocExport> read()
	{
		List<DocExport> docList;
		ExportSearchParms parms;

		parms = new ExportSearchParms( jobid, _document_cursor_fetch, null );
		doccer.getSpoolDocsForJob( parms );
		docList = parms.p_result;

		logger_.debug("read {} export documents for job {}", docList.size(), jobid);
		return docList;
	}



	/**
	 * convert an export record back into a document object,
	 * remove the export record from the staging table
	 * 
	 * @return
	 */
	private Document transform(DocExport exDoc) throws IOException
	{
		Document transformed;

		// create TMF document from spooled CSV data
		transformed = exDoc.asDocument();
		logger_.debug("xform new doc: {}", transformed);

		// remove record from staging table
		doccer.removeFromExportStaging(exDoc.getJobId(), exDoc.getLineOrder());
		logger_.debug("stage item removed: job {} / item {}", exDoc.getJobId(), exDoc.getLineOrder());

		return transformed;
	}

	/**
	 * main routine to manage processing for a single document,
	 * the document is transformed and then uploaded to Wingspan;
	 * status is written to the export record
	 * 
	 * @param doc
	 * @return
	 * @throws InterruptedException
	 */
	private int transfer(Document doc) throws InterruptedException
	{
		EtmfModel wingDoc;
		PdfGenerator pdfGen = new PdfGenerator();
		String stubDoc;
		WingspanClient2 wc;
		WingspanClient2.Wing iid, fid;
		int rc = 0;
		String rstat = "";


		// generate stub document
		{
			int ret;

			stubDoc = String.format(
								Configure.getValueByName("wingspan.stub.path"),
								doc.getDataId() + ""
							);
			ret = pdfGen.generate( doc.getUrl(), stubDoc, Configure.getValueByName("wingspan.stub.header") );
			if (ret != 0) {
				this.setUploadStatus(doc.getDataId(), "", "SYSTEM", "could not create stub PDF file with URL");
				return -1;
			}
		}

		wc = new WingspanClient2();

		logger_.debug("start {} processing doc {} - {}", doc.getRecType(), doc.getDataId(), doc.getDocFullName());
		switch (doc.getRecType())
		{
			// new document
			case "UPLOAD":
				wingDoc = this.wsTransformer(doc);
				if (wingDoc == null) {
					rstat = "no XFORM";
					rc =  -1;
					break;
				}

				// if this job is 'INITIALIZE', then we set the propose-if-no-match
				// to true for every item
				if ( "I".equals( currentStudy.getAllJobYn( ) ) ) {
					wingDoc.setProposeStudyItemIfNoMatch( true );
				}

				iid = wc.uploadDocument(wingDoc, stubDoc);
				if ( iid.isGood() ) {

					fid = wc.finalizeDocument( iid.getIid() );
					if ( fid.isGood() ) {
						this.setUploadStatus(doc.getDataId(), iid.getIid(), "OK", "---");
						rstat = "OK";
					}
					else {
						this.setUploadStatus(doc.getDataId(), iid.getIid(), "MATCH", fid.getError());
						rstat = fid.getError();
					}
				}
				else {
					this.setUploadStatus(doc.getDataId(), "", "METADATA", iid.getError());
					rstat = iid.getError();
				}
				break;

			// existing document, deleted and then re-added
			case "UPDATE":

				// delete first
				if ( doc.hasWingId() ) {
					fid = wc.finalizeReset( doc.getWingspanId() );
					if ( !fid.isGood() ) {
						this.setUploadStatus(doc.getDataId(), 
													doc.getWingspanId(), 
													"SYSTEM", 
													"WINGSPAN API update delete/reset problem:" + fid.getError());
						rstat = fid.getError();
						rc =  -1;
						break;
					}
				}
				else {
					logger_.info("no Wingspan ID for doc {}, delete skipped", doc.getDataId());
				}

				// TODO did the reset fail because the object was already deleted?
				/*
					WINGSPAN API update delete/reset problem:API ERROR: WSPT_ORM_OBJECT_DOES_NOT_EXIST 
					ORM tmf_document object '1000553A000000000EF8DD49' does not exist in ORM Factory tmf.
				 */

				// reload second
				wingDoc = this.wsTransformer(doc);
				if (wingDoc == null) {
					rstat = "no XFORM";
					rc = -1;
					break;
				}

				iid = wc.uploadDocument(wingDoc, stubDoc);
				if ( iid.isGood() ) {

					fid = wc.finalizeDocument( iid.getIid() );
					if ( fid.isGood() ) {
						this.setUploadStatus(doc.getDataId(), iid.getIid(), "OK", " (update)");
						rstat = "OK";
					}
					else {
						this.setUploadStatus(doc.getDataId(), iid.getIid(), "MATCH", fid.getError());
						rstat = fid.getError();
					}
				}
				else {
					this.setUploadStatus(doc.getDataId(), "", "METADATA", iid.getError());
					rstat = iid.getError();
				}
				break;

			// existing document deleted
			case "DELETE":
				if ( doc.hasWingId() ) {
					fid = wc.finalizeReset( doc.getWingspanId() );
					if ( fid.isGood() ) {
						this.setUploadStatus(doc.getDataId(), "", "OK", "(deleted)");
						rstat = "OK";
					}
					else {
						this.setUploadStatus(doc.getDataId(), 
													doc.getWingspanId(), 
													"SYSTEM",
													"WINGSPAN API delete/reset problem: " + fid.getError());
						rstat = fid.getError();
					}
				}
				else {
					logger_.info("no Wingspan ID to delete for doc {}, delete skipped", doc.getDataId());
					rstat = "no wingspan ID for document";
				}
				break;

			default:
				rstat = "unknown action";
				this.setUploadStatus(doc.getDataId(), doc.getWingspanId(), "SYSTEM", "undefined rec type");
				logger_.error("unknown action type [{}] for doc {} - {}", 
									doc.getRecType(), doc.getDataId(), doc.getDocFullName());
		}
		logger_.debug("end process doc {} - {}", doc.getDataId(), rstat);

		// remove stub file
		try {
			(new File(stubDoc)).delete();
		}
		catch (Exception e) {
			// NOOP
			logger_.error("stub delete error", e);
		}

		return rc;
	}



	/**
	 * convert our ETMF model into a Wingspan model
	 * 
	 * Wingspan has created another ELVIS model so we have to 
	 * initialize it first and then call their transform
	 * 
	 */
	private EtmfModel wsTransformer(Document doc)
	{
		EtmfModel wingspanDoc;

		// convert our model to Wingspan and do the mapping
		// (only required for upload and update?)
		try {
			wingspanDoc = this.elvisDia2Wingspan( doc );
			if (wingspanDoc == null) {
				this.setUploadStatus(doc.getDataId(), doc.getWingspanId(), 
										"SYSTEM", "transform failed to generate Wingspan input");
				logger_.error("transform error document doc {} - {} \n{}", 
									doc.getDataId(), 
									doc.getDocFullName(), 
									"wingspan code"
								);
				return null;
			}
			if (wingspanDoc.getTmfItemId() == null) {
				this.setUploadStatus(doc.getDataId(), doc.getWingspanId(),
										"TRANSFORM", "no matching TMF_ITEM_ID");
				logger_.error("transform error [no tmf item id] doc {} - {}", 
									doc.getDataId(), 
									doc.getDocFullName() 
								);
				return null;
			}
		}
		catch (Exception e) {
			// Wingspan routine crashed
			this.setUploadStatus(doc.getDataId(), doc.getWingspanId(), 
										"SYSTEM", "transform process exception: " + e.getMessage());
			logger_.error("transform exception document doc {} - {} \n{}", 
								doc.getDataId(), 
								doc.getDocFullName(), 
								e.getMessage()
							);
			logger_.error("transform exception", e);
			return null;
		}

		return wingspanDoc;
	}


	/**
	 * convert our ETMF model into a Wingspan model
	 * 
	 * Wingspan has created another ELVIS model so we have to 
	 * initialize it first and then call their transform
	 * 
	 */
	private EtmfModel elvisDia2Wingspan(Document doc)
	{
		EtmfModel wingspan;
		ElvisModel elvis;
		ElvisToEtmfTransformer xformer;

		elvis = ExportProcessorTask.elvisDia2elvisWing(doc);

		// make magic
		xformer = new ElvisToEtmfTransformer();
		wingspan = xformer.transform( elvis );

		return wingspan;
	}


	/**
	 * convert our ETMF model into a "Wingspan ELVIS" model,
	 * (this is submitted to their transform engine)
	 */
	// TODO, this needs a home could be somewhere else - the logical
	//       place is the ELVIS or Wingspan POJO, but I don't want the 
	//       libraries cross-dependent
	public static ElvisModel elvisDia2elvisWing(Document doc)
	{
		String datePattern = "yyyy-MM-dd";
		SimpleDateFormat sdf = new SimpleDateFormat(datePattern);
		ElvisModel elvis;

		elvis = new ElvisModel();

		elvis.setProtocolNumber( doc.getProtocolNumber() );
		elvis.setCountry( doc.getCountry() );
		elvis.setSiteId( doc.getSiteId() );
		elvis.setDocumentLanguage( doc.getDocumentLanguage() );
		elvis.set_class( doc.getDocClass() );
		elvis.setZone( doc.getZone() );
		elvis.setSection( doc.getSection() );
		elvis.setArtifact( doc.getArtifact() );
		elvis.setDiaKey( doc.getDiaKey() );
		elvis.setAbbreviation( doc.getDocAbbreviation() );
		elvis.setDocumentDate( sdf.format( doc.getDocDate() ) );
		elvis.setCreatedDate( sdf.format( doc.getCreateDate() ) );
		elvis.setDocumentName( doc.getDocFullName() );
//		elvis.setComment("HC 2.0");
		elvis.setDataId( doc.getDataId().toString() );
		elvis.setUrl( doc.getUrl() );
		elvis.setDisposition( doc.getRecType() );
		elvis.setFirstName( doc.getFirstName() );
		elvis.setLastName( doc.getLastName());
		elvis.setUnblinded( doc.getIsUnblinded() );
		elvis.setInvestigatorName( doc.getInvestigatorName());
		elvis.setSiteName( doc.getSiteName() );
		elvis.setSponsor( doc.getSponsor() );
		elvis.setVisitDocumentID( doc.getVisitDocId() );
//		elvis.setDocumentId( doc.getWingspanId() );
		elvis.setLanguageIdentifier( doc.getLanguageIdentifier() );
		elvis.setVisitType( doc.getVisitType() );
		elvis.setVisitDocumentID( doc.getVisitDocId() );
		elvis.setProjectCode( doc.getProjectCode() );
		elvis.setCountryCode( doc.getCountryCode() );
		elvis.setLanguageAbbreviation( doc.getLanguageAbbreviation() );
		elvis.setOrganizationId( doc.getOrganizationId() );
		elvis.setDrugType( doc.getDrugType() );
		elvis.setReportVersion( doc.getReportVersion() );
		elvis.setEventIdentifier( doc.getEventIdentifier() );

		return elvis;
	}


	// wrapper for the DB call to check for large Wingspan error pages
	private void setUploadStatus(Long dataid, String iid, String errGroup, String response )
	{
		String status = response;

		if (status.length() > _max_error_message) {
			status = status.substring(0, _max_error_message);
		}
		doccer.setUploadStatus(dataid, iid, errGroup, status);
	}


}

