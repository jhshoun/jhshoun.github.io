package com.iqvia.healthcheck.service.wingspan;

import java.util.Date;

/**
 * @author q766769
 *
 * request to delete 1 or more documents from user
 * Wingspan workspace
 */
public class WsDeleteJSONResponse implements WsJSONResponse
{

	public String version;
	public String message;
	public int totalCount;
	public Data data;
	public Date timestamp;
	public String context;

	public static class Data
	{
		public Result[] results;
	}

	public static class Result
	{
		public String id;
		public boolean error;
		public String[] messages;
		public int elapsedMs;
	}

	@Override
	public String getMessage()
	{
		return message;
	}

	@Override
	public String getIid()
	{
		if (data != null && data.results != null && data.results.length > 0) {
			return data.results[0].id;
		}
		return null;
	}

}

