package com.iqvia.healthcheck.web.application;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

// IQVIA
import com.iqvia.ElvisToEtmfTransformer;
import com.iqvia.healthcheck.batch.step.ExportProcessorTask;
import com.iqvia.healthcheck.dao.DocumentMapper;
import com.iqvia.healthcheck.dao.models.Document;
import com.iqvia.healthcheck.service.api.BatchServiceController;
// Wingspan
import com.iqvia.model.ElvisModel;
import com.iqvia.model.EtmfModel;

@Controller
@RequestMapping(value= "/xformtest")
public class TestController
{
	private static final Logger logger_ = LoggerFactory.getLogger(TestController.class);

	@Autowired
	private DocumentMapper doccer;

	@RequestMapping(method= RequestMethod.GET)
	public String transformDocument(
						@RequestParam(value="did") Optional<Long> dataid,
						Model model )
	{
		ElvisToEtmfTransformer transformer;
		EtmfModel etmfObj = null;
		ElvisModel elvisObj;
		Document aDoc = null;

		if (dataid.isPresent() ) {

			aDoc = doccer.getDocById( dataid.get() );

			if (aDoc != null) {
				elvisObj = ExportProcessorTask.elvisDia2elvisWing( aDoc );

				transformer = new ElvisToEtmfTransformer();
				etmfObj = transformer.transform( elvisObj );
			}
		}

		aDoc = (aDoc == null) ? new Document() : aDoc;
		etmfObj = (etmfObj == null) ? new EtmfModel() : etmfObj;

		model.addAttribute("elvis", aDoc);
		model.addAttribute("etmf", etmfObj);

		return "transform";
	}

	/**
	 * automated testing off all transform rules in the mapping
	 * Excel document, reads the "VALIDATION" sponsor records
	 * from the export table
	 * 
	 * @return
	 */
	@RequestMapping(value= "/validation", method= RequestMethod.GET)
	public String transformDocument( Model model )
	{
		EtmfModel etmfObj = null;
		ElvisModel elvisObj;
		List<Document> docList = null;
		StringBuilder response;

		logger_.info("<< Excel Verify Run >>");

		response = new StringBuilder();

		// get all the docs in the validation list
		docList = doccer.getDocsByStudy("VAL101");
		for (Document aDoc : docList )
		{
			ElvisToEtmfTransformer xformer;
			xformer = new ElvisToEtmfTransformer();

			elvisObj = ExportProcessorTask.elvisDia2elvisWing( aDoc );
			etmfObj = xformer.transform( elvisObj );

			logger_.info("dataid {}: '{}' -> '{}'", 
							aDoc.getDataId(), aDoc.getExportReason(), etmfObj.getTmfItemId()
						);

			// compare the predicted and actual results
			if ( aDoc.getExportReason() == null ) {
				if ( etmfObj.getTmfItemId() != null ) {
					response.append( 
							"[" + aDoc.getDataId() + "]"
							+ " " + aDoc.getDocClass() + " > " 
									+ aDoc.getDiaKey() + " > " 
									+ aDoc.getArtifact() + " > " 
									+ aDoc.getDocAbbreviation()
							+ " ==>> expect: no map" 
							+ " -- got: " + etmfObj.getTmfItemId()
							+ "\r\n" 
						);
				}
			}
			else if ( !aDoc.getExportReason().equals( etmfObj.getTmfItemId() )) {
				response.append( 
							"[" + aDoc.getDataId() + "]"
							+ " " + aDoc.getDocClass() + " > " 
								+ aDoc.getDiaKey() + " > " 
								+ aDoc.getArtifact() + " > " 
								+ aDoc.getDocAbbreviation()
							+ " ==>> expect: " + aDoc.getExportReason() 
							+ " -- got: " + etmfObj.getTmfItemId()
							+ "\r\n" 
						);
			}
		}

		model.addAttribute("docList", "Start\r---------\r" + response + "\r---------\rEnd" );
		logger_.info("<< Verify Run End >>");


		return "validate";
	}


}
