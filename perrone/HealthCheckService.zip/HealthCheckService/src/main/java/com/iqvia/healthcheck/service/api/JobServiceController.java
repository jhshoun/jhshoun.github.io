package com.iqvia.healthcheck.service.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.iqvia.healthcheck.dao.models.Job;
import com.iqvia.healthcheck.service.HealthService;

@RestController
@RequestMapping(value = "/api")
public class JobServiceController
{

	@Autowired
	private HealthService healthService;

	@RequestMapping(method = RequestMethod.GET, value = "/jobs/")
	public List<Job> getAllJobs()
	{
		return this.healthService.getAllJobs();
	}

}
