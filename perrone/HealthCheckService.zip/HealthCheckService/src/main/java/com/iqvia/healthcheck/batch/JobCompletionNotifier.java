package com.iqvia.healthcheck.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iqvia.healthcheck.dao.JobMapper;

@Component
public class JobCompletionNotifier extends JobExecutionListenerSupport
{
	private static final Logger logger_ = LoggerFactory.getLogger(JobCompletionNotifier.class);

	@Autowired
	JobMapper jobber;

//	@Autowired
//	BatchServiceController batchService;

	@Override
	public void afterJob(JobExecution jobExecution)
	{
		Long jobid;
//		String mode;

		if ( jobExecution.getStatus() == BatchStatus.COMPLETED ) {

			jobid = jobExecution.getJobParameters().getLong("jobid");
			logger_.info("Job {} finished.", jobid);

			// update the job status in the database to complete
			jobber.setCompleted( jobid );

			// check and see if all-launch mode is in progress
			// if this was not a manual job -> then run the all
			// launch to start up the next job
//			mode = jobExecution.getJobParameters().getString("mode");
//			if (mode != null && "AUTO".equals( mode )) {
//				try {
//					String status;
//
//					status = batchService.startBatchRun();
//					logger_.info("launch new batch set: {}", status);
//				}
//				catch (Exception e) {
//					logger_.info("failed to start new batch group", e);
//				}
//			}
		}
	}
}
