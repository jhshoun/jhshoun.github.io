package com.iqvia.healthcheck.web.application;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.iqvia.healthcheck.dao.DocumentMapper;
import com.iqvia.healthcheck.dao.models.Document;
import com.iqvia.healthcheck.service.wingspan.WingspanClient2;
import com.iqvia.healthcheck.service.wingspan.WingspanClient2.Wing;
import com.iqvia.healthcheck.service.wingspan.WsDocumentJSONResponse;
import com.iqvia.healthcheck.service.wingspan.WsSingleDocJSONResponse;

import lombok.Getter;
import lombok.Setter;

@Controller
@RequestMapping(value = "/killkill")
public class DeleteController
{
	// Wingspan client connection
	WingspanClient2 wc2 = null;

	@Autowired
	private DocumentMapper doccer;

	@RequestMapping(method = RequestMethod.GET)
	public String deletePage(Model model)
	{

		model.addAttribute("command", new DeleteForm());
		return "deletelist";
	}

	@PostMapping("/die")
	public String docsForStudy(
						@ModelAttribute("command") DeleteForm form,
						Model model )
	{
		wc2 = new WingspanClient2();

		switch ( form.getScope() == null ? "null" : form.getScope() )
		{
			case "all":
				form.setIdList( documentKill(form.getStudy(), form.isWipeout()) );
				break;

			case "deleted":
				form.setIdList( deletedDupsDocs(form.getStudy(), "deleted", form.isWipeout()) );
				break;

			case "dups":
				form.setIdList( deletedDupsDocs(form.getStudy(), "duplicated", form.isWipeout()) );
				break;

			default:
				form.setIdList( "no scope" );
				// noop
		}

		model.addAttribute("command", form);
		return "deletelist";
	}

	// list all documents from the delete or duplicates table;
	// kill if requested
	private String deletedDupsDocs(String study, String source, boolean kill)
	{
		StringBuilder sb;
		List<Document> docs = null;

		sb = new StringBuilder();

		if (study != null && !study.isEmpty()) {

			if ("deleted".equals( source )) {
				docs = doccer.deleteDocList(study);
			}
			if ("duplicated".equals( source )) {
				docs = doccer.duplicateDocList(study);
			}

			for (Document doc : docs)
			{
				WsSingleDocJSONResponse aDoc;

				aDoc = wc2.singleDocument( doc.getWingspanId() );

				if (aDoc == null || aDoc.data == null) {
					sb.append( doc.getWingspanId() + " / " + doc.getDataId() + " - invalid IID\r");
					continue;
				}

				// kill if commanded
				if (kill) {
					killDoc(sb, aDoc.data.id, aDoc.data.name);
				}
				else {
					sb.append( doc.getWingspanId() + " / " + doc.getDataId() + " / " + aDoc.data.name + "\r");
				}
			}
			sb.append( docs.size() + " processed from " + source);
		}

		return sb.toString();
	}


	// process all the finalized docs in the study,
	// if kill is false, then just list results
	private String documentKill(String study, boolean kill)
	{
		WsDocumentJSONResponse jsonDocs;
		StringBuilder sb;

		sb = new StringBuilder();

		if (study != null && !study.isEmpty()) {

			jsonDocs = wc2.studyDocuments( study );

			for (WsDocumentJSONResponse.Data doc : jsonDocs.data)
			{
				if (kill) {
					killDoc(sb, doc.id, doc.name);
				}
				else {
					sb.append( doc.id + " / " + doc.tmfItemId + " / " + doc.name + "\r");
				}
			}
			sb.append( jsonDocs.data.length + " records");
		}

		return sb.toString();
	}

	// delete single WS doc and return details
	private void killDoc(StringBuilder sb, String id, String name)
	{
		Wing wing;

		sb.append( id + " " + name + " >>> ");

		wing = wc2.finalizeReset( id );

		sb.append( wing.isGood() ? "DELETED" : "ERR: " + wing.getError() );
		sb.append( "\r" );
	}

	/*
	 * model for the Thymeleaf Form
	 */
	@Getter @Setter
	public class DeleteForm
	{
		private String study;
		private String idList;
		private String scope;
		private boolean wipeout;
	}

}
