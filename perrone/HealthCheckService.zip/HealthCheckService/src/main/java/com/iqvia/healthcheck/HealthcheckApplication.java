package com.iqvia.healthcheck;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class HealthcheckApplication 
{
	private static ConfigurableApplicationContext ctx;

	public static void main(String[] args)
	{
		String option;

		// is this a shutdown call?
		option = (args != null && args.length > 0) ? args[0] : null;
		if ( "halt".equals( option )) {
			System.exit(0);
		}

		SpringApplication.run(HealthcheckApplication.class, args);
	}

	public static void exit(String[] args) throws InterruptedException
	{
		SpringApplication.exit( ctx );
		System.exit(0);
	}


}
