package com.iqvia.healthcheck.service.wingspan;

import java.util.Date;

/**
 * @author q766769
 *
 * request to delete document (all versions) and reset the 
 * associated placeholder
 */
public class WsResetJSONResponse implements WsJSONResponse
{

	public String version;
	public String messageID = "WS";
	public String message;
	public int totalCount;
	public Data data;
	public Date timestamp;
	public String context;

	public static class Data
	{
		public String id;
		public String name;
		public String sourceReference;
	}


	@Override
	public String getMessage()
	{
		return messageID + " " + message;
	}

	@Override
	public String getIid()
	{
		if (data != null) {
			return data.id;
		}
		return null;
	}

}

