package com.iqvia.healthcheck.dao.models;

import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class DocExport implements Serializable
{

	/** * */ private static final long serialVersionUID = -4098243539711314625L;

	private Long dataId;
	private Long jobId;
	private String fileName;
	private int lineOrder;
	private String csvLine;



	/**
	 * takes the CSV line and parses into respective fields,
	 * these are written into a new document object and returned
	 * @throws IOException 
	 * @throws ParseException 
	 */
	public Document asDocument() throws IOException
	{
		Document doc;
		CSVParser parser;
		CSVRecord row;
		List<CSVRecord> props;

		parser = CSVParser.parse(getCsvLine(), CSVFormat.EXCEL.withNullString(""));
		props = parser.getRecords();
		row = props.get(0);
		parser.close();

		// build the document
		doc = Document.builder()
						.dataId( Long.parseLong(row.get(0)) )
						.sponsor( row.get(1) )
						.protocolNumber( row.get(2) )
						.projectCode( row.get(3) )
						.country( row.get(4) )
						.countryCode( row.get(5) )
						.siteId( row.get(6) )
						.siteName( row.get(7) )
						.investigatorName( row.get(8) )
						.docClass( row.get(9) )
						.zone( row.get(10) )
						.section( row.get(11) )
						.artifact( row.get(12) )
						.diaKey( row.get(13) )
						.docAbbreviation( row.get(14) )
						.isUnblinded( row.get(15) )
						.docFullName( row.get(16) )
						.docDate( toDate( row.get(17) ) )
						.createDate( toDate( row.get(18) ) )
						.documentLanguage( row.get(19) )
						.languageAbbreviation( row.get(20) )
						.languageIdentifier( row.get(21) )
						.firstName( row.get(22) )
						.lastName( row.get(23) )
						.organizationId( row.get(24) )
						.drugType( row.get(25) )
						.visitType( row.get(26) )
						.visitDocId( row.get(27) )
						.reportVersion( row.get(28) )
						.eventIdentifier( row.get(29) )
						.url( row.get(30) )
						.recType( row.get(31) )
						.wingspanId( row.get(32) )
					.build();

//		"URL","Disposition","documentId"

		return doc;
	}

	private Date toDate(String sqlDate)
	{
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		try {
			return format.parse( sqlDate );
		}
		catch (ParseException e) {
			// TODO, need some logging here
			return null;
		}
	}
	
}
