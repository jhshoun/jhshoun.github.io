package com.iqvia.healthcheck.batch.step.process;

import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.ListIterator;

import org.slf4j.Logger;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;

import com.iqvia.healthcheck.dao.DocumentMapper;
import com.iqvia.healthcheck.dao.DocumentMapper.ExportSearchParms;
import com.iqvia.healthcheck.dao.JobMapper;
import com.iqvia.healthcheck.dao.models.DocExport;

/**
 * 
 * 
 * 
 * @author q766769
 *
 */
@SuppressWarnings("unused")
public class ExportItemProcessor implements ItemReader<DocExport>, ItemReadListener<DocExport>
{
	private Logger logger_ = LoggerFactory.getLogger(ExportItemProcessor.class);

	private List<DocExport> docList;
	private ListIterator<DocExport> docIterator;
	private Long jobid;
//	private int queuePosition;

	@Autowired
	private DocumentMapper docs;

	@Autowired
	private JobMapper jobs;


//	@Override
//	public void beforeStep(StepExecution stepExecution)
//	{
//		jobid = stepExecution.getJobParameters().getLong("jobid");
////		queuePosition = 0;
//
//		this.getDocumentSet( 0 ); //stepExecution.getExecutionContext(). );
//
//		// remove header row from staging
//		docs.removeFromExportStaging(jobid, 0L);
//
//		// update the job status to transmitting
//		jobs.setStatus(jobid, "TRANSMITTING");
//
//logger_.info( "/{}/", jobid );
//	}

	@Override
	public DocExport read() throws Exception, UnexpectedInputException,
									ParseException, NonTransientResourceException
	{
		DocExport docEx = null;

		// check the iterator, if empty try and get more
//		if ( !docIterator.hasNext() ) {
//			int count;

//			count = this.getDocumentSet();
//			if (count < 1) {
//				logger_.debug("end of spool for job {}", jobid);
//				return null;
//			}
//		}

		if ( docIterator.hasNext() ) {
			docEx = docIterator.next();
logger_.info( "/{}/", jobid );
			logger_.debug( "spooled doc {} #{}", docEx.getDataId(), docEx.getLineOrder() );
		}
//		else {
//			logger_.debug("end of spool for job {}", jobid);
//		}

		return docEx;
	}

//	@Override
//	public ExitStatus afterStep(StepExecution stepExecution)
//	{
//		// NOOP
//logger_.info( "/{}/", jobid );
//		return ExitStatus.COMPLETED;
////		ExitStatus.FAILED
//	}

	/**
	 * retrieve a block of records from the export staging
	 * table, the objects are then wrapped with an iterator
	 * and the doc count returned
	 * 
	 * if the table is empty, the iterator is NULL and the 
	 * count 0
	 * 
	 * @return
	 */
	private int getDocumentSet(int offset)
	{
		ExportSearchParms parms;

		parms = new ExportSearchParms( jobid, offset, null );
		docs.getSpoolDocsForJob( parms );
		docList = parms.p_result;
		docIterator = docList.listIterator();

//		queuePosition += docList.size();
		logger_.debug("read {} export documents for job {}", docList.size(), jobid);
		return docList.size();
	}

	@Override
	public void beforeRead()
	{
		// TODO Auto-generated method stub
logger_.info("before read ???  "  );
	}

	@Override
	public void afterRead(DocExport item)
	{
		// TODO Auto-generated method stub
logger_.info("after read {} {}", item.getJobId(), item.getLineOrder());
	}

	@Override
	public void onReadError(Exception ex)
	{
		// TODO Auto-generated method stub
		
	}

}

