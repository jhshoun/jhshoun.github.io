package com.iqvia.healthcheck.service.wingspan;

/**
 * @author q766769
 *
 * request to delete 1 or more documents from user
 * Wingspan workspace
 */
public class WsDeleteJSONRequest
{
	private String[] selectedIds;


	// generic constructor
	public WsDeleteJSONRequest()
	{
		// NOOP
	}

	public void setSelectedIds(String[] idList)
	{
		this.selectedIds = idList;
	}

	public void addSelectedId(String iid)
	{
		this.selectedIds = new String[] {iid};
	}

	public String[] getSelectedIds()
	{
		return this.selectedIds;
	}
}

