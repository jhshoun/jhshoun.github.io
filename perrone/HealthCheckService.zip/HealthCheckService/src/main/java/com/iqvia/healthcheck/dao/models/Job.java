package com.iqvia.healthcheck.dao.models;

import java.io.Serializable;
import java.sql.Date;

import lombok.Getter;
import lombok.Setter;

public class Job implements Serializable
{

	/** * */ private static final long serialVersionUID = -4167400680830535694L;

	@Getter @Setter
	private Long jobId;

	@Getter @Setter
	private Date jobCreated;

	@Getter @Setter
	private String jobStatus;

	@Getter @Setter
	private String jobType;

	@Getter @Setter
	private String jobParam;

	@Getter @Setter
	private int exportCount;

	@Override
	public String toString()
	{
		return getJobId() + ", " + getJobStatus() + ", " + getJobType();
	}
}
