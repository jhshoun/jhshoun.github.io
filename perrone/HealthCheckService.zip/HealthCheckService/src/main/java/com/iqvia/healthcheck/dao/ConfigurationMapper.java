package com.iqvia.healthcheck.dao;


import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.iqvia.healthcheck.dao.models.Configuration;

@Mapper
public interface ConfigurationMapper
{


	// get named configuration
	Configuration getByName(
					@Param("p_name") String name
				);

}
