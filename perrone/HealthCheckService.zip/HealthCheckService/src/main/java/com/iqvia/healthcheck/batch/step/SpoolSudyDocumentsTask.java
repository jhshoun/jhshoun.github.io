package com.iqvia.healthcheck.batch.step;

import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.util.Date;

import org.slf4j.Logger;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.iqvia.healthcheck.dao.JobMapper;

/**
 * (Spring Batch Tasklet)
 * 
 * generates the export record list for a study using 
 * the batch database package;
 * this step can take several hours to run based on the 
 * study size and number of documents to export
 * 
 * @author q766769
 *
 */
public class SpoolSudyDocumentsTask implements Tasklet, StepExecutionListener
{
	private Logger logger_ = LoggerFactory.getLogger(SpoolSudyDocumentsTask.class);

	private String sponsor;
	private String protocol;

	@Autowired
	private JobMapper jobber;

	public SpoolSudyDocumentsTask()
	{
		logger_.info("***** construct SpoolStudyDocumentsTask >>>");
	}

	@Override
	public void beforeStep(StepExecution stepExecution)
	{
		JobParameters parms;
		Long jobid;

		parms = stepExecution.getJobParameters();
		sponsor = parms.getString("sponsor");
		protocol = parms.getString("protocol");
		jobid = parms.getLong("jobid");

		// set up MDC (mapped diagnostic context) for logging by job
		MDC.put("jobId", jobid+"");

		logger_.debug("generating export spool for {}/{} ({})", sponsor, protocol, new Date());
	}

	@Override
	public RepeatStatus execute(StepContribution arg0, ChunkContext arg1)
																throws Exception
	{
		Long jobid = (Long) arg1.getStepContext().getJobParameters().get("jobid");

		jobber.expBatchJob(sponsor, protocol, jobid);
		logger_.debug("export HC job id: {}", jobid);
		return RepeatStatus.FINISHED;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution)
	{
		logger_.debug("HC export spool {} complete ({})", 
								stepExecution.getJobParameters().getLong("jobid"), 
								new Date()
							);

		return ExitStatus.COMPLETED;
	}

}

