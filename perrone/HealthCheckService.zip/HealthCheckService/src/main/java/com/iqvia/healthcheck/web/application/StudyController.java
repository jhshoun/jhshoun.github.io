package com.iqvia.healthcheck.web.application;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.iqvia.healthcheck.dao.models.Study;
import com.iqvia.healthcheck.service.HealthService;

@Controller
@RequestMapping(value="/studies")
public class StudyController
{

	@Autowired
	private HealthService healthService;

	@RequestMapping(method= RequestMethod.GET)
	public String getAllStudies(Model model)
	{
		List<Study> studyList;

		studyList = this.healthService.getAllStudies();
		model.addAttribute("studies", studyList);
		return "studylist";
	}

}
