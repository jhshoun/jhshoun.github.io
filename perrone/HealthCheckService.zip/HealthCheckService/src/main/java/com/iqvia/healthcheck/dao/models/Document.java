package com.iqvia.healthcheck.dao.models;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Document implements Serializable
{

	/** * */
	private static final long serialVersionUID = -3135089497804785773L;

	private Long dataId;
	private String sponsor;
	private String protocolNumber;
	private String projectCode;
	private String country;
	private String countryCode;
	private String siteId;
	private String siteName;
	private String investigatorName;
	private String docClass;
	private String zone;
	private String section;
	private String artifact;
	private String diaKey;
	private String docAbbreviation;
	private String isUnblinded;
	private String docFullName;
	private Date docDate;
	private Date createDate;
	private String documentLanguage;
	private String languageAbbreviation;
	private String languageIdentifier;
	private String firstName;
	private String lastName;
	private String organizationId;
	private String drugType;
	private String visitType;
	private String visitDocId;
	private String reportVersion;
	private String eventIdentifier;
	private String url;
	private String recType;
	private Date lastExpDate;
	private Date lastUpdDate;
	private String wingspanId;
	private String wingspanResponse;
	private String errGroup;
	private Long parentId;
	private Long projectDataId;
	private int exportId;
	private String exportReason;

	
	
//	@Builder
//	public Document()
//	{
//		// noop
//	}

	@Override
	public String toString()
	{
		String nameFormat = "[%d] %s (%s - %s) %s";

		return String.format(
						nameFormat, 
						getDataId(), getDiaKey(), 
						getSponsor(), getProtocolNumber(),
						getDocFullName() 
					);
	}

	// utility to verify we have a Wingspan ID
	public boolean hasWingId()
	{
		if (wingspanId == null) {
			return false;
		}
		if ( "".equals( wingspanId ) ) {
			return false;
		}
		return true;
	}
	

	

}
