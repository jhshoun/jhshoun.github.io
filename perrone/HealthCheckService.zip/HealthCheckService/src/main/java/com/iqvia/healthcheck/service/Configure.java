package com.iqvia.healthcheck.service;

import com.iqvia.healthcheck.SpringContext;
import com.iqvia.healthcheck.dao.ConfigurationMapper;

/**
 * simple class to get the configuration mapper from the
 * context and then provide values as requested
 * 
 * @author q766769
 *
 */
public class Configure
{

	private static final ConfigurationMapper cfg;


	// access the context to get database mapper
	static {
		cfg = SpringContext.getBean(ConfigurationMapper.class);
	}

	public static String getValueByName(String cfgName)
	{
		return cfg.getByName( cfgName ).getVarValue();
	}



}
