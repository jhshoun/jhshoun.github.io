package com.iqvia.healthcheck.batch.step.process;

import org.slf4j.LoggerFactory;

import java.util.List;

import org.slf4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.iqvia.healthcheck.dao.DocumentMapper;
import com.iqvia.healthcheck.dao.models.Document;

/**
 * upload the Wingspan document, finalizes if there the upload
 * is successful, return with the URL and status
 * 
 * @author q766769
 *
 */
@SuppressWarnings("unused")
public class DocUploadItemProcessor implements ItemWriter<Document>, ItemWriteListener<Document>
{
	private Logger logger_ = LoggerFactory.getLogger(DocUploadItemProcessor.class);

	@Autowired
	private DocumentMapper doccer;

//	private Long jobid;

	@Override
	public void write(List<? extends Document> docs) throws Exception
	{


		// TODO, implement upload logic
		// will call the Wingspan provided libraries
		for (Document d : docs)
		{

			// TODO
			// jobs can be 'regular' or 'initialize'
			// regular - distinguish between tracked in placeholders and ad hoc submissions
			// initialize - all docs treated as ad hoc (match and create placeholder)



			// TODO need to find the class for a Wingspan object
			// convert our model to Wingspan and do the mapping
			// (only required for upload and update?)
			if (1 == 0) {
				logger_.error("transform error document doc {} - {} \n{}", 
						d.getDataId(), d.getDocFullName(), "winspan code");
				continue;
			}

			switch (d.getRecType())
			{
				case "UPLOAD":
					doccer.setUploadStatus(d.getDataId(), "1000314600000000003B4EC7", "okie dokie", "---");
					break;

				case "UPDATE":
					doccer.setUploadStatus(d.getDataId(), "1000314600000000003B4EC7", "again", "---");
					break;

				case "DELETE":
					doccer.setUploadStatus(d.getDataId(), "", "deleted", "---");
					break;

				default:
					doccer.setUploadStatus(d.getDataId(), "", "invalid action type", "---");
					logger_.error("unknown action type [{}] for doc {} - {}", 
									d.getRecType(), d.getDataId(), d.getDocFullName());
			}

			// remove record from staging table
//			doccer.removeFromExportStaging(jobid, d.getDataId());

			logger_.debug("processed doc {} - {}", d.getDataId(), d.getDocFullName());

//Thread.sleep(30000);
Thread.sleep(1600);

		}

	}

//	@Override
//	public void beforeStep(StepExecution stepExecution)
//	{
////		jobid = stepExecution.getJobParameters().getLong("jobid");
//	}

//	@Override
//	public ExitStatus afterStep(StepExecution stepExecution)
//	{
//		// NOOP
//		return ExitStatus.COMPLETED;
//	}

	@SuppressWarnings("rawtypes")
	@Override
	public void beforeWrite(List items)
	{
		// TODO Auto-generated method stub
	}

	@SuppressWarnings("rawtypes")
	@Override
	public void afterWrite(List items)
	{
		// TODO Auto-generated method stub
	}

	@SuppressWarnings("rawtypes")
	@Override
	public void onWriteError(Exception exception, List items)
	{
		// NOOP
	}

}

