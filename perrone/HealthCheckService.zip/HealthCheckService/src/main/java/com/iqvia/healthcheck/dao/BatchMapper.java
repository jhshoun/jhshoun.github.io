package com.iqvia.healthcheck.dao;


import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import com.iqvia.healthcheck.dao.models.Job;

@Mapper
public interface BatchMapper
{

	// get details for a single job
	Job findById(
					@Param("jobid") Long job
				);

	// get all batch runs (instance and execution details)
	@SuppressWarnings("rawtypes")
	List<Map> getAll( );

}
