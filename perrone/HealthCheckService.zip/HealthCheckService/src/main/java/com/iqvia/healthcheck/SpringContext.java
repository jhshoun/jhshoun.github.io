package com.iqvia.healthcheck;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

@Component
public class SpringContext implements ApplicationContextAware
{
	private static ApplicationContext ctx;

	/**
	 * returns the Spring managed bean instance of the given class type (if it exists),
	 * otherwise returns NULL
	 * @param beanClass
	 * @return 'a bean' or null
	 */
	public static <T extends Object> T getBean(Class<T> beanClass)
	{
		return ctx.getBean(beanClass);
	}

	@Override
	public void setApplicationContext(ApplicationContext ctx) throws BeansException
	{
		// store ApplicationContext reference to access beans later
		SpringContext.ctx = ctx;
	}

}

