package com.iqvia.healthcheck.service.wingspan;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.DatatypeConverter;

import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.glassfish.jersey.media.multipart.file.FileDataBodyPart;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import com.iqvia.healthcheck.SpringContext;
import com.iqvia.healthcheck.dao.ConfigurationMapper;
import com.iqvia.model.EtmfModel;

import lombok.Getter;
import lombok.Setter;



/**
 * Client to the Wingspan cloud TMF provider;
 * this supports the TMF health system
 * 
 * Documents are uploaded, updated, and deleted
 * <p/>
 * @author q766769
 */
public class WingspanClient2
{
	private static Logger logger_ = LoggerFactory.getLogger(WingspanClient2.class);

	private static final String user;
	private static final String password;
	private static final String server;
//	private String host;
	private static final String pathUpload;
	private static final String pathFinalize;
	private static final String pathDeleteReset;
	private static final String pathWorkspaceDelete;

	static {
		ConfigurationMapper cfg = SpringContext.getBean(ConfigurationMapper.class);

		user = cfg.getByName( "wingspan.user" ).getVarValue();
		password = cfg.getByName( "wingspan.password" ).getVarValue();
		server = cfg.getByName( "wingspan.server" ).getVarValue();
		pathUpload = cfg.getByName( "wingspan.path.upload" ).getVarValue();
		pathFinalize = cfg.getByName( "wingspan.path.finalize" ).getVarValue();
		pathDeleteReset = cfg.getByName( "wingspan.path.delete_reset" ).getVarValue();
		pathWorkspaceDelete = cfg.getByName( "wingspan.path.workspace_delete" ).getVarValue();
	}

	/**
	 * Constructors to define service connection,
	 * this one extracts the configuration constants for the request
	 */
	public WingspanClient2()
	{
		// noop
	}


	/**
	 * uses Wingspan REST service to upload file to work area,
	 * uses the model provided by Wingspan
	 * 
	 * upload (POST) a document to the work area
	 * 
	 * @param   ETMF Model (Wingspan)
	 * @param 	file stub document
	 * @return 	Wingspan reference,
	 *             chronicle document ID or 'ERROR Wingspan:" message
	 */
	public Wing uploadDocument(EtmfModel doc, String stubFileName )
	{
		Wing xwing;
		long t1, t2;                // request timing

		// -------------------------------------------------
		// REST API components
		// -------------------------------------------------
		FormDataMultiPart multiForm;
		Response response = null;
		Client client;
		WebTarget target;
		FileDataBodyPart filePart;
		FormDataMultiPart multiPart;
		Entity<FormDataMultiPart> requestEntity;
		RestJSON<WsUploadJSONResponse> json;

		// copy model attributes to submission form
		multiForm = new FormDataMultiPart();
		multiForm.setMediaType(MediaType.MULTIPART_FORM_DATA_TYPE);
		fillAttributes(doc, multiForm);

		// build and invoke the REST request
		client = ClientBuilder
					.newBuilder()
					.register(MultiPartFeature.class)
					.property(ClientProperties.SUPPRESS_HTTP_COMPLIANCE_VALIDATION, true)
					.build();

		target = client.target( server );

		try {
			// assemble the form and file parts
			filePart = new FileDataBodyPart("file", new File(stubFileName) );
			multiPart = (FormDataMultiPart) multiForm.bodyPart(filePart);
			requestEntity = Entity.entity(multiPart, multiPart.getMediaType());

			t1 = System.currentTimeMillis();
			response = target
							.path( pathUpload )
							.request(MediaType.APPLICATION_JSON)
							.header("Authorization", authHeader())
//							.header("Host", host)
							.post( requestEntity );
			t2 = System.currentTimeMillis();
			logger_.info("REST {}, executed {} mSec, response {}", pathUpload, t2 - t1, response.getStatus());

			multiForm.close();
			multiPart.close();

			// decode and process the response
			json = new RestJSON<WsUploadJSONResponse>( WsUploadJSONResponse.class );
			xwing = json.xlateResponse("workarea upload", response);
		}
		catch (Exception e) {
			logger_.error("wingspan upload error", e);
			xwing = new Wing(false, "UPLOAD ERR: exception " + e.toString() + " - " + e.getMessage());
		}

		return xwing;
	}


	/**
	 * uses Wingspan REST service to 
	 * finalize (PUT) a document to the work area
	 * 
	 * @param   chronicle ID
	 * @return 	Wingspan reference,
	 *             chronicle document ID or 'ERROR Wingspan:" message
	 */
	public Wing finalizeDocument(String iid)
	{
		Wing xwing;
		long t1, t2;                // request timing

		// -------------------------------------------------
		// REST API components
		// -------------------------------------------------
		Response response = null;
		Client client;
		WebTarget target;
		RestJSON<WsUploadJSONResponse> json;

		// build and invoke the REST request
		client = ClientBuilder
					.newBuilder()
					.property(ClientProperties.SUPPRESS_HTTP_COMPLIANCE_VALIDATION, true)
					.build();

		target = client.target( server );

		try {

			// submit the PUT request

			t1 = System.currentTimeMillis();
			response = target
							.path( pathFinalize )
							.resolveTemplate("id", iid)
							.request(MediaType.APPLICATION_JSON)
							.header("Authorization", authHeader())
							.put( Entity.json(null) );
			t2 = System.currentTimeMillis();
			logger_.info("REST {}, executed {} mSec, response {}", pathFinalize, t2 - t1, response.getStatus());

			// decode and process the response
			json = new RestJSON<WsUploadJSONResponse>( WsUploadJSONResponse.class );
			xwing = json.xlateResponse("qc finalize", response);
		}
		catch (Exception e) {
			logger_.error("wingspan upload error", e);
			xwing = new Wing(false, "FINALIZE ERR: exception " + e.toString() + " - " + e.getMessage());
		}

		return xwing;
	}



	/**
	 * uses Wingspan private REST service to 
	 * delete a document from the user work area
	 * 
	 * @param   chronicle ID
	 * @return 	return Wing with code and possible err text
	 */
	public Wing workareaDelete(String iid)
	{
		Wing xwing;
		long t1, t2;                // request timing

		// -------------------------------------------------
		// REST API components
		// -------------------------------------------------
		Response response = null;
		Client client;
		WebTarget target;
		WsDeleteJSONRequest deleteReq;
		RestJSON<WsDeleteJSONResponse> json;

		// build and invoke the REST request
		client = ClientBuilder
					.newBuilder()
					.property(ClientProperties.SUPPRESS_HTTP_COMPLIANCE_VALIDATION, true)
					.build();

		target = client.target( server );

		try {

			deleteReq = new WsDeleteJSONRequest();
			deleteReq.addSelectedId( iid );

			// submit the POST request
			t1 = System.currentTimeMillis();
			response = target
							.path( pathWorkspaceDelete )
							.request(MediaType.APPLICATION_JSON)
							.header("Authorization", authHeader())
							.post( Entity.json(deleteReq) );
			t2 = System.currentTimeMillis();
			logger_.info("REST {}, executed {} mSec, response {}", pathWorkspaceDelete, t2 - t1, response.getStatus());

			// decode and process the response
			json = new RestJSON<WsDeleteJSONResponse>( WsDeleteJSONResponse.class );
			xwing = json.xlateResponse("workspace delete", response);

// let's see if we need to do something here
//			wing = new Wing(true, "document " + iid + " deleted");
		}
		catch (Exception e) {
			logger_.error("wingspan upload error", e);
			xwing = new Wing(false, "WORKSPACE DELETE ERR: exception " + e.toString() + " - " + e.getMessage());
		}

		return xwing;
	}


	/**
	 * uses Wingspan REST service to delete a
	 * finalized document and reset the study item
	 * 
	 * @param   chronicle ID
	 * @return 	return Wing with code and possible err text
	 */
	public Wing finalizeReset(String iid)
	{
		Wing xwing;
		long t1, t2;                // request timing

		// -------------------------------------------------
		// REST API components
		// -------------------------------------------------
		Response response = null;
		Client client;
		WebTarget target;
		RestJSON<WsResetJSONResponse> json;

		// build and invoke the REST request
		client = ClientBuilder
					.newBuilder()
					.property(ClientProperties.SUPPRESS_HTTP_COMPLIANCE_VALIDATION, true)
					.build();

		target = client.target( server );

		try {

			// submit the POST request
			t1 = System.currentTimeMillis();
			response = target
							.path( pathDeleteReset )
							.resolveTemplate("id", iid)
							.request(MediaType.APPLICATION_JSON)
							.header("Authorization", authHeader())
							.delete();
			t2 = System.currentTimeMillis();
			logger_.info("REST {}, executed {} mSec, response {}", pathWorkspaceDelete, t2 - t1, response.getStatus());

			// decode and process the response
			json = new RestJSON<WsResetJSONResponse>( WsResetJSONResponse.class );
			xwing = json.xlateResponse("finalize delete and reset", response);

// let's see if we need to do something here
// wing = new Wing(true, "document " + iid + " deleted");
		}
		catch (Exception e) {
			logger_.error("wingspan upload error", e);
			xwing = new Wing(false, "finalize delete & resetR: exception " + e.toString() + " - " + e.getMessage());
		}

		return xwing;
	}



	/**
	 * uses Wingspan REST service to 
	 * list all documents for a study
	 * 
	 * @param   Wingspan study identifier
	 * @return 	JSON response
	 */
	public WsDocumentJSONResponse studyDocuments(String study)
	{
		long t1, t2;                // request timing

		// -------------------------------------------------
		// REST API components
		// -------------------------------------------------
		Response response = null;
		Client client;
		WebTarget target;
		RestJSON<WsDocumentJSONResponse> json;

		// build and invoke the REST request
		client = ClientBuilder
					.newBuilder()
					.property(ClientProperties.SUPPRESS_HTTP_COMPLIANCE_VALIDATION, true)
					.build();

		target = client.target( server );

		try {

			// submit the PUT request

			t1 = System.currentTimeMillis();
			response = target
							.path( "/api/v1/documents" )
							.queryParam("study", study)
							.request(MediaType.APPLICATION_JSON)
							.header("Authorization", authHeader())
							.get();
			t2 = System.currentTimeMillis();
			logger_.info("REST {}, executed {} mSec, response {}", pathUpload, t2 - t1, response.getStatus());

			// decode and process the response
			json = new RestJSON<WsDocumentJSONResponse>( WsDocumentJSONResponse.class );
			json.xlateResponse("get docs for study", response);

			return json.getJson();
		}
		catch (Exception e) {
			logger_.error("wingspan document search error", e);
		}

		return null;
	}


	/**
	 * uses Wingspan REST service to get details for a single document
	 * 
	 * @param   Wingspan document identifier
	 * @return 	JSON response
	 */
	public WsSingleDocJSONResponse singleDocument(String iid)
	{
		long t1, t2;                // request timing

		// -------------------------------------------------
		// REST API components
		// -------------------------------------------------
		Response response = null;
		Client client;
		WebTarget target;
		RestJSON<WsSingleDocJSONResponse> json;

		// build and invoke the REST request
		client = ClientBuilder
					.newBuilder()
					.property(ClientProperties.SUPPRESS_HTTP_COMPLIANCE_VALIDATION, true)
					.build();

		target = client.target( server );

		try {

			// submit the PUT request

			t1 = System.currentTimeMillis();
			response = target
							.path( "/api/v1/documents" )
							.path( iid )
							.request(MediaType.APPLICATION_JSON)
							.header("Authorization", authHeader())
							.get();
			t2 = System.currentTimeMillis();
			logger_.info("REST {}, executed {} mSec, response {}", pathUpload, t2 - t1, response.getStatus());

			// decode and process the response
			json = new RestJSON<WsSingleDocJSONResponse>( WsSingleDocJSONResponse.class );
			json.xlateResponse("get document by iid", response);

			return json.getJson();
		}
		catch (Exception e) {
			logger_.error("wingspan document iid lookup error", e);
		}

		return null;
	}



	/**
	 * generic class to take the REST API response text and 
	 * generate the appropriate Wingspan JSON object, 
	 * determines the response status
	 */
	final class RestJSON<T extends WsJSONResponse>
	{
		private final Class<T> typeClass;
		private T lookup = null;

		public RestJSON(Class<T> typeParmClass)
		{
			this.typeClass = typeParmClass;
		}

		public T getJson()
		{
			return lookup;
		}

		public Wing xlateResponse(String function, Response apiResp)
		{
			Wing wingResp = null;
			String responseText;

			// get the response content
			responseText = apiResp.readEntity(String.class);

			if (apiResp.getStatus() == 500) {
				logger_.error("{} server error: {}", function, responseText);
				wingResp = new Wing(
								false,
								String.format("Internal Server Error (%s): %s", function, responseText)
							);
			}
			else {
				try {
					lookup = new Gson().fromJson(responseText, typeClass);
				}
				catch (JsonSyntaxException jse) {
					logger_.error("{} response error: {}", function, responseText);
					wingResp = new Wing(
									false, 
									String.format("Failed %s response: %s", function, responseText)
								);
				}
			}

			// HTTP success
			if (apiResp.getStatus() == 200) {
				wingResp = new Wing( lookup.getIid() );
				wingResp.setGood( true );
			}
			// HTTP request fail
			else {
				// was an earlier response created?
				if (wingResp == null) {
					if (lookup != null) {
						wingResp = new Wing(false, "API ERROR: " + lookup.getMessage());
						wingResp.setIid( lookup.getIid() );
					}
					else {
						wingResp = new Wing(false, "API ERROR: unknown code " 
											+ apiResp.getStatus() + " " 
											+ apiResp.getStatusInfo());
					}
				}
			}

			return wingResp;
		}

	}

	/**
	 * generate WS authentication header
	 * <p/>
	 */
	private String authHeader()
	{
		String authHeader = "Basic ";
		byte[] uid_pw = (user + ":" + password).getBytes();

		authHeader += DatatypeConverter.printBase64Binary( uid_pw );
		return authHeader;
	}


	// copy the model fields into the rest request
	private void fillAttributes(EtmfModel doc, FormDataMultiPart form) 
	{

		addField(form, "study", doc.getStudy());
		addField(form, "tmfItemId", doc.getTmfItemId());
		addField(form, "country", doc.getCountry());
		addField(form, "site", doc.getSite());
		addField(form, "proposeStudyItemIfNoMatch", doc.getProposeStudyItemIfNoMatch());
		addField(form, "proposedOrganization", doc.getProposedOrganization());
		addField(form, "documentDate", doc.getDocumentDate());
		addField(form, "documentLanguage", doc.getDocumentLanguage());
		addField(form, "documentOwner", doc.getDocumentOwner());
		addField(form, "documentSubmitter", doc.getDocumentSubmitter());
		addField(form, "documentSubject", doc.getSubject() );
		addField(form, "receiptDate", doc.getReceiptDate());
		addField(form, "expirationDate", doc.getExpirationDate());
		addField(form, "additionalInformation", doc.getAdditionalInformation());
		addField(form, "financialInterestDisclosed", doc.getFinancialInterestDisclosed());
		addField(form, "partOfIIP", doc.getPartOfIIP());
		addField(form, "unblindedDocument", doc.getUnblindedDocument());
		addField(form, "source", doc.getSource());
		addField(form, "sourceDescription", doc.getSourceDescription());
		addField(form, "sourceOrigin", doc.getSourceOrigin());
		addField(form, "sourceReference", doc.getSourceReference());
		addField(form, "hardcopyIndicator", doc.getHardcopyIndicator());
		addField(form, "scanComments", doc.getScanComments());
		addField(form, "scanCenterReceiptDate", doc.getScanCenterReceiptDate());
		addField(form, "scanDate", doc.getScanDate());
		addField(form, "scanOperator", doc.getScanOperator());
		addField(form, "scanLocation", doc.getScanLocation());
		addField(form, "scanDevice", doc.getScanDevice());
		addField(form, "scanBatchName", doc.getScanBatchName());
		addField(form, "scanTransmittalNumber", doc.getScanTransmittalNumber());
		addField(form, "scanTransmittalDocNumber", doc.getScanTransmittalDocNumber());
		addField(form, "scanTransmittalBarcodeId", doc.getScanTransmittalBarcodeId());
		addField(form, "scanBarcodeId", doc.getScanBarcodeId());
		addField(form, "scanPageCount", doc.getScanPageCount());
		addField(form, "scanOcrConfidence", doc.getScanOcrConfidence());
		addField(form, "scanTeam", doc.getScanTeam());
		addField(form, "scanSubteam", doc.getScanSubteam());

		addField(form, "expiresAtEndOfStudy", doc.getExpiresAtEndOfStudy());
		addField(form, "meetingType", doc.getMeetingType());
		addField(form, "investigationalProductId", doc.getInvestigationalProductId());
		addField(form, "sitePersonnelName", doc.getSitePersonnelName());
		addField(form, "financialInterestDisclosed", doc.getFinancialInterestDisclosed());
		addField(form, "translationType", doc.getTranslationType());
		addField(form, "refModelSubtype", doc.getRefModelSubtype());
		addField(form, "vendorName", doc.getVendorName());
		addField(form, "amendmentNumber", doc.getAmendmentNumber());

//		private String workareaAction;
//	    private String program;
//	    private String documentLevel;
//	    private String documentId;
//	    private Boolean financialInterestUndisclosed;
//	    private String financialInterest;

	}

	// add field to multi-part form, but skip if the input is null
	private void addField(FormDataMultiPart form, String field, Object value)
	{
		// do we have a value?
		if (value == null) {
			return;
		}

		// strings
		if (value instanceof String) {
			String v = (String) value;

			if ( !v.isEmpty() ) {

				// if this a 'stringy' date, then truncate 
				// ( 2017-12-12T00:00:00.000-05:00 )
				if ( v.matches( ".*T00:00:00.*" ) ) {
					v = v.substring(0, 10);
				}
				addField(form, field, v, 2000);
			}
			return;
		}

		// dates
		if (value instanceof Date) {
			Date v = (Date) value;
			SimpleDateFormat ymd = new SimpleDateFormat("yyyy-MM-dd");

			form.field(field, ymd.format(v));
			return;
		}

		// integers, booleans, numbers
		if (value instanceof Integer) {
			Integer v = (Integer) value;

			form.field(field, v.toString());
			return;
		}
		if (value instanceof Boolean) {
			Boolean v = (Boolean) value;

			form.field(field, v.toString());
			return;
		}
		if (value instanceof Number) {
			Number v = (Number) value;

			form.field(field, v.toString());
			return;
		}

	}


	// add field with a limit on the max text length
	private void addField(FormDataMultiPart form, String field, String value, int limit)
	{
		String truncValue = value;

		if (value.length() > limit) {
			truncValue = value.substring(0, limit-1);
		}

		form.field(field, truncValue);
	}


	// utility to check for NULL or empty variable
	@SuppressWarnings("unused")
	private boolean isArg(String s)
	{
		if (s == null) {
			return false;
		}
		if (s.isEmpty()) {
			return false;
		}
		return true;
	}


	/**
	 * Wingspan return value
	 * shows the status of the request, document id, and
	 * any error details
	 */
	@Getter
	@Setter
	public class Wing
	{
		private boolean good = false;
		private String iid;
		private String error;

		Wing()
		{
			// empty constructor
		}

		Wing(String wingspanId)
		{
			this.good = true;
			this.iid = wingspanId;
		}

		Wing(boolean status, String message)
		{
			this.good = status;
			this.error = message;
		}
	}


}
