

// UI API operations
function setStudyFlag(event)
{
	var parms = {};
	var options;

	parms["all"] = event.value;

	$.post(
			"/api/studies/" + event.getAttribute('study-id'),
			parms
		);
}

function startSingleExport(event)
{
	var parms = {};
	var options;

	parms["sponsor"] = event.getAttribute('sponsor');
	parms["protocol"] = event.getAttribute('protocol');

	$.get(
			"/api/batch/run/study",
			parms,
			function(data)
			{
				alert(data);
			}

		);
}

function startBulkRun(event)
{
	var parms = {};
	var options;

	$.get(
			"/api/batch/run/all",
			parms,
			function(data)
			{
				alert(data);
			}

		);
}



// trigger the ELVIS to Wingspan transform
function runXform()
{
	var action_root = "/xformtest?id=";
	var xform;

	xform = $("#didForm");
	xform.attr("action", action_root + $("#did").val());
	xform.submit();
}




function getRequestParam(p)
{
	return (window.location.search.match(new RegExp('[?&]' + p + '=([^&]+)')) || [, null])[1];
}


function setup()
{
	// disable AJAX GET() cache
	$.ajaxSetup(
				{ cache: false }
			);

}

$(document).ready( setup );

