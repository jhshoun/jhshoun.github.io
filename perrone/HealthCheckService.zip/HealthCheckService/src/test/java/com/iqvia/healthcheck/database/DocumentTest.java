package com.iqvia.healthcheck.database;

import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.iqvia.healthcheck.dao.DocumentMapper;
import com.iqvia.healthcheck.dao.models.DocExport;
import com.iqvia.healthcheck.dao.models.Document;

@RunWith(SpringRunner.class)
@MybatisTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("dev")
public class DocumentTest
{

	@Autowired
	private DocumentMapper doccer;

	@Test
	public void getOneDocument()
	{
		Document doc;

		doc = doccer.getDocById( 2000L );
		assertTrue( doc.getDocFullName().equals("Test-Doc-John-DO_NOT_DELETE") );
		assertTrue( doc.getSponsor().equals("SHOUN") );
		assertTrue( doc.getProtocolNumber().equals("JOHN-MEDS") );
		assertTrue( doc.getDiaKey().equals("01.01.01") );

	}


	@Test
	public void getExportDocs() throws IOException
	{
		List<DocExport> docs = null;
		Document aDoc;
		DocumentMapper.ExportSearchParms parms;

		parms = new DocumentMapper.ExportSearchParms(1L, 1000, null);
		doccer.getSpoolDocsForJob( parms );
		docs = parms.p_result;

		System.out.println( docs.size() + " docs were spooled");
		assertTrue( docs.size() > 0 );

		// see if the csv record will transform
		aDoc = docs.get(0).asDocument();
		assertTrue( "SHOUN".equals( aDoc.getSponsor() ) );

	}


	@Test
	public void removeDocFromQueue() throws IOException
	{

		doccer.removeFromExportStaging(545L, 10);
		assertTrue( true );
	}

	@Test
	public void updateTheExportStatus() throws IOException
	{
		Document aDoc;

		doccer.setUploadStatus(2000L, "1000314600000000001B3D5F", "N/A", "hunky dory");

		aDoc = doccer.getDocById( 2000L );
		assertTrue( aDoc.getDocFullName().equals("Test-Doc-John-DO_NOT_DELETE") );
		assertTrue( aDoc.getWingspanId().length() > 15 );
		assertTrue( aDoc.getWingspanResponse().length() > 5 );
		assertTrue( aDoc.getErrGroup().length() == 3 );
	}


}

