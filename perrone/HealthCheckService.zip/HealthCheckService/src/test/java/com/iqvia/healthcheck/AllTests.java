package com.iqvia.healthcheck;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import org.springframework.test.context.ActiveProfiles;

import com.iqvia.healthcheck.database.*;
import com.iqvia.test.TestElvisToEtmfTransform;

@RunWith(Suite.class)
@ActiveProfiles("dev")
@SuiteClasses( {
			HealthcheckApplicationTests.class,
			WingspanClientTests.class,
			BatchTest.class,
			ConfigurationTest.class,
			DocumentTest.class,
			JobTest.class,
			StudyTest.class,
			TestElvisToEtmfTransform.class
		} )
public class AllTests
{

}
