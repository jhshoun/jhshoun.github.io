package com.iqvia.healthcheck.database;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.iqvia.healthcheck.dao.StudyMapper;
import com.iqvia.healthcheck.dao.models.Study;

@RunWith(SpringRunner.class)
@MybatisTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("dev")
public class StudyTest
{

	@Autowired
	private StudyMapper study;

	@Test
	public void getAllStudies()
	{
		List<Study> all;

		all = study.getAll();
		assertTrue(all.size() > 10);
	}

	@Test
	public void getStudiesToRun()
	{
		List<Study> toRun;
		StudyMapper.StudySearchParms parms;

		parms = new StudyMapper.StudySearchParms(null);
		study.getRunQueue( parms );
		toRun = parms.p_result;

		assertTrue(toRun.size() > 0);
	}
}

