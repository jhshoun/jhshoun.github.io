package com.iqvia.healthcheck;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.iqvia.healthcheck.service.wingspan.WingspanClient2;
import com.iqvia.healthcheck.service.wingspan.WsDocumentJSONResponse;
import com.iqvia.model.EtmfModel;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("dev")
public class WingspanClientTests
{

	@Test
	public void uploadDoc()
	{
		WingspanClient2 wc2;
		WingspanClient2.Wing iid;
		EtmfModel wingDoc;

		wingDoc = new EtmfModel();
		wingDoc.setSource("the shoun");
		wingDoc.setSourceDescription("unit testing");
		wc2 = new WingspanClient2();
		iid = wc2.uploadDocument(wingDoc, "C:/temp/hello.pdf");

		assertTrue( iid.isGood() );
	}

//	@Test
//	public void finalizeDoc()
//	{
//		String wid = "100055360000000000263876";
//		WingspanClient2 wc2;
//		WingspanClient2.Wing fid;
//
//		wc2 = new WingspanClient2();
//
//		fid = wc2.finalizeDocument( wid );
//		assertTrue( fid.isGood() );
//	}

	@Test
	public void deleteFromWorkArea()
	{
		WingspanClient2 wc2;
		WingspanClient2.Wing rc;
		WingspanClient2.Wing iid;
		EtmfModel wingDoc;

		wingDoc = new EtmfModel();
		wingDoc.setSource("HC 2.0");
		wingDoc.setSourceDescription("testing work area delete");
		wc2 = new WingspanClient2();
		iid = wc2.uploadDocument(wingDoc, "C:/temp/hello.pdf");

		assertTrue( iid.isGood() );

		rc = wc2.workareaDelete( iid.getIid() );
		assertTrue( rc.isGood() );

	}


	@Test
	public void removeFinalItem()
	{
		String wid;
		WingspanClient2 wc2;
		WingspanClient2.Wing rc;
		WsDocumentJSONResponse studyDocs;

		wc2 = new WingspanClient2();
		studyDocs = wc2.studyDocuments("109MS413");
		wid = studyDocs.data[20].id;

		rc = wc2.finalizeReset( wid );
		assertTrue( rc.isGood() );

	}

	@Test
	public void getStudyDocuments()
	{
		WingspanClient2 wc2;
		WsDocumentJSONResponse studyDocs;

		wc2 = new WingspanClient2();
		studyDocs = wc2.studyDocuments("CD-ON-MEDI-575-1031");

		assertTrue( studyDocs.data.length > 3 );

	}


}

