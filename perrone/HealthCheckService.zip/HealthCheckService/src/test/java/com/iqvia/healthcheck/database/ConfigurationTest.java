package com.iqvia.healthcheck.database;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.iqvia.healthcheck.dao.ConfigurationMapper;
import com.iqvia.healthcheck.dao.models.Configuration;

@RunWith(SpringRunner.class)
@MybatisTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("dev")
public class ConfigurationTest
{

	@Autowired
	private ConfigurationMapper cfg;


	@Test
	public void getUrl()
	{
		Configuration c;

		c = cfg.getByName( "wingspan.server" );
		assertTrue( "https://tmfhealth26.testing.mywingspan.com".equals( c.getVarValue() ) );
	}

}


