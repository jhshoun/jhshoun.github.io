package com.iqvia.healthcheck.database;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.iqvia.healthcheck.dao.JobMapper;
import com.iqvia.healthcheck.dao.models.Job;

@RunWith(SpringRunner.class)
@MybatisTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("dev")
public class JobTest
{

	@Autowired
	private JobMapper job;

	@Test
	public void getAllJobs()
	{
		List<Job> all;

		all = job.getAll();
		assertTrue(all.size() > 10);
	}

	@Test
	public void setStatus()
	{
		Job j;

		job.setStatus(428L, "TESTING");
		j = job.findById( 428L );
		assertTrue( "TESTING".equals( j.getJobStatus() ) );
	}

	@Test
	public void setComplete()
	{
		Job j;

		job.setCompleted(428L);
		j = job.findById( 428L );
		assertTrue( "COMPLETED".equals( j.getJobStatus() ) );
	}

	@Test
	public void getNewJobId()
	{
		Long jid;

		jid = job.getNextJobId("INFOSARIO", "PROT-INF003");
		assertTrue( jid > 100 );
	}

	// create a new export job
	@Test
	public void createNewJob()
	{
		Long jid;
		Job j;

		jid = job.getNextJobId("INFOSARIO", "PROT-INF003");
		assertTrue( jid > 100 );
		j = job.findById(jid);
		assertTrue(j == null);

		job.expBatchJob("INFOSARIO", "PROT-INF003", jid);
		j = job.findById(jid);
		assertTrue(j != null);
		assertTrue( j.getJobParam().startsWith("INFO") );

		job.setCompleted(jid);
	}

	// count running jobs
	@Test
	public void jobCount()
	{
		Long running;

		running = job.getRunCount();
		System.out.println("there are " + running + " jobs running");
		assertTrue(running != null);
	}
}

