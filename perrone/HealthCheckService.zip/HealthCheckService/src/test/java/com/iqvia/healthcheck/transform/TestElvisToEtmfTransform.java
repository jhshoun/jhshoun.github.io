package com.iqvia.healthcheck.transform;

import com.iqvia.ElvisToEtmfTransformer;
import com.iqvia.model.ElvisModel;
import com.iqvia.model.EtmfModel;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class TestElvisToEtmfTransform
{

	@Test
	public void testElvisToEtmsTransform1()
	{
		EtmfModel etmfObj;
		ElvisToEtmfTransformer transformer = new ElvisToEtmfTransformer();
		ElvisModel elvisObj = new ElvisModel();

		elvisObj.setProtocolNumber("SB112");
		elvisObj.setCountry("United States");
		elvisObj.setSiteId("Washington DC");
		elvisObj.setDocumentLanguage("Spanish");
		elvisObj.set_class("Country");
		elvisObj.setZone("01 Trial Management");
		elvisObj.setAbbreviation("Co-FC");
		elvisObj.setSection("01 Trial Oversight");
		elvisObj.setArtifact("01 Trial Master File Plan");
		elvisObj.setDiaKey("03.04.01");
		elvisObj.setDocumentDate("11/06/2019");
		elvisObj.setCreatedDate("11/05/2018");
		elvisObj.setDocumentName("naveen");
		elvisObj.setDataId("123456");

		etmfObj = transformer.transform(elvisObj);
		System.out.println(etmfObj);

		assertTrue(elvisObj
						.getCountry()
						.toUpperCase()
						.equals( etmfObj.getCountry() )
				);
		assertTrue(elvisObj.getProtocolNumber().equals(etmfObj.getStudy()));

	}


	@Test
	public void testElvisToEtmsTransform2()
	{
		EtmfModel etmfObj;
		ElvisToEtmfTransformer transformer = new ElvisToEtmfTransformer();
		ElvisModel elvisObj = new ElvisModel();

		elvisObj.setDataId("41941884");
		elvisObj.setSponsor("BOEHRINGER_INGEL");
		elvisObj.setProtocolNumber("1302.5");
		elvisObj.setCountry("NETHERLANDS");
		elvisObj.setSiteId("854");
		elvisObj.setSiteName("Amsterdam UMC, Locatie AMC");
		elvisObj.setInvestigatorName("Lowenberg, Mark");
		elvisObj.setFirstName("Geert");
		elvisObj.setLastName("DHaens");

		elvisObj.set_class("Site");
		elvisObj.setZone("05 Site Management");
		elvisObj.setSection("02 Site Set-up Documentation");
		elvisObj.setArtifact("10 Financial Disclosure-Investigator Consent");
		elvisObj.setDiaKey("05.02.10");
		elvisObj.setAbbreviation("FDF-Other");
		elvisObj.setUnblinded("NO");
		elvisObj.setDocumentName("CntryMstrICF-Main-2016-04-07-VER-V4.0EGY ar 1.0-ara-TVF-000001");
		elvisObj.setDocumentDate("2016-04-07");
		elvisObj.setCreatedDate("2016-09-26");
		elvisObj.setDocumentLanguage("Arabic");
		elvisObj.setLanguageIdentifier("TVF");
		// elvisObj.setFirstName("");
		// elvisObj.setLastName("");
		// elvisObj.setVisitType("");
		// elvisObj.setVisitDocumentID("");
		// elvisObj.setDrugType("");
		// elvisObj.setCountryCode("");
		// elvisObj.setProjectCode("");
		// elvisObj.setLanguageAbbreviation("");
		// elvisObj.setEventIdentifier("");
		// elvisObj.setReportVersion("");
		// elvisObj.setOrganizationId("");
		elvisObj.setUrl("http://etmf.quintiles.com/etmf/llisapi.dll/Properties/41941884");
		elvisObj.setDisposition("DELETE");

		etmfObj = transformer.transform(elvisObj);
		System.out.println(etmfObj);

		assertTrue(elvisObj.getCountry().toUpperCase().equals(etmfObj.getCountry()));
		assertTrue(elvisObj.getProtocolNumber().equals(etmfObj.getStudy()));

	}


}
