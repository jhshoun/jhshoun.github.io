package com.iqvia.healthcheck.database;

import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.spring.boot.test.autoconfigure.MybatisTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.iqvia.healthcheck.dao.BatchMapper;

@RunWith(SpringRunner.class)
@MybatisTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("dev")
public class BatchTest
{

	@Autowired
	private BatchMapper batcher;

	@SuppressWarnings("rawtypes")
	@Test
	public void getAllExecutions()
	{
		List<Map> all;

		all = batcher.getAll();
		assertTrue(all.size() > 3);
	}

}

